import re, paths
import os

def detect_sas_comments(sas_code: str):
    """
    Extract all comments (single-line and block) from a SAS program,
    while temporarily replacing SQL * usage to avoid conflicts.

    Args:
        sas_code (str): The SAS program code as a string.

    Returns:
        list: A list of extracted comments.
    """
    # Step 1: Temporarily replace SQL * with +
    # sas_code_temp = re.sub(r"\b(select\s+\*)\s+from\b", r"\1+ from", sas_code, flags=re.IGNORECASE)
    # sas_code_temp = re.sub(r"(\()\s*\*(\s*\))", r"\1+\2", sas_code_temp)
    sas_code_temp = sas_code.replace("select * from","select + from").replace("SELECT * FROM","select + from")
    sas_code_temp = sas_code_temp.replace("(*)","(+)")
    sas_code_temp = sas_code_temp.replace(".*",".+")

    # Regex patterns for SAS comments:
    # 1. Block comments: /* ... */ (handles multiline and multiple instances)
    block_comment_pattern = r"/\*.*?\*/"
    
    # 2. Single-line comments: * ... ; (ends with a semicolon)
    single_line_comment_pattern = r"\*[^;]*;"

    # Combine both patterns with '|'
    combined_pattern = f"{block_comment_pattern}|{single_line_comment_pattern}"

    # Use re.DOTALL and re.MULTILINE to handle overlapping block comments
    comments = []
    pos = 0
    while pos < len(sas_code_temp):
        match = re.search(combined_pattern, sas_code_temp[pos:], re.DOTALL)
        if not match:
            break
        comments.append(match.group())
        pos += match.start() + len(match.group())

    # Step 2: Restore SQL * by replacing + back to *
    sas_code_temp = re.sub(r"\b(select\s+)\+\s+from\b", r"\1* from", sas_code_temp, flags=re.IGNORECASE)
    sas_code_temp = re.sub(r"(\()\s*\+\s*(\))", r"\1*\2", sas_code_temp)
    sas_code_temp = sas_code_temp.replace(".+",".*")


    new_code = sas_code_temp
    for comment in comments:
        new_code = new_code.replace(comment,'\n'*comment.count('\n'))
    
    return comments, new_code

def process_sas_files(directory_path: str):
    """
    Recursively process all SAS files in the given directory and its subdirectories.
    
    Args:
        directory_path (str): Root path to process SAS files
    """
    for root, dirs, files in os.walk(directory_path):
        # Filter for .sas files
        sas_files = [f for f in files if f.endswith('.sas')]
        
        for sas_file in sas_files:
            file_path = os.path.join(root, sas_file)
            try:
                # Read the original file
                with open(file_path, 'r', encoding='utf-8') as f:
                    sas_code = f.read()
                
                # Process the code
                comments, new_code = detect_sas_comments(sas_code)
                
                # Write the processed code back to the file
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_code)
                    
                print(f"Processed: {file_path}")
                
            except Exception as e:
                print(f"Error processing {file_path}: {str(e)}")

# Example usage:
if __name__ == "__main__":
    directory_name = "sas_code"
    directory_path = os.path.join(paths.INPUT_PATH, directory_name)
    process_sas_files(directory_path)