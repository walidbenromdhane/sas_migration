
from tree_sitter import Language

# Step 1: Rebuild the language library
Language.build_library(
    # The path to the shared library that will be created (you will overwrite the existing one).
    r'C:\Users\ZH634TG\OneDrive - EY\Desktop\SAS Lineage\SAS-Lineage\tree-sitter-sql\build\sql.so',

    # List of language repository paths (point to your updated tree-sitter grammar).
    [
        r'C:\Users\ZH634TG\OneDrive - EY\Desktop\SAS Lineage\SAS-Lineage\tree-sitter-sql'
    ]
)

print("Language library has been successfully rebuilt.")

