import os
import sqlite3
import pandas as pd
from SQL_toolkit import SQLParser, ASTProcessor
import paths
import re

print(paths.OUTPUT_PATH)
def analyze_sql_file(file_path: str, sql_parser: SQLParser):
    """Analyze a single SQL file and extract SQL information and columns"""
    try:
        with open(file_path, 'r', encoding='utf8') as f:
            sql_script = f.read()

        # Preprocess: remove all # characters
        sql_script = sql_script.replace('#', '')
        
        # Preprocess: convert three-part table references (DB.SCHMA.TABLE) to two-part (SCHMA.TABLE)
        sql_script = re.sub(r'(\w+)\.(\w+)\.(\w+)', r'\2.\3', sql_script)
        
        # Process SQL statements
        tables = []
        columns_data = []
        
        # Split the script into individual statements
        statements = [stmt.strip() for stmt in sql_script.split(';') if stmt.strip()]
        
        for sql in statements:
            try:
                # Process the SQL statement
                sql_tree = sql_parser.parse(sql)
                sql_processor = ASTProcessor(sql)
                sql_processor.previous_tables = []
                sql_processor.traverse_tree(sql_tree.root_node)
                
                # Get tables from processor
                if not sql_processor.df.empty:
                    for _, row in sql_processor.df.iterrows():
                        table_name = str(row.get('Table', '')).replace('"', '')
                        schema_name = str(row.get('Library', '')).replace('"', '')
                        
                        if table_name:  # Only add if we have a table name
                            tables.append({
                                'type': 'input' if row.get('Input/Output') == 'Input' else 'output',
                                'step_type': row.get('Operation', 'unknown').lower(),
                                'schema': schema_name.lower(),
                                'table_name': table_name.lower(),
                                'Source_Line': 0,  # Line numbers not tracked in this version
                                'join_condition': row.get('Condition'),
                                'involved_tables': row.get('Involved Tables'),
                                'code_block': sql,
                                'Source_File': os.path.relpath(file_path)
                            })
                
                # Get columns from processor
                if not sql_processor.columns_df.empty:
                    for _, row in sql_processor.columns_df.iterrows():
                        column_name = str(row.get('Column', '')).replace('"', '')
                        table_name = str(row.get('Table', '')).replace('"', '')
                        
                        if column_name:  # Only add if we have a column name
                            column_data = {
                                'column_name': column_name.lower(),
                                'table_name': table_name.lower(),
                                'Source_Line': 0,  # Line numbers not tracked in this version
                                'Source_File': os.path.relpath(file_path),
                                'code_block': sql
                            }
                            columns_data.append(column_data)
                            
            except Exception as e:
                print(f"Error processing SQL statement in {file_path}: {str(e)}")
                continue
        
        # Create DataFrames
        tables_df = pd.DataFrame(tables) if tables else pd.DataFrame()
        columns_df = pd.DataFrame(columns_data) if columns_data else pd.DataFrame()
        
        return tables_df, columns_df
        
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        return pd.DataFrame(), pd.DataFrame()

def analyze_sql_directory(directory_path: str, sql_grammar_path: str, output_db_path: str):
    """Analyze all SQL files in a directory and save results to SQLite database"""
    # Initialize SQL parser
    sql_parser = SQLParser(sql_grammar_path, 'sql')
    
    # Initialize SQLite database
    conn = sqlite3.connect(output_db_path)
    
    # Create tables
    create_lineage_table = '''
    CREATE TABLE IF NOT EXISTS sql_lineage (
        type TEXT,
        step_type TEXT,
        schema TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        join_condition TEXT,
        involved_tables TEXT,
        code_block TEXT
    )
    '''
    
    create_columns_table = '''
    CREATE TABLE IF NOT EXISTS sql_columns (
        column_name TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        code_block TEXT
    )
    '''
    
    conn.execute(create_lineage_table)
    conn.execute(create_columns_table)
    
    try:
        file_count = 0
        all_tables = pd.DataFrame()
        all_columns = pd.DataFrame()
        
        for root, _, files in os.walk(directory_path):
            sql_files = [f for f in files if f.endswith('.sql')]
            for sql_file in sql_files:
                file_path = os.path.join(root, sql_file)
                print(f"Processing file: {file_path}")
                
                df_tables, df_columns = analyze_sql_file(file_path, sql_parser)
                
                if not df_tables.empty:
                    all_tables = pd.concat([all_tables, df_tables], ignore_index=True)
                if not df_columns.empty:
                    all_columns = pd.concat([all_columns, df_columns], ignore_index=True)
                file_count += 1
                
                # Write to database every 100 files
                if file_count % 100 == 0:
                    if not all_tables.empty:
                        all_tables.to_sql('sql_lineage', conn, if_exists='append', index=False)
                        all_tables = pd.DataFrame()
                    if not all_columns.empty:
                        all_columns.to_sql('sql_columns', conn, if_exists='append', index=False)
                        all_columns = pd.DataFrame()
                    conn.commit()
        
        # Write remaining data
        if not all_tables.empty:
            all_tables.to_sql('sql_lineage', conn, if_exists='append', index=False)
        if not all_columns.empty:
            all_columns.to_sql('sql_columns', conn, if_exists='append', index=False)
        
        # Create indices
        print("Creating indices...")
        conn.execute('CREATE INDEX IF NOT EXISTS idx_schema ON sql_lineage(schema)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table ON sql_lineage(table_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_type ON sql_lineage(type)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_column_name ON sql_columns(column_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table_name ON sql_columns(table_name)')
        
        # Remove duplicates
        print("Removing duplicates...")
        conn.execute('''
            DELETE FROM sql_lineage 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sql_lineage 
                GROUP BY 
                    LOWER(type),
                    LOWER(step_type),
                    LOWER(schema),
                    LOWER(table_name),
                    Source_Line,
                    Source_File
            )
        ''')
        
        conn.execute('''
            DELETE FROM sql_columns 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sql_columns 
                GROUP BY 
                    LOWER(column_name),
                    LOWER(table_name),
                    Source_Line,
                    Source_File
            )
        ''')
        
        conn.commit()
        print(f"\nProcessed {file_count} files")
        print(f"Information saved to {output_db_path}")
    
    except Exception as e:
        print(f"Error during processing: {str(e)}")
    
    finally:
        conn.close()

if __name__ == "__main__":

    
    input_directory = os.path.join(paths.INPUT_PATH, "sql")
    sql_grammar_path = paths.SQL_GRAMMAR_FILE
    output_db = os.path.join(paths.OUTPUT_PATH, "sql_lineage.db")
    
    
    analyze_sql_directory(input_directory, sql_grammar_path, output_db) 