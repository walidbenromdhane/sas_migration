from tree_sitter import Language, Parser

def print_sql_tree(sql_text):
    # Load the SQL grammar
    SQL_LANGUAGE = Language(r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\sql\build\sql.so", 'sql')
    parser = Parser()
    parser.set_language(SQL_LANGUAGE)
    
    # Parse the SQL text
    tree = parser.parse(bytes(sql_text, 'utf8'))
    
    def print_node(node, level=0):
        # Get the text this node represents
        node_text = sql_text[node.start_byte:node.end_byte].strip()
        
        # Print the current node with proper indentation
        if node_text:
            print('  ' * level + f'- {node.type} [{node_text}]')
        else:
            print('  ' * level + f'- {node.type}')
        
        # Print all children recursively
        for child in node.children:
            print_node(child, level + 1)
    
    # Print the entire tree
    print("\nSQL Parse Tree:")
    print_node(tree.root_node)

if __name__ == "__main__":
    # Test SQL statements
    test_sql = """
    PROC SQL;
    CONNECT TO DB2 (DATABASE=mydb USER=myuser PASSWORD=mypass);
    CREATE TABLE work.passthrough_table AS
    SELECT * FROM CONNECTION TO DB2
    (SELECT 
        CUSTOMER_ID,
        FIRST_NAME,
        LAST_NAME,
        EMAIL_ADDRESS,
        PHONE_NUMBER
    FROM CUSTOMER_DATABASE.CUSTOMERS
    WHERE STATUS = 'ACTIVE');
    DISCONNECT FROM DB2;
QUIT;

    """
    
    print("Testing SQL Parser with:")
    print(test_sql)
    print_sql_tree(test_sql)
