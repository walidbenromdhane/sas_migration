import os

GIT_PATH = os.getcwd()
GIT_PARENT_PATH = os.path.dirname(GIT_PATH)

# SAS_GRAMMAR_FILE = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\SAS Lineage\SAS-Lineage\tree-sitter-sas\build\sas.so"
SAS_GRAMMAR_FILE = os.path.join(GIT_PATH,"tree-sitter-sas","build","sas.so")

# SQL_GRAMMAR_FILE = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\sql\build\sql.so"
SQL_GRAMMAR_FILE = os.path.join(GIT_PATH,"sql","build","sql.so")

# OUTPUT_PATH = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\output.xlsx"
OUTPUT_PATH = os.path.join(GIT_PARENT_PATH,"outputs")

# DIRECTORY = r"C:\Users\ZH634TG\Downloads\files_sas"
INPUT_PATH = os.path.join(GIT_PARENT_PATH,"inputs")
