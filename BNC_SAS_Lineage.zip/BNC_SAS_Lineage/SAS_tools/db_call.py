import sqlite3
import pandas as pd
import paths
import os

db_path = os.path.join(paths.OUTPUT_PATH, "columns.db")
connection = sqlite3.connect(db_path)

query = "SELECT * FROM sas_columns"

df = pd.read_sql_query(query, connection)
print(df)

connection.close()