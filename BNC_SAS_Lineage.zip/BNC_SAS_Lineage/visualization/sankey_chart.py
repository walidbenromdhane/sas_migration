import plotly.graph_objects as go
import pandas as pd
import os

# Load the uploaded CSV file
output_folder = os.path.join(os.path.dirname(os.path.dirname(os.getcwd())),"outputs") 

file_path = os.path.join(output_folder,'lineage.csv')
lineage_data = pd.read_csv(file_path)

# Prepare data for the Sankey diagram
# Group by `type`, `step_type`, and `table` to get flows
sankey_data = lineage_data.groupby(['type', 'step_type', 'table']).size().reset_index(name='count')

# Extract unique nodes (type, step_type, and table as separate groups)
nodes = list(sankey_data['type'].unique()) + list(sankey_data['step_type'].unique()) + list(sankey_data['table'].unique())

# Create mappings from node names to indices
node_map = {node: i for i, node in enumerate(nodes)}

# Create the links for the Sankey diagram
links = {
    'source': sankey_data['type'].map(node_map).tolist() +
              sankey_data['step_type'].map(node_map).tolist(),
    'target': sankey_data['step_type'].map(node_map).tolist() +
              sankey_data['table'].map(node_map).tolist(),
    'value': sankey_data['count'].tolist() * 2
}

# Create the Sankey diagram
fig = go.Figure(go.Sankey(
    node=dict(
        pad=15,
        thickness=20,
        line=dict(color="black", width=0.5),
        label=nodes,
    ),
    link=dict(
        source=links['source'],
        target=links['target'],
        value=links['value'],
    )
))

# Update layout for better visualization
fig.update_layout(title_text="Sankey Diagram of Dataset Flows", font_size=10)
fig.show()
