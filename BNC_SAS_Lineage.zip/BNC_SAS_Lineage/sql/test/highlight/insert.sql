INSERT INTO table1 VALUES (1, 'test')
-- <- keyword
--      ^ keyword
--             ^ variable
--                 ^ keyword
--                         ^ number
--                              ^ string
