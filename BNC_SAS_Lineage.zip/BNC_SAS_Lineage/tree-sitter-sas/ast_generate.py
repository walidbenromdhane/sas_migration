from tree_sitter import Language, Parser

# Load the SQL language for the parser
SQL_LANGUAGE = Language(
    r'C:\Users\ZH634TG\OneDrive - EY\Desktop\SAS Lineage\SAS-Lineage\tree-sitter-sas\build\sas.so', 'sas'
)

parser = Parser()
parser.set_language(SQL_LANGUAGE)

# File path to the SAS script
file = r""

# Parse the SAS file content
with open(file, 'r', encoding="utf-8") as f:
    code = f.read()

tree = parser.parse(bytes(code, "utf8"))

def print_and_save_node(node, code, file, depth=0):
    """
    Recursively print the AST to the console and save it to a file.

    Parameters:
    - node: The current node in the AST.
    - code: The source code as bytes.
    - file: File object to save the output.
    - depth: Indentation level for printing hierarchy.
    """
    indent = "  " * depth
    # Extract node text and print to console
    node_text = f"{indent}{node.type}: {code[node.start_byte:node.end_byte].decode('utf-8')}"
    print(node_text)
    # Write to file
    file.write(node_text + "\n")
    
    # Recurse for child nodes
    for child in node.children:
        print_and_save_node(child, code, file, depth + 1)

# File to save the output
output_file = "ast_output.txt"

print("Abstract Syntax Tree (AST):")
with open(output_file, "w", encoding="utf-8") as f:
    # Generate and save the AST
    print_and_save_node(tree.root_node, bytes(code, "utf8"), f)

print(f"Abstract Syntax Tree has been saved to {output_file}.")
