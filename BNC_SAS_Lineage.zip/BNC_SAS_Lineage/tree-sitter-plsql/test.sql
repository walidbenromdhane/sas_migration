CREATE OR REPLACE PACKAGE test_package AS
    v_count NUMBER;
    
    PROCEDURE process_data(p_id IN NUMBER);
    FUNCTION get_name(p_id IN NUMBER) RETURN VARCHAR2;
END test_package;
/

CREATE OR REPLACE PACKAGE BODY test_package AS
    PROCEDURE process_data(p_id IN NUMBER) IS
        v_name VARCHAR2(100);
    BEGIN
        v_name := get_name(p_id);
        
        IF v_name IS NOT NULL THEN
            UPDATE employees 
            SET processed = 1
            WHERE id = p_id;
            
            v_count := v_count + 1;
        END IF;
    EXCEPTION
        WHEN OTHERS THEN
            NULL;
    END process_data;
    
    FUNCTION get_name(p_id IN NUMBER) 
    RETURN VARCHAR2 IS
        v_result VARCHAR2(100);
    BEGIN
        SELECT name INTO v_result
        FROM employees
        WHERE id = p_id;
        
        RETURN v_result;
    END get_name;
END test_package;
/