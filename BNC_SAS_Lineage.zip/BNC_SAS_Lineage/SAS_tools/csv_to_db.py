import pandas as pd
import sqlite3
import os

def csv_to_sqlite(csv_file: str, db_file: str, table_name: str, if_exists: str = 'replace') -> None:
    """
    Convert a CSV file to a SQLite database.
    
    Args:
        csv_file (str): Path to the input CSV file
        db_file (str): Path to the output SQLite database file
        table_name (str): Name of the table to create in the database
        if_exists (str): How to behave if table exists ('fail', 'replace', or 'append')
    """
    try:
        # Read the CSV file using pandas
        df = pd.read_csv(csv_file)
        
        # Create a database connection
        conn = sqlite3.connect(db_file)
        
        # Write the data to SQLite
        df.to_sql(table_name, conn, if_exists=if_exists, index=False)
        
        # Create indices for all columns
        cursor = conn.cursor()
        for column in df.columns:
            index_name = f'idx_{table_name}_{column}'
            try:
                cursor.execute(f'CREATE INDEX IF NOT EXISTS {index_name} ON {table_name}({column})')
            except sqlite3.OperationalError:
                # Skip if column type doesn't support indexing
                continue
        
        conn.commit()
        
        # Print summary
        print(f"Successfully converted {csv_file} to SQLite database: {db_file}")
        print(f"Table name: {table_name}")
        print(f"Number of rows: {len(df)}")
        print(f"Number of columns: {len(df.columns)}")
        print(f"Columns: {', '.join(df.columns)}")
        
    except Exception as e:
        print(f"Error: {str(e)}")
    finally:
        # Close the connection if it exists
        if 'conn' in locals():
            conn.close()

def convert_directory(input_dir: str, output_db: str, if_exists: str = 'replace') -> None:
    """
    Convert all CSV files in a directory to tables in a SQLite database.
    
    Args:
        input_dir (str): Directory containing CSV files
        output_db (str): Path to the output SQLite database file
        if_exists (str): How to behave if table exists ('fail', 'replace', or 'append')
    """
    try:
        # Get all CSV files in the directory
        csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]
        
        if not csv_files:
            print(f"No CSV files found in {input_dir}")
            return
        
        print(f"Found {len(csv_files)} CSV files")
        
        # Process each CSV file
        for csv_file in csv_files:
            file_path = os.path.join(input_dir, csv_file)
            # Use filename without extension as table name
            table_name = os.path.splitext(csv_file)[0].lower()
            print(f"\nProcessing {csv_file}...")
            csv_to_sqlite(file_path, output_db, table_name, if_exists)
            
    except Exception as e:
        print(f"Error processing directory: {str(e)}")

if __name__ == "__main__":
    # Example usage for a single file
    csv_to_sqlite("input.csv", "output.db", "macros")
    
    # Example usage for a directory
    # convert_directory("input_directory", "output.db")
