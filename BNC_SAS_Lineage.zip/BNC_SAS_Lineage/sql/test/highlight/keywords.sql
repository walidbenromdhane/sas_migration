WHERE a > b OR b = a AND c > d;
-- <- keyword
--          ^ keyword
--                   ^ keyword
WHERE NOT a AND b NOT IN c AND c IN d
-- <- keyword
--    ^ keyword
--          ^ keyword
--                ^ keyword
--                         ^ keyword
--                               ^ keyword
