from tree_sitter import Language, Parser, Query
import pandas as pd

# Assuming you have a SAS grammar compiled as "sas.so"
SAS_LANGUAGE = Language('./parsing/build/sas.so', 'sas')
parser = Parser()
parser.set_language(SAS_LANGUAGE)

# sas_code = b"""
# DATA output;
#     SET input;
#     x = 5;
#     IF x > 0 THEN OUTPUT;
# RUN;
# """


sas_file = r"C:\Users\NW538RY\OneDrive - EY\Desktop\SAS_test.sas"

tree_file = r"C:\Users\NW538RY\OneDrive - EY\Desktop\tree_output.txt"
with open(sas_file, 'r') as f:
    sas_code = f.read()

# sas_code = 'LIBNAME extdat "&path_extd." filelocks=none ;'
# sas_code = 'Libname WRR ODBC dsn="WRR_PROD_CLOUD_DB";'

# print(sas_code)

# Parse the SAS code
tree = parser.parse(sas_code.encode('utf-8'))
root_node = tree.root_node

# Function to print the tree structure
def print_tree_to_file(node, file_path, level=0):
    indent = "  " * level
    with open(file_path, "a") as file:  # Open the file in append mode
        # file.write(f"{indent}{node.type}\n")
        # If you want to include start and end points, uncomment the next line
        # if node.type=="ERROR":
        # file.
        # write(f"{indent}{node.type}{node.text.decode('utf-8')}\n")
        # else:
        # file.write(f"{indent}{node.type} \n")
        file.write(f"{indent}{node.type} [{node.start_point[0]+1,node.start_point[1]+1} - {node.end_point[0]+1,node.end_point[1]+1}]\n")
    for child in node.children:
        print_tree_to_file(child, file_path, level + 1)

def print_tree(node, level=0):
    indent = "  " * level
    # print(f"{indent}{node.type} [{node.start_point} - {node.end_point}]")
    print(f"{indent}{node.type}")
    # if node.type.lower() == "let_statement":
    #     print("statement is :", node.children[0].text.decode("utf-8"),"     ",
    #           "macro_var name is:",  node.children[1].text.decode("utf-8"),"     ",
    #           "macro_var value is:",  node.children[3].text.decode("utf-8") )

    # if node.type.lower() == "libname_statement":
    #     print("statement is :", node.children[0].text.decode("utf-8"),"     ",
    #           "libname reference is:",  node.children[1].text.decode("utf-8"),"     ",
    #           "libname path is:",  node.children[2].text.decode("utf-8") )

    # if (node.type.lower() == "error") & level==1:
    #     print(node.text.decode("utf-8"))
        # statement = sas_code
        # for child in node.children:
        # statement = [child.text.decode("utf-8") for child in node.children]
        # print(statement)
        # print("statement is :", node.children[0].text.decode("utf-8"),"     ",
        #       "first:",  node.children[1].text.decode("utf-8"),"     ",
        #       "second:",  node.children[2].text.decode("utf-8") )
              
    for child in node.children:
        print_tree(child, level + 1)



def tree_to_dataframe(node, level=0, rows=None):
    if rows is None:
        rows = []
    rows.append({
        "type": node.type,
        "start_point": node.start_point,
        "end_point": node.end_point,
        "level": level,
        "content": node.text.decode("utf-8") if hasattr(node, "text") else None  # Extract node content if available
    })
    for child in node.children:
        tree_to_dataframe(child, level + 1, rows)
    return pd.DataFrame(rows)

# print_tree(root_node)
with open(tree_file, 'w') as f:
    f.write("")
print_tree_to_file(root_node, tree_file)
# df = tree_to_dataframe(root_node, level=0, rows=None)
# df.to_csv('./parsing/output_tree.csv',index=False)



# Recursive function to find nodes of a specific type
# def find_nodes_by_type(node, node_type, results=None):
#     if results is None:
#         results = []
#     if node.type == node_type:
#         results.append(node)
#     for child in node.children:
#         find_nodes_by_type(child, node_type, results)
#     return results

# # Find all `let_statement` nodes
# root_node = tree.root_node
# let_statements = find_nodes_by_type(root_node, "let_statement")

# for node in let_statements:
#     print(node.children[1].text.decode("utf-8"), " = ",node.children[3].text.decode("utf-8"))
    
