from tree_sitter import Language, Parser
import pandas as pd
import paths, os
import re

# Load the SAS grammar
sas_so = paths.SAS_GRAMMAR_FILE
LANGUAGE = Language(sas_so, 'sas')
parser = Parser()
parser.set_language(LANGUAGE)

def extract_let_statements(node, code_lines, file_path):
    """Extract LET statements from a node"""
    lets = []
    
    if node.type == 'let_statement':
        # Get the line number for this node (1-based indexing)
        line_num = node.start_point[0] + 1
        
        # Get the full statement text
        statement = node.text.decode('utf-8').strip()
        
        # Use regex to separate key and value
        match = re.match(r'%let\s+(\w+)\s*=\s*(.*?)\s*;', statement, re.IGNORECASE)
        if match:
            key = match.group(1)
            value = match.group(2)
            
            lets.append({
                'key': key,
                'value': value,
                'full_statement': statement,
                'Source_Line': line_num,
                'Source_File': file_path
            })
    
    # Recursively process child nodes
    for child in node.children:
        lets.extend(extract_let_statements(child, code_lines, file_path))
    
    return lets

def analyze_sas_file(file_path):
    """Analyze a single SAS file for LET statements"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        code_lines = code.splitlines()
        tree = parser.parse(bytes(code, 'utf8'))
        
        # Extract LET statements
        lets = extract_let_statements(tree.root_node, code_lines, file_path)
        
        return pd.DataFrame(lets)
        
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        return pd.DataFrame()

def analyze_sas_files(directory_path):
    """Analyze multiple SAS files in a directory and its subdirectories."""
    all_lets = pd.DataFrame()
    
    for root, dirs, files in os.walk(directory_path):
        sas_files = [f for f in files if f.endswith('.sas')]
        
        for sas_file in sas_files:
            file_path = os.path.join(root, sas_file)
            print(f"Processing {file_path}")
            
            try:
                df_lets = analyze_sas_file(file_path)
                if not df_lets.empty:
                    relative_path = os.path.relpath(file_path, start=directory_path)
                    df_lets['Source_File'] = relative_path
                    all_lets = pd.concat([all_lets, df_lets], ignore_index=True)
            
            except Exception as e:
                print(f"Error processing {file_path}: {str(e)}")
    
    # Export to Excel
    if not all_lets.empty:
        output_path = os.path.join(paths.OUTPUT_PATH, "let_statements.xlsx")
        try:
            with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                all_lets.to_excel(writer, sheet_name='LET Statements', index=False)
                
                # Add a summary sheet
                summary = pd.DataFrame({
                    'Metric': ['Total LET Statements', 'Unique Keys'],
                    'Value': [len(all_lets), len(all_lets['key'].unique())]
                })
                summary.to_excel(writer, sheet_name='Summary', index=False)
                
            print(f"\nResults written to: {output_path}")
            
        except Exception as e:
            print(f"Error writing Excel file: {str(e)}")
    
    return all_lets

if __name__ == "__main__":
    input_directory = os.path.join(paths.INPUT_PATH, "smu")  # Adjust directory name as needed
    result = analyze_sas_files(input_directory)
    print("\nExtracted LET Statements:")
    print(f"Total statements found: {len(result)}")
