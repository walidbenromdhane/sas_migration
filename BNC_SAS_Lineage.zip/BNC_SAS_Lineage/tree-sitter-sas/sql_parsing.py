import sqlglot

query = "SELECT name, age FROM users WHERE age > 25; SELECT lastname FROM students WHERE GPA=4;"

# Parse all statements
parsed_queries = sqlglot.parse(query)

for i, parsed_query in enumerate(parsed_queries):
    print(f"\n--- Query {i+1} ---")
    
    # Accessing the selected columns
    select_columns = parsed_query.args.get("expressions")
    print("Selected columns:", [str(column.args["this"]) for column in select_columns])
    
    # Accessing the FROM clause
    from_clause = parsed_query.args.get("from")
    print("From table:",from_clause.args["this"])
    
    # Accessing the WHERE clause (if it exists)
    where_clause = parsed_query.args.get("where")
    if where_clause:
        print("Where condition:", where_clause.args["this"])# Shows the condition
    else:
        print("No WHERE clause.")
