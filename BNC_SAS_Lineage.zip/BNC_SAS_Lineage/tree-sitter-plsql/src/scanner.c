#include <tree_sitter/parser.h>
#include <wctype.h>

enum TokenType {
  DOLLAR_QUOTED_STRING_START,
  DOLLAR_QUOTED_STRING_CONTENT,
  DOLLAR_QUOTED_STRING_END,
};

void *tree_sitter_plsql_external_scanner_create() { return NULL; }
void tree_sitter_plsql_external_scanner_destroy(void *p) {}
void tree_sitter_plsql_external_scanner_reset(void *p) {}
unsigned tree_sitter_plsql_external_scanner_serialize(void *p, char *buffer) { return 0; }
void tree_sitter_plsql_external_scanner_deserialize(void *p, const char *b, unsigned n) {}

bool tree_sitter_plsql_external_scanner_scan(void *payload, TSLexer *lexer, const bool *valid_symbols) {
  // Basic implementation that just returns false
  // You can expand this to handle dollar-quoted strings if needed
  return false;
} 