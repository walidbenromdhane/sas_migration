import os, chardet, paths
import unicodedata
import re

"""
This code ensures that all the SAS codes are encoded correctly and removes comments. 
It needs to be executed with each new set of SAS code copied into the 'inputs' folder.
"""

def normalize_french_chars(text):
    """
    Replace French characters with their English counterparts.
    For example: é -> e, à -> a, ç -> c, etc.
    """
    # First, decompose the characters (separate base letter from accents)
    normalized = unicodedata.normalize('NFKD', text)
    # Then remove the accent marks, keeping only the base letters
    normalized = ''.join(c for c in normalized if not unicodedata.combining(c))
    return normalized

def detect_sas_comments(sas_code: str):
    """
    Extract all comments (single-line and block) from a SAS program,
    while temporarily replacing SQL * usage to avoid conflicts.

    Args:
        sas_code (str): The SAS program code as a string.

    Returns:
        list: A list of extracted comments.
    """
    # Step 1: Temporarily replace SQL * with +
    # sas_code_temp = re.sub(r"\b(select\s+\*)\s+from\b", r"\1+ from", sas_code, flags=re.IGNORECASE)
    # sas_code_temp = re.sub(r"(\()\s*\*(\s*\))", r"\1+\2", sas_code_temp)
    sas_code_temp = sas_code.replace("select * from","select + from").replace("SELECT * FROM","select + from")
    sas_code_temp = sas_code_temp.replace("(*)","(+)")
    sas_code_temp = sas_code_temp.replace(".*",".+")

    # Regex patterns for SAS comments:
    # 1. Block comments: /* ... */ (handles multiline and multiple instances)
    block_comment_pattern = r"/\*.*?\*/"
    
    # 2. Single-line comments: * ... ; (ends with a semicolon)
    single_line_comment_pattern = r"\*[^;]*;"

    # Combine both patterns with '|'
    combined_pattern = f"{block_comment_pattern}|{single_line_comment_pattern}"

    # Use re.DOTALL and re.MULTILINE to handle overlapping block comments
    comments = []
    pos = 0
    while pos < len(sas_code_temp):
        match = re.search(combined_pattern, sas_code_temp[pos:], re.DOTALL)
        if not match:
            break
        comments.append(match.group())
        pos += match.start() + len(match.group())

    # Step 2: Restore SQL * by replacing + back to *
    sas_code_temp = re.sub(r"\b(select\s+)\+\s+from\b", r"\1* from", sas_code_temp, flags=re.IGNORECASE)
    sas_code_temp = re.sub(r"(\()\s*\+\s*(\))", r"\1*\2", sas_code_temp)
    sas_code_temp = sas_code_temp.replace(".+",".*")


    new_code = sas_code_temp
    for comment in comments:
        new_code = new_code.replace(comment,'\n'*comment.count('\n'))
    
    return comments, new_code

def fix_file_encoding(filepath):
    with open(filepath, 'rb') as f:
        data = f.readlines()

    # Decode and normalize all lines
    processed_lines = []
    for line in data:
        detection = chardet.detect(line)
        try:
            decoded_line = line.decode('utf8')
        except:
            try:
                decoded_line = line.decode('ISO-8859-1')
            except:
                decoded_line = line.decode(detection['encoding'])
        
        # Normalize French characters after decoding
        processed_lines.append(normalize_french_chars(decoded_line))

    # Join all lines, remove comments, and clean up the text
    full_text = ''.join(processed_lines)
    _, cleaned_text = detect_sas_comments(full_text)
    
    # Remove any excessive blank lines created by comment removal
    cleaned_text = re.sub(r'\n\s*\n', '\n\n', cleaned_text)

    # Write the cleaned content back to file in UTF-8 encoding
    with open(filepath, mode='w', newline='', encoding='utf8') as f:
        f.write(cleaned_text)

##################
directory_name = "sas_code"
directory_path = os.path.join(paths.INPUT_PATH, directory_name)
for root, dirs, files in os.walk(directory_path):
    sas_files = [f for f in files if f.endswith('.sas')]
    for sas_file in sas_files:
        file_path = os.path.join(root, sas_file)
        print(file_path)
        fix_file_encoding(file_path)