import pandas as pd
import networkx as nx
from generate_yed_graph import to_graphml
import os


output_folder = os.path.join(os.path.dirname(os.getcwd()),"outputs") 
output_file = os.path.join(output_folder, "programs_dependencies.graphml")

def get_files_filtered_by_keywords():
    file_path = os.path.join(output_folder,"files_filtered_by_keywords.csv")
    df = pd.read_csv(file_path)
    df["file_path"] = df.apply(lambda x: x['file_path'].lower(),axis=1)
    files_filtered_by_keywords = df["file_path"].unique().tolist()
    return files_filtered_by_keywords

def get_table_data():
    # Replace with the actual path to your CSV file
    file_path = os.path.join(output_folder,"lineage.csv")
    df = pd.read_csv(file_path)
    return df

def clean_string(string):
    cleaned_string = str(string).replace("&","_")\
                                .replace("<","leq")\
                                .replace(">","geq")\
                                .replace('"',"'")\
                                .lower()
    return cleaned_string

# Read data
df = get_table_data()
files_filtered_by_keywords = get_files_filtered_by_keywords()

# Create a directed graph
G = nx.DiGraph()

# Process the data to add nodes and edges
for _, row in df.iterrows():
    source_file = row["Source_File"].rsplit("\\",1)[0].rsplit("\\",1)[1].lower()
    # source_file = clean_string(row["Source_File"])
    data_source = clean_string(row["table"])
    data_source = clean_string(row["library"])
    table_type  = clean_string(row["type"])
    
    # Add a node for the program (source file)
    if any(source_file in s for s in files_filtered_by_keywords):
        G.add_node(source_file, color="#FF0000", shape="ellipse", label=source_file, tooltip="program tooltip")
    else:
        G.add_node(source_file, color="#DDDDDD", shape="ellipse", label=source_file, tooltip="program tooltip")

    # Add input/output nodes and connect them to the program
    if table_type == "input":
        # Add input node and connect to program
        G.add_node(data_source, label=data_source, color="#97c2fc", tooltip="Input tooltip", shape="rectangle")
        G.add_edge(data_source, source_file, color="#009900")
    elif table_type == "output":
        # Add output node and connect program to it
        G.add_node(data_source, label=data_source, color="#97c2fc", tooltip="Output tooltip", shape="rectangle")
        G.add_edge(source_file, data_source, color="#FF0000")

# Specify output folder and file path

# Save the graph and open it
to_graphml(G, path = output_file)
os.startfile(output_file)
