from tree_sitter import Language, Parser
from SQL_toolkit import SQLParser, ASTProcessor
import pandas as pd
import paths, os
import re
import sqlite3

sas_so = paths.SAS_GRAMMAR_FILE
sql_so = paths.SQL_GRAMMAR_FILE
output_file_location = os.path.join(paths.OUTPUT_PATH,"output.xlsx")
directory_name = "smu" # Name of the directory under the "inputs" folder

# Load the SAS grammar
LANGUAGE = Language(sas_so, 'sas')
parser = Parser()
parser.set_language(LANGUAGE)
sql_parser = SQLParser(sql_so, 'sql')

# Update these regex patterns for better SQL cleaning
PROC_SQL_REGEX = re.compile(r"(?i)PROC\s+SQL\s*;(.*?)(?=\s*QUIT\s*;)", re.DOTALL)
PROC_DATA_REGEX = re.compile(r'(?i)data\s*=\s*([^\s;]+)')
PROC_OUT_REGEX = re.compile(r'(?i)out\s*=\s*([^\s;]+)')
# Updated to better capture database type with optional whitespace and parameters
CONNECT_TO_REGEX = re.compile(r'(?i)CONNECT\s+TO\s+(\w+)(?:\s*\([^)]*\))?\s*;', re.DOTALL)
SELECT_FROM_CONNECTION_REGEX = re.compile(r'(?i)SELECT\s+.*?FROM\s+CONNECTION\s+TO\s+\w+\s*\(', re.DOTALL)

# Add SAS keywords set near the top with other constants
SAS_KEYWORDS = {
    'and', 'as', 'by', 'delete', 'drop', 'else', 'end', 'from', 'group', 'having',
    'if', 'in', 'into', 'join', 'left', 'like', 'not', 'null', 'on', 'or', 'order',
    'outer', 'right', 'run', 'set', 'then', 'union', 'update', 'where', 'while', 'quit'
}

# Add near the top with other regex patterns
MACRO_PERIOD_REGEX = re.compile(r'&[^.\s]+\.')

# Update the PROC_REGEX pattern
PROC_REGEX = re.compile(r'(?i)PROC\s+(?!SQL\b)(\w+).*?(?:run\s*;)', re.DOTALL)

# Add new patterns with same structure as existing ones
DATAFILE_REGEX = re.compile(r'(?i)datafile\s*=\s*(?:(["\'])(.*?)\1|([^\s;]+))')
OUTFILE_REGEX = re.compile(r'(?i)outfile\s*=\s*(?:(["\'])(.*?)\1|([^\s;]+))')

def normalize_table_name(table_name):
    """Normalize table name by removing the first period after each & symbol and handling special SAS tables"""
    if not isinstance(table_name, str):
        return table_name
    
    
    # Split the string into segments at & symbols
    parts = table_name.split('&')
    result = parts[0]  # Keep the first part as is
    
    # Process each part that started with &
    for part in parts[1:]:
        if part:  # Only process non-empty parts
            # Find the first period in this part
            period_idx = part.find('.')
            if period_idx != -1:
                # Keep everything before the first period and after it
                result += '&' + part[:period_idx] + part[period_idx + 1:]
            else:
                result += '&' + part
    
    return result.strip()

def normalize_sql(sql):
    """Normalize SQL string by cleaning up whitespace and formatting"""
    # First, handle the trailing period after table names in CREATE TABLE and FROM statements
    sql = re.sub(r'(?i)(CREATE\s+TABLE\s+\w+)\.(\s+AS)', r'\1\2', sql)
    sql = re.sub(r'(?i)(FROM\s+[\w.]+)\.(\s+)', r'\1\2', sql)  # Handle FROM statements
    sql = re.sub(r'(?i)(JOIN\s+[\w.]+)\.(\s+)', r'\1\2', sql)  # Handle JOIN statements
    
    # Replace multiple whitespace with single space
    sql = re.sub(r'\s+', ' ', sql)
    
    # Ensure single space after commas
    sql = re.sub(r',\s*', ', ', sql)
    
    # Ensure single space around operators
    sql = re.sub(r'\s*(=|\+|-|\*|/|\(|\))\s*', r' \1 ', sql)
    
    # Clean up JOIN syntax
    sql = re.sub(r'\s+JOIN\s+', ' JOIN ', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+ON\s+', ' ON ', sql, flags=re.IGNORECASE)
    
    # Clean up FROM syntax
    sql = re.sub(r'\s+FROM\s+', ' FROM ', sql, flags=re.IGNORECASE)
    
    # Remove any trailing/leading whitespace
    sql = sql.strip()
    
    return sql

def extract_proc_info(code):
    """Extract information from PROC statements using regex"""
    tables = []
    
    # Find all PROC blocks (excluding PROC SQL)
    for match in PROC_REGEX.finditer(code):
        proc_type = match.group(1).upper()
        proc_block = match.group(0)
        line_num = code[:match.start()].count('\n') + 1
        
        # Find input (DATA= and DATAFILE=) datasets
        for data_match in PROC_DATA_REGEX.finditer(proc_block):
            dataset = normalize_table_name(data_match.group(1))
            lib, table = ('WORK', dataset) if '.' not in dataset else dataset.split('.')
            tables.append({
                'type': 'input',
                'step_type': f'PROC {proc_type}',
                'library': lib,
                'table': table,
                'Source_Line': line_num,
                'code_block': proc_block
            })
        
        for datafile_match in DATAFILE_REGEX.finditer(proc_block):
            # Get either the quoted string (group 2) or the unquoted string (group 3)
            file_path = datafile_match.group(2) or datafile_match.group(3)
            file_path = normalize_table_name(file_path)
            tables.append({
                'type': 'input',
                'step_type': f'PROC {proc_type}',
                'library': 'EXTERNAL',
                'table': file_path,
                'Source_Line': line_num,
                'code_block': proc_block
            })
        
        # Find output (OUT= and OUTFILE=) datasets
        for out_match in PROC_OUT_REGEX.finditer(proc_block):
            dataset = normalize_table_name(out_match.group(1))
            lib, table = ('WORK', dataset) if '.' not in dataset else dataset.split('.')
            tables.append({
                'type': 'output',
                'step_type': f'PROC {proc_type}',
                'library': lib,
                'table': table,
                'Source_Line': line_num,
                'code_block': proc_block
            })
            
        for outfile_match in OUTFILE_REGEX.finditer(proc_block):
            # Get either the quoted string (group 2) or the unquoted string (group 3)
            file_path = outfile_match.group(2) or outfile_match.group(3)
            file_path = normalize_table_name(file_path)
            tables.append({
                'type': 'output',
                'step_type': f'PROC {proc_type}',
                'library': 'EXTERNAL',
                'table': file_path,
                'Source_Line': line_num,
                'code_block': proc_block
            })
    
    return tables

def extract_dataset_info(node, code_lines):
    """Extract dataset information from a node"""
    tables = []
    data_found = False
    
    # Get the line number for this node (1-based indexing)
    node_line_num = node.start_point[0] + 1
    
    if node.type == 'data_step':
        current_lib = 'WORK'
        # Capture the full DATA step code block
        full_block = node.text.decode('utf-8')
        
        for child in node.children:
            child_line_num = child.start_point[0] + 1
            
            if child.type == 'DATA':
                data_found = True
                continue
            elif data_found:
                # Get the raw text of the dataset name
                dataset_text = child.text.decode('utf-8').strip() if child.text else ''
                
                # Check for _null_ specifically (case-insensitive)
                if dataset_text.upper() == '_NULL_':
                    tables.append({
                        'type': 'output',
                        'step_type': 'DATA _null_',
                        'library': 'NULL',
                        'table': '_NULL_',
                        'Source_Line': child_line_num,
                        'code_block': full_block
                    })
                    data_found = False
                    continue
                
                # Normal dataset processing
                elif child.type == 'identifier':
                    next_sibling = child.next_sibling
                    if next_sibling and next_sibling.type == '.':
                        current_lib = normalize_table_name(dataset_text)
                    else:
                        tables.append({
                            'type': 'output',
                            'step_type': 'DATA',
                            'library': current_lib,
                            'table': normalize_table_name(dataset_text),
                            'Source_Line': child_line_num,
                            'code_block': full_block
                        })
                        data_found = False
            
            elif child.type == 'set_statement' or child.type == 'merge_statement':
                # Handle both SET and MERGE statements the same way
                current_lib = 'WORK'
                for set_child in child.children:
                    set_line_num = set_child.start_point[0] + 1
                    
                    if set_child.type == 'identifier':
                        next_sibling = set_child.next_sibling
                        if next_sibling and next_sibling.type == '.':
                            current_lib = normalize_table_name(set_child.text.decode('utf-8'))
                        else:
                            table = normalize_table_name(set_child.text.decode('utf-8'))
                            tables.append({
                                'type': 'input',
                                'step_type': 'SET' if child.type == 'set_statement' else 'MERGE',
                                'library': current_lib,
                                'table': table,
                                'Source_Line': set_line_num,
                                'code_block': full_block
                            })
                            current_lib = 'WORK'
            
            elif child.type == 'infile_statement':
                # Get the full statement text
                infile_text = child.text.decode('utf-8').strip()
                tables.append({
                    'type': 'input',
                    'step_type': 'INFILE',
                    'library': 'EXTERNAL',
                    'table': infile_text,
                    'Source_Line': child_line_num,
                    'involved_tables': None,
                    'join_condition': None
                })
    
    elif node.type == 'filename_statement':
        # Get the full statement text
        filename_text = node.text.decode('utf-8').strip()
        tables.append({
            'type': 'input',
            'step_type': 'FILENAME',
            'library': 'EXTERNAL',
            'table': filename_text,
            'Source_Line': node_line_num,
            'involved_tables': None,
            'join_condition': None
        })
    
    elif node.type == 'include_statement':
        # Get the full statement text
        include_text = node.text.decode('utf-8').strip()
        # Extract the file path
        file_path = None
        for child in node.children:
            if child.type == 'string':
                file_path = child.text.decode('utf-8').strip('"\'')
                break
            elif child.type == 'identifier':
                # Handle library.member format
                next_sibling = child.next_sibling
                if next_sibling and next_sibling.type == '.':
                    lib = child.text.decode('utf-8')
                    member = next_sibling.next_sibling.text.decode('utf-8') if next_sibling.next_sibling else None
                    if member:
                        file_path = f"{lib}.{member}"
        
        if file_path:
            tables.append({
                'type': 'input',
                'step_type': 'INCLUDE',
                'library': 'EXTERNAL',
                'table': include_text,
                'Source_Line': node_line_num,
                'involved_tables': None,
                'join_condition': None
            })
    
    for child in node.children:
        tables.extend(extract_dataset_info(child, code_lines))
    
    return tables

def extract_libref_info(node, code_lines):
    """Extract libref information from a node"""
    librefs = []
    
    if node.type == 'libname_statement':
        libref_name = None
        engine = None
        path = None
        line_num = node.start_point[0] + 1
        # Get the full statement
        full_statement = node.text.decode('utf-8')
        
        for child in node.children:
            if child.type == 'identifier' and not libref_name:
                libref_name = child.text.decode('utf-8')
            elif child.type == 'string':
                path = child.text.decode('utf-8').strip('"')
            elif child.type == 'identifier' and libref_name:
                engine = child.text.decode('utf-8')
        
        if libref_name:
            librefs.append({
                'libref': libref_name,
                'engine': engine,
                'path': path,
                'Source_Line': line_num,
                'full_statement': full_statement  # New column
            })
    
    for child in node.children:
        librefs.extend(extract_libref_info(child, code_lines))
    
    return librefs

def convert_df_to_lowercase(df):
    """Convert all string values in DataFrame to lowercase"""
    for column in df.columns:
        if df[column].dtype == 'object':  # Only convert string/object columns
            df[column] = df[column].apply(lambda x: x.lower() if isinstance(x, str) else x)
    return df

def preserve_lines_replace(pattern, repl, text):
    """Replace pattern with empty lines while preserving line count"""
    def replacement(match):
        # Count newlines in the matched text
        newline_count = match.group(0).count('\n')
        # If there are newlines, return that many empty lines
        if newline_count:
            return '\n' * newline_count
        # If no newlines, return a single space to preserve the line
        return ' '
    
    return re.sub(pattern, replacement, text)

def remove_comments(sql):
    """Remove SQL comments while preserving line numbers"""
    # Remove inline comments /*...*/
    sql = re.sub(r'/\*.*?\*/', '', sql)
    # Remove single-line comments --...
    sql = re.sub(r'--.*$', '', sql, flags=re.MULTILINE)
    return sql

def analyze_sas_file(file_path):
    """Analyze a SAS file and extract table and libref information"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # First normalize the table names to handle periods after & symbols
        code = normalize_table_name(code)
        
        # Then handle macro variables
        code = code.replace('&', 'MACROREPLACE')
        
        # Extract PROC information using regex
        proc_tables = extract_proc_info(code)
        
        # Check for too many INSERT statements
        insert_count = len(re.findall(r'(?i)INSERT\s+INTO', code))
        if insert_count > 1000:
            print(f"Skipping {file_path}: Contains {insert_count} INSERT statements (>1000)")
            return pd.DataFrame(), pd.DataFrame()
        
        # First, find all PROC SQL blocks
        sql_blocks = PROC_SQL_REGEX.finditer(code)
        sql_tables = []
        
        # Process each SQL block
        for match in sql_blocks:
            sql_content = match.group(1)
            line_num = code[:match.start()].count('\n') + 1
            original_block = f"PROC SQL;\n{sql_content}\nQUIT;"
            
            # Check for database connection
            is_db_connection = False
            db_type = None
            db_match = CONNECT_TO_REGEX.search(sql_content)
            if db_match:
                is_db_connection = True
                try:
                    db_type = db_match.group(1).lower() if db_match.group(1) else None
                except (IndexError, AttributeError) as e:
                    print(f"Warning: Could not extract database type from {file_path}: {str(e)}")
                    db_type = "unknown"

            # Remove comments first
            sql_content = remove_comments(sql_content)
            
            # Clean up in specific order:
            cleaned_sql = sql_content
            
            # 1. Remove CONNECT TO statements
            cleaned_sql = preserve_lines_replace(CONNECT_TO_REGEX, '', cleaned_sql)
            
            # 2. Remove SELECT ... FROM CONNECTION TO ... (
            cleaned_sql = preserve_lines_replace(SELECT_FROM_CONNECTION_REGEX, '', cleaned_sql)
            
            # Clean up whitespace and empty lines
            cleaned_sql = '\n'.join(line.strip() for line in cleaned_sql.splitlines() if line.strip())
            
            # Split the SQL content into individual statements
            statements = []
            current_statement = []
            paren_count = 0
            quote_char = None
            
            for char in cleaned_sql:
                if char in ["'", '"'] and (not quote_char or char == quote_char):
                    quote_char = None if quote_char else char
                
                if not quote_char:
                    if char == '(':
                        paren_count += 1
                    elif char == ')':
                        paren_count -= 1
                
                if char == ';' and paren_count == 0 and not quote_char:
                    current_statement = ''.join(current_statement).strip()
                    if current_statement:
                        statements.append(current_statement)
                    current_statement = []
                    continue
                
                current_statement.append(char)
            
            current_statement = ''.join(current_statement).strip()
            if current_statement:
                statements.append(current_statement)
            
            for statement in statements:
                normalized_sql = normalize_sql(statement)
                sql_tree = sql_parser.parse(normalized_sql)
                sql_processor = ASTProcessor(normalized_sql)
                sql_processor.previous_tables = []
                sql_processor.traverse_tree(sql_tree.root_node)
                
                for _, row in sql_processor.df.iterrows():
                    library = row.get('Library', 'WORK')
                    table = row.get('Table')
                    # Skip if table is 'subquery'
                    if table and table.lower() != 'subquery':
                        # Handle database connections differently
                        if is_db_connection:
                            sql_tables.append({
                                'type': 'input' if row.get('Input/Output') == 'Input' else 'output',
                                'step_type': f"PROC SQL {row.get('Operation', 'UNKNOWN')}".upper(),
                                'library': '',  # Empty for DB connections
                                'schema': library,  # Move library to schema for DB connections
                                'table': table,
                                'Source_Line': line_num,
                                'join_condition': row.get('Condition'),
                                'involved_tables': row.get('Involved Tables'),
                                'code_block': original_block,
                                'database_type': db_type
                            })
                        else:
                            sql_tables.append({
                                'type': 'input' if row.get('Input/Output') == 'Input' else 'output',
                                'step_type': f"PROC SQL {row.get('Operation', 'UNKNOWN')}".upper(),
                                'library': library,
                                'schema': '',  # Empty for non-DB connections
                                'table': table,
                                'Source_Line': line_num,
                                'join_condition': row.get('Condition'),
                                'involved_tables': row.get('Involved Tables'),
                                'code_block': original_block,
                                'database_type': None
                            })
        
        # Now parse the SAS code normally for DATA steps
        code_lines = code.splitlines()
        tree = parser.parse(bytes(code, 'utf8'))
        tables = extract_dataset_info(tree.root_node, code_lines)
        librefs = extract_libref_info(tree.root_node, code_lines)
        
        # Add the PROC tables to the results
        tables.extend(proc_tables)
        tables.extend(sql_tables)
        
        # Create DataFrames with explicit columns including involved_tables
        df_tables = pd.DataFrame(tables, columns=[
            'type', 'step_type', 'library', 'schema', 'table', 'Source_Line', 
            'join_condition', 'involved_tables', 'code_block', 'database_type'  # Add involved_tables here
        ]).drop_duplicates()
        
        df_librefs = pd.DataFrame(librefs, columns=[
            'libref', 'engine', 'path', 'Source_Line', 'full_statement'
        ])
        
        # Filter and convert to lowercase
        if not df_tables.empty:
            df_tables = df_tables[df_tables['library'].str.lower() != 'connection']
            df_tables = df_tables.dropna(subset=['table'])
            df_tables = df_tables[df_tables['table'].str.strip() != "'"]
            df_tables = df_tables.sort_values(['type', 'library', 'table'])
        
        # Convert to lowercase and add quotes
        df_tables = convert_df_to_lowercase(df_tables)
        df_librefs = convert_df_to_lowercase(df_librefs)
        
        # Replace MACROREPLACE with & before adding quotes
        for df in [df_tables, df_librefs]:
            for column in df.columns:
                if column != 'code_block':  # Skip code_block for macro replacement
                    df[column] = df[column].apply(
                        lambda x: x.replace('macroreplace', '&') if isinstance(x, str) else x
                    )
        
        # Add quotes after replacing MACROREPLACE
        for df in [df_tables, df_librefs]:
            for column in df.columns:
                if column != 'code_block':  # Skip code_block for quote addition
                    df[column] = df[column].apply(
                        lambda x: f"'{str(x)}" if pd.notnull(x) else x
                    )
        
        return df_tables, df_librefs
        
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        print(f"Error details: {type(e).__name__}")
        return pd.DataFrame(), pd.DataFrame()

def analyze_sas_files(directory_path):
    """Analyze multiple SAS files in a directory and its subdirectories, and combine results."""
    # Initialize SQLite database
    db_path = os.path.join(paths.OUTPUT_PATH, "lineage.db")
    # Add new output file for empty files
    empty_files_path = os.path.join(paths.OUTPUT_PATH, "empty_files.txt")
    empty_files = []
    
    conn = sqlite3.connect(db_path)
    
    # Update table creation SQL to include involved_tables
    create_tables_sql = '''
    CREATE TABLE IF NOT EXISTS table_lineage (
        type TEXT,
        step_type TEXT,
        library TEXT,
        schema TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        join_condition TEXT,
        involved_tables TEXT,
        code_block TEXT,
        database_type TEXT
    );
    
    CREATE TABLE IF NOT EXISTS librefs (
        libref TEXT,
        engine TEXT,
        path TEXT,
        Source_Line INTEGER,
        full_statement TEXT,
        Source_File TEXT
    );
    '''
    conn.executescript(create_tables_sql)
    
    # Initialize DataFrames with code_block column
    all_tables = pd.DataFrame(columns=[
        'type', 'step_type', 'library', 'schema', 'table', 'Source_Line', 
        'Source_File', 'join_condition', 'code_block', 'database_type'
    ])
    all_librefs = pd.DataFrame()
    
    file_count = 0
    total_files_processed = 0
    stop_path = os.path.join(directory_path, 'a20')
    
    def write_to_db(tables_df, librefs_df, conn):
        if not tables_df.empty:
            # Rename columns to match database schema
            tables_df = tables_df.rename(columns={'table': 'table_name'})
            
            # Remove single quotes we added earlier
            for column in tables_df.columns:
                tables_df[column] = tables_df[column].apply(lambda x: x.strip("'") if isinstance(x, str) else x)
            
            # Filter out records where table_name is a SAS keyword
            tables_df = tables_df[~tables_df['table_name'].str.lower().isin(SAS_KEYWORDS)]
            
            # Write to SQLite
            tables_df.to_sql('table_lineage', conn, if_exists='append', index=False)
            print(f"Wrote {len(tables_df)} table records to database")
        
        if not librefs_df.empty:
            # Remove single quotes
            for column in librefs_df.columns:
                librefs_df[column] = librefs_df[column].apply(lambda x: x.strip("'") if isinstance(x, str) else x)
            
            # Write to SQLite
            librefs_df.to_sql('librefs', conn, if_exists='append', index=False)
            print(f"Wrote {len(librefs_df)} libref records to database")
    
    try:
        for root, dirs, files in os.walk(directory_path):
            if root.startswith(stop_path):
                print(f"Stopping at directory: {stop_path}")
                break
                
            sas_files = [f for f in files if f.endswith('.sas')]
            
            for sas_file in sas_files:
                file_path = os.path.join(root, sas_file)
                total_files_processed += 1
                print(f"Processing file {total_files_processed}: {file_path}")
                
                try:
                    df_tables, df_librefs = analyze_sas_file(file_path)
                    
                    if df_tables.empty:
                        # Store relative path for empty files
                        relative_path = os.path.relpath(file_path, start=directory_path)
                        empty_files.append(relative_path)
                    
                    if not df_tables.empty or not df_librefs.empty:
                        relative_path = os.path.relpath(file_path, start=directory_path)
                        
                        if not df_tables.empty:
                            df_tables['Source_File'] = relative_path
                            all_tables = pd.concat([all_tables, df_tables], ignore_index=True)
                        
                        if not df_librefs.empty:
                            df_librefs['Source_File'] = relative_path
                            all_librefs = pd.concat([all_librefs, df_librefs], ignore_index=True)
                        
                        file_count += 1
                        
                        # Every 100 files that HAVE data, write to database
                        if file_count % 100 == 0:
                            print(f"\nWriting batch of {file_count} files to database...")
                            print(f"Current DataFrame sizes: Tables={len(all_tables)} rows, Librefs={len(all_librefs)} rows")
                            write_to_db(all_tables, all_librefs, conn)
                            all_tables = pd.DataFrame(columns=['type', 'step_type', 'library', 'schema', 'table', 'Source_Line', 'Source_File', 'join_condition', 'code_block', 'database_type'])
                            all_librefs = pd.DataFrame()
                            conn.commit()
                            print("Memory cleared and changes committed\n")
                
                except Exception as e:
                    print(f"Error processing {file_path}: {str(e)}")
        
        # Write any remaining data
        if not all_tables.empty or not all_librefs.empty:
            print(f"\nWriting final batch to database...")
            print(f"Final batch sizes: Tables={len(all_tables)} rows, Librefs={len(all_librefs)} rows")
            write_to_db(all_tables, all_librefs, conn)
        
        # Create indices for better query performance
        print("\nCreating indices...")
        conn.execute('CREATE INDEX IF NOT EXISTS idx_library ON table_lineage(library)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table ON table_lineage(table_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_type ON table_lineage(type)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_libref ON librefs(libref)')
        
        # Remove duplicates
        print("Removing duplicates...")
        conn.execute('''
            DELETE FROM table_lineage 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM table_lineage 
                GROUP BY 
                    LOWER(type),
                    LOWER(step_type),
                    LOWER(library),
                    LOWER(table_name),
                    Source_Line,
                    Source_File
                -- Intentionally excluding code_block and join_condition from grouping
                -- to prevent duplicates with only slight differences
            )
        ''')
        conn.execute('''
            DELETE FROM librefs 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM librefs 
                GROUP BY libref, engine, path, Source_Line, full_statement, Source_File
            )
        ''')
        
        # Remove records with SAS keywords as table names
        print("Removing records with SAS keywords as table names...")
        conn.execute('''
            DELETE FROM table_lineage 
            WHERE LOWER(table_name) IN (
                ''' + ','.join(f"'{keyword}'" for keyword in SAS_KEYWORDS) + ')')
        
        conn.commit()
        print(f"\nProcessed {total_files_processed} total files")
        print(f"Found data in {file_count} files")
        print(f"Information saved to {db_path}")
        
        # Write empty files to output
        if empty_files:
            with open(empty_files_path, 'w', encoding='utf-8') as f:
                f.write(f"Found {len(empty_files)} files with no tables:\n\n")
                for file_path in sorted(empty_files):
                    f.write(f"{file_path}\n")
            print(f"\nList of files with no tables saved to {empty_files_path}")
    
    except Exception as e:
        print(f"Error during processing: {str(e)}")
    
    finally:
        conn.close()
    
    return pd.DataFrame(), pd.DataFrame()  # Return empty DataFrames since data is in DB

# Modify the test code at the bottom
if __name__ == "__main__":
    input_directory = os.path.join(paths.INPUT_PATH, directory_name)
    analyze_sas_files(input_directory)