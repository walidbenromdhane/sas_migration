CREATE TYPE foo AS (a TEXT, b TEXT);
-- <- keyword
--      ^ keyword
--              ^ keyword
--                     ^ type.builtin
--                            ^ type.builtin
