from tree_sitter import Language, Parser
from SQL_toolkit import SQLParser, ASTProcessor
import pandas as pd
import paths, os
import re
import sqlite3


# Add regex patterns
PROC_SQL_REGEX = re.compile(r"proc\s+sql\s*;(.*?)(?=\s*quit\s*;)", re.DOTALL)
CONNECT_TO_REGEX = re.compile(r'connect\s+to\s+.*?;', re.DOTALL)
SELECT_FROM_CONNECTION_REGEX = re.compile(r'select\s+.*?from\s+connection\s+to\s+\w+\s*\(', re.DOTALL)
TRAILING_PAREN_REGEX = re.compile(r'\)\s*;?\s*$')

# Add SAS keywords set
SAS_KEYWORDS = {
    'and', 'as', 'by', 'delete', 'drop', 'else', 'end', 'from', 'group', 'having',
    'if', 'in', 'into', 'join', 'left', 'like', 'not', 'null', 'on', 'or', 'order',
    'outer', 'right', 'run', 'set', 'then', 'union', 'update', 'where', 'while', 'quit'
}

def preserve_lines_replace(pattern, repl, text):
    """Replace pattern with empty lines while preserving line count"""
    def replacement(match):
        # Count newlines in the matched text
        newline_count = match.group(0).count('\n')
        # If there are newlines, return that many empty lines
        if newline_count:
            return '\n' * newline_count
        # If no newlines, return a single space to preserve the line
        return ' '
    
    return re.sub(pattern, replacement, text)

def normalize_sql(sql):
    """Normalize SQL string by cleaning up whitespace and formatting"""
    # Convert to lowercase first
    sql = sql.lower()
    
    # Replace multiple whitespace with single space
    sql = re.sub(r'\s+', ' ', sql)
    
    # Ensure single space after commas
    sql = re.sub(r',\s*', ', ', sql)
    
    # Ensure single space around operators
    sql = re.sub(r'\s*(=|\+|-|\*|/|\(|\))\s*', r' \1 ', sql)
    
    # Clean up JOIN syntax
    sql = re.sub(r'\s+JOIN\s+', ' JOIN ', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+ON\s+', ' ON ', sql, flags=re.IGNORECASE)
    
    # Clean up FROM syntax
    sql = re.sub(r'\s+FROM\s+', ' FROM ', sql, flags=re.IGNORECASE)
    
    # Remove any trailing/leading whitespace
    sql = sql.strip()
    
    return sql

def remove_comments(sql):
    """Remove SQL comments while preserving line numbers"""
    # Remove inline comments /*...*/
    sql = re.sub(r'/\*.*?\*/', '', sql)
    # Remove single-line comments --...
    sql = re.sub(r'--.*$', '', sql, flags=re.MULTILINE)
    return sql

class ColumnExtractor:
    def __init__(self):
        # Initialize parsers
        self.sas_parser = Parser()
        self.sas_parser.set_language(Language(paths.SAS_GRAMMAR_FILE, 'sas'))
        self.sql_parser = SQLParser(paths.SQL_GRAMMAR_FILE, 'sql')

    def is_valid_sas_name(self, name):
        """
        Validate if a name follows SAS naming conventions:
        - First character must be a letter (A-Z, a-z)
        - Subsequent characters can be letters, numbers, or underscore
        - No special characters except underscore
        - No blanks
        """
        if not name:
            return False
        
        # Remove single quotes if they exist (from our formatting)
        name = name.strip("'")
        
        # Check if the name contains invalid special characters
        if '=' in name or '/' in name or ' ' in name:
            return False
        
        # Regular expression for SAS naming convention
        sas_name_pattern = r'^[a-zA-Z][a-zA-Z0-9_]*$'
        return bool(re.match(sas_name_pattern, name))

    def process_data_steps(self, node):
        current_lib = 'WORK'
        current_table = None
        columns = []

        # Helper to extract library.table format
        def extract_library_table(identifier_node):
            lib = 'WORK'
            table = None
            if identifier_node.next_sibling and identifier_node.next_sibling.type == '.':
                lib = identifier_node.text.decode('utf-8')
                table = identifier_node.next_sibling.next_sibling.text.decode('utf-8')
            else:
                table = identifier_node.text.decode('utf-8')
            return lib, table

        # Process PROC statement options
        if node.type == 'proc_statement':
            for child in node.children:
                if child.type == 'data' and child.next_sibling and child.next_sibling.type == '=':
                    # Get the dataset reference after data=
                    dataset_node = child.next_sibling.next_sibling
                    if dataset_node:
                        current_lib, current_table = extract_library_table(dataset_node)

        # Process column-referencing statements
        for child in node.children:
            if child.type == 'by_statement':
                for by_child in child.children:
                    if by_child.type == 'identifier':
                        column_name = by_child.text.decode('utf-8')
                        if self.is_valid_sas_name(column_name):
                            columns.append({
                                'library': current_lib,
                                'table': current_table,
                                'column': column_name,
                                'Source_Line': by_child.start_point[0] + 1,
                                'step_type': 'BY'
                            })

            elif child.type == 'class_statement':
                for class_child in child.children:
                    if class_child.type == 'identifier':
                        column_name = class_child.text.decode('utf-8')
                        if self.is_valid_sas_name(column_name):
                            columns.append({
                                'library': current_lib,
                                'table': current_table,
                                'column': column_name,
                                'Source_Line': class_child.start_point[0] + 1,
                                'step_type': 'CLASS'
                            })

            elif child.type == 'var_statement':
                for var_child in child.children:
                    if var_child.type == 'identifier':
                        column_name = var_child.text.decode('utf-8')
                        if self.is_valid_sas_name(column_name):
                            columns.append({
                                'library': current_lib,
                                'table': current_table,
                                'column': column_name,
                                'Source_Line': var_child.start_point[0] + 1,
                                'step_type': 'VAR'
                            })

            elif child.type == 'means_statement':
                for means_child in child.children:
                    if means_child.type == 'identifier' and means_child.parent.type == 'columns':
                        column_name = means_child.text.decode('utf-8')
                        if self.is_valid_sas_name(column_name):
                            columns.append({
                                'library': current_lib,
                                'table': current_table,
                                'column': column_name,
                                'Source_Line': means_child.start_point[0] + 1,
                                'step_type': 'MEANS'
                            })

        return columns

    def analyze_sas_file(self, file_path):
        """Analyze a SAS file and extract column information"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()
            
            # Convert code to lowercase immediately after reading
            code = code.lower()
            
            # First do a quick line-by-line scan for INSERT statements
            insert_count = len(re.findall(r'insert\s+into', code))
            if insert_count > 1000:
                print(f"Skipping {file_path}: Contains {insert_count} INSERT statements (>1000)")
                return pd.DataFrame()

            # Preprocess the code to handle macro variables
            code = code.replace('&', 'MACROREPLACE')
            
            columns = []
            
            # First, process PROC SQL blocks
            sql_blocks = PROC_SQL_REGEX.finditer(code)
            
            # Process each SQL block
            for match in sql_blocks:
                sql_content = match.group(1)
                line_num = code[:match.start()].count('\n') + 1
                
                # Remove comments first
                sql_content = remove_comments(sql_content)
                
                # Clean up in specific order:
                cleaned_sql = sql_content
                
                # 1. Remove CONNECT TO statements
                cleaned_sql = preserve_lines_replace(CONNECT_TO_REGEX, '', cleaned_sql)
                
                # 2. Remove SELECT ... FROM CONNECTION TO ... (
                cleaned_sql = preserve_lines_replace(SELECT_FROM_CONNECTION_REGEX, '', cleaned_sql)
                
                # 3. Remove trailing parenthesis
                cleaned_sql = preserve_lines_replace(TRAILING_PAREN_REGEX, '', cleaned_sql)
                
                # Clean up whitespace and empty lines
                cleaned_sql = '\n'.join(line.strip() for line in cleaned_sql.splitlines() if line.strip())

                # Split the SQL content into individual statements
                statements = []
                current_statement = []
                paren_count = 0
                quote_char = None
                
                for char in cleaned_sql:
                    if char in ["'", '"'] and (not quote_char or char == quote_char):
                        quote_char = None if quote_char else char
                    
                    if not quote_char:
                        if char == '(':
                            paren_count += 1
                        elif char == ')':
                            paren_count -= 1
                    
                    if char == ';' and paren_count == 0 and not quote_char:
                        current_statement = ''.join(current_statement).strip()
                        if current_statement:
                            statements.append(current_statement)
                        current_statement = []
                        continue
                    
                    current_statement.append(char)
                
                current_statement = ''.join(current_statement).strip()
                if current_statement:
                    statements.append(current_statement)
                
                for statement in statements:
                    normalized_sql = normalize_sql(statement)
                    sql_tree = self.sql_parser.parse(normalized_sql)
                    sql_processor = ASTProcessor(normalized_sql)
                    sql_processor.traverse_tree(sql_tree.root_node)
                    
                    if not sql_processor.columns_df.empty:
                        for _, row in sql_processor.columns_df.iterrows():
                            column_name = row['Column']
                            if (self.is_valid_sas_name(column_name) and 
                                column_name.lower() not in SAS_KEYWORDS):
                                columns.append({
                                    'library': row['Library'] if row['Library'] else 'WORK',
                                    'table': row['Table'],
                                    'column': column_name,
                                    'Source_Line': line_num,
                                    'step_type': 'PROC SQL'
                                })
            
            # Then process non-SQL statements using tree-sitter
            tree = self.sas_parser.parse(bytes(code, 'utf8'))
            
            def traverse_tree(node):
                if node.type == 'data_step':
                    columns.extend(self.process_data_steps(node))
                elif node.type == 'proc_statement':
                    columns.extend(self.process_data_steps(node))
                for child in node.children:
                    traverse_tree(child)
            
            traverse_tree(tree.root_node)
            
            # Convert to DataFrame
            df_columns = pd.DataFrame(columns)
            
            # Filter out SAS keywords and connection library entries
            if not df_columns.empty:
                df_columns = df_columns[
                    (df_columns['library'].str.lower() != 'connection') &
                    (~df_columns['column'].str.lower().isin(SAS_KEYWORDS))
                ]
                df_columns = df_columns.dropna(subset=['column'])
                df_columns = df_columns[df_columns['column'].str.strip() != "'"]
                df_columns = df_columns.sort_values(['library', 'table', 'column'])
            
            # Convert to lowercase before adding quotes
            if not df_columns.empty:
                for column in df_columns.columns:
                    df_columns[column] = df_columns[column].apply(lambda x: str(x).lower() if pd.notnull(x) else x)
                
                # Add single quote prefix to all string values
                for column in df_columns.columns:
                    df_columns[column] = df_columns[column].apply(lambda x: f"'{str(x)}" if pd.notnull(x) else x)
                
                df_columns = df_columns.dropna(subset=['column'])
                df_columns = df_columns.sort_values(['library', 'table', 'column'])
            
            return df_columns
            
        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")
            return pd.DataFrame()

def analyze_files_for_columns(directory_path, db_path):
    """Analyze multiple SAS files in a directory and its subdirectories for columns."""
    extractor = ColumnExtractor()
    all_columns = pd.DataFrame()
    file_count = 0
    total_files_processed = 0
    
    # Initialize tracking dictionaries
    error_files = {}  # Will store filename: error message
    empty_files = []  # Will store filenames with no columns
    
    # Initialize SQLite database
    conn = sqlite3.connect(db_path)
    
    # Create table if it doesn't exist
    create_table_sql = '''
    CREATE TABLE IF NOT EXISTS sas_columns (
        library TEXT,
        table_name TEXT,
        column_name TEXT,
        Source_Line INTEGER,
        step_type TEXT,
        Source_File TEXT
    )
    '''
    conn.execute(create_table_sql)
    
    def write_to_db(df, conn):
        if not df.empty:
            # Rename columns to match the database schema
            df = df.rename(columns={
                'table': 'table_name',
                'column': 'column_name'
            })
            
            # Remove the single quote prefix we added earlier
            for column in df.columns:
                df[column] = df[column].apply(lambda x: x.strip("'") if isinstance(x, str) else x)
            
            # Write to SQLite
            df.to_sql('sas_columns', conn, if_exists='append', index=False)
            print(f"Wrote {len(df)} records to database")
    
    try:
        for root, dirs, files in os.walk(directory_path):
            sas_files = [f for f in files if f.endswith('.sas')]
            
            for sas_file in sas_files:
                file_path = os.path.join(root, sas_file)
                total_files_processed += 1
                print(f"Processing file {total_files_processed}: {file_path}")
                
                try:
                    df_columns = extractor.analyze_sas_file(file_path)
                    
                    if df_columns.empty:
                        relative_path = os.path.relpath(file_path, start=directory_path)
                        empty_files.append(relative_path)
                    else:
                        relative_path = os.path.relpath(file_path, start=directory_path)
                        df_columns['Source_File'] = relative_path
                        all_columns = pd.concat([all_columns, df_columns], ignore_index=True)
                        
                        file_count += 1
                        print(f"Found {len(df_columns)} columns in this file. Total files with columns: {file_count}")
                        
                        # Every 100 files that HAVE columns, write to database
                        if file_count % 100 == 0:
                            print(f"\nWriting batch of {file_count} files to database...")
                            print(f"Current DataFrame size: {len(all_columns)} rows")
                            write_to_db(all_columns, conn)
                            all_columns = pd.DataFrame()  # Clear the DataFrame
                            conn.commit()  # Commit the transaction
                            print("Memory cleared and changes committed\n")
                
                except Exception as e:
                    relative_path = os.path.relpath(file_path, start=directory_path)
                    error_files[relative_path] = str(e)
                    print(f"Error processing {file_path}: {str(e)}")
        
        # Write any remaining data
        if not all_columns.empty:
            print(f"\nWriting final batch to database...")
            print(f"Final batch size: {len(all_columns)} rows")
            write_to_db(all_columns, conn)
        
        # Create indices for better query performance
        print("\nCreating indices...")
        conn.execute('CREATE INDEX IF NOT EXISTS idx_library ON sas_columns(library)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table ON sas_columns(table_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_column ON sas_columns(column_name)')
        
        # Remove duplicates with improved deduplication
        print("Removing duplicates...")
        conn.execute('''
            DELETE FROM sas_columns 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sas_columns 
                GROUP BY 
                    lower(library), 
                    lower(table_name), 
                    lower(column_name), 
                    Source_Line, 
                    step_type, 
                    lower(Source_File)
            )
        ''')
        
        conn.commit()
        
        # Write error and empty file logs
        log_dir = os.path.dirname(db_path)
        
        # Write error log
        error_log_path = os.path.join(log_dir, "column_extraction_errors.log")
        with open(error_log_path, 'w') as f:
            f.write(f"Processing completed at: {pd.Timestamp.now()}\n")
            f.write(f"Total files processed: {total_files_processed}\n")
            f.write(f"Files with errors: {len(error_files)}\n\n")
            for file, error in error_files.items():
                f.write(f"File: {file}\nError: {error}\n\n")
        
        # Write empty files log
        empty_log_path = os.path.join(log_dir, "files_without_columns.log")
        with open(empty_log_path, 'w') as f:
            f.write(f"Processing completed at: {pd.Timestamp.now()}\n")
            f.write(f"Total files processed: {total_files_processed}\n")
            f.write(f"Files without columns: {len(empty_files)}\n\n")
            for file in empty_files:
                f.write(f"{file}\n")
        
        print(f"\nProcessed {total_files_processed} total files")
        print(f"Found columns in {file_count} files")
        print(f"Files with errors: {len(error_files)}")
        print(f"Files without columns: {len(empty_files)}")
        print(f"Column information saved to {db_path}")
        print(f"Error log saved to {error_log_path}")
        print(f"Empty files log saved to {empty_log_path}")
    
    except Exception as e:
        print(f"Error during processing: {str(e)}")
    
    finally:
        conn.close()

if __name__ == "__main__":
    input_directory = os.path.join(paths.INPUT_PATH, "smu")
    db_file = os.path.join(paths.OUTPUT_PATH, "columns.db")
    analyze_files_for_columns(input_directory, db_file)
