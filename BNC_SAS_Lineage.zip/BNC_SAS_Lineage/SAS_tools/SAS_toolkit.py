from tree_sitter import Language, Parser
import pandas as pd
from SQL_toolkit import SQLParser, ASTProcessor 
import paths, os

class SASParser:
    def __init__(self, language_path, language_name):
        self.language = Language(language_path, language_name)
        self.parser = Parser()
        self.parser.set_language(self.language)

    def parse(self, sas_code):
        return self.parser.parse(bytes(sas_code, "utf8"))


class SASASTProcessor:
    def __init__(self, sas_code, sql_language_path, sql_language_name):
        self.sas_code = sas_code
        self.sql_language_path = sql_language_path
        self.sql_language_name = sql_language_name
        self.df = pd.DataFrame(columns=["Table", "Operation", "Involved Tables", "Condition", "Input/Output"])

    def traverse_tree(self, node, current_table=None, previous_tables=[]):
        """
        Recursively traverse the AST to extract relevant information.
        """
        if node.type == "data_step":
            self._handle_data_step(node)
        elif node.type == "proc_step":
            self._handle_proc_step(node)
        elif node.type == "set_statement":
            self._handle_set(node)

        # Recursively traverse children
        for child in node.children:
            self.traverse_tree(child, current_table, previous_tables)

    def _handle_data_step(self, node):
        """
        Handle DATA step nodes and extract output tables.
        """
        data_table = None
        for child in node.children:
            if child.type == "identifier":
                data_table = self._extract_text(child)
        if data_table:
            self._add_to_dataframe(data_table, "DATA", input_output="Output")

    def _handle_proc_step(self, node):
        """
        Handle PROC step nodes and extract procedure details.
        """
        procedure = None
        table = None
        sql_code = None
        for child in node.children:
            if child.type == "identifier":
                if procedure is None:
                    procedure = self._extract_text(child)
                else:
                    table = self._extract_text(child)
            elif child.type == "sql_block":
                sql_code = self._extract_text(child)

        if procedure:
            if procedure.upper() == "SQL":
                # Use sql_toolkit to parse the SQL code
                self._handle_proc_sql(sql_code)
            else:
                self._add_to_dataframe(table if table else " ", procedure.upper(), input_output="Output")

    def _handle_proc_sql(self, sql_code):
        """
        Handle PROC SQL using the sql_toolkit module.
        """
        sql_parser = SQLParser(self.sql_language_path, self.sql_language_name)
        tree = sql_parser.parse(sql_code)
        processor = ASTProcessor(sql_code)
        processor.traverse_tree(tree.root_node)

        # Append the SQL parser's DataFrame rows to the main DataFrame
        for _, row in processor.df.iterrows():
            self.df = pd.concat([self.df, pd.DataFrame([row])], ignore_index=True)

    def _handle_set(self, node):
        """
        Handle SET statements to extract input tables.
        """
        set_table = None
        for child in node.children:
            if child.type == "identifier":
                set_table = self._extract_text(child)
        if set_table:
            self._add_to_dataframe(set_table, "DATA", input_output="Input")

    def _extract_text(self, node):
        """
        Helper function to extract the text representation of a node.
        """
        return self.sas_code[node.start_byte:node.end_byte]

    def _add_to_dataframe(self, table, operation, involved_tables=None, condition=None, input_output="Output"):
        """
        Add extracted information to the main DataFrame.
        """
        self.df = pd.concat(
            [self.df, pd.DataFrame([{
                "Table": table,
                "Operation": operation,
                "Involved Tables": involved_tables,
                "Condition": condition,
                "Input/Output": input_output
            }])],
            ignore_index=True
        )

    def save_to_excel(self, filename):
        """
        Save the main DataFrame to an Excel file.
        """
        with pd.ExcelWriter(filename, engine="openpyxl") as writer:
            # Save the main DataFrame
            self.df.to_excel(writer, index=False, sheet_name="Main")


# Main Program
if __name__ == "__main__":
    SAS_LANGUAGE_PATH = paths.SAS_GRAMMAR_FILE
    SAS_LANGUAGE_NAME = "sas"
    SQL_LANGUAGE_PATH = paths.SQL_GRAMMAR_FILE
    SQL_LANGUAGE_NAME = "sql"

    SAS_CODE = """
    DATA lib.tablename;
        SET lib.tablename2;
    RUN;

    PROC MEANS DATA=lib.tablename;
    RUN;

    PROC FREQ DATA=lib.tablename4;
    RUN;

    PROC PRINT DATA=lib.tablename4;
    RUN;

    PROC SQL;
        CREATE TABLE sql_table AS
        SELECT * FROM some_table;
    QUIT;
    """

    # Parse and process the SAS code
    parser = SASParser(SAS_LANGUAGE_PATH, SAS_LANGUAGE_NAME)
    tree = parser.parse(SAS_CODE)
    processor = SASASTProcessor(SAS_CODE, SQL_LANGUAGE_PATH, SQL_LANGUAGE_NAME)
    processor.traverse_tree(tree.root_node)

    # Save results to an Excel file
    output_file_location = os.paths.join(paths.OUTPUT_PATH,"output_sas.xlsx")
    processor.save_to_excel(output_file_location)
