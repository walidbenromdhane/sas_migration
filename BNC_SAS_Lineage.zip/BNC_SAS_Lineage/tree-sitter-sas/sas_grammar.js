module.exports = grammar({
  name: 'sas',

  extras: $ => [
    /\s/,
    $.comment,
  ],

  rules: {
    source_file: $ => repeat($._statement),

    _statement: $ => choice(
      $.data_step,
      $.proc_step,
      $.macro_definition,
      $.macro_call,
      $.macro_variable,
      $.assignment_statement,
      $.if_statement,
      $.do_loop,
      $.array_statement,
      $.input_statement,
      $.put_statement,
      $.set_statement,
      $.merge_statement,
      $.by_statement,
      $.where_statement,
      $.format_statement,
      $.informat_statement,
      $.length_statement,
      $.label_statement,
      $.retain_statement,
      $.keep_statement,
      $.drop_statement,
      $.call_statement,
      $.x_command,
      $.options_statement,
      $.title_statement,
      $.footnote_statement,
      $.libname_statement,
      $.filename_statement,
      $.ods_statement,
      $.global_statement,
      $.error_statement,
      $.abort_statement,
      $.goto_statement,
      $.return_statement,
      $.stop_statement,
      $.endsas_statement
    ),

	data_step: $ => seq(
	  $.DATA,
	  repeat($.identifier),
	  ';',
	  repeat($._statement),
	  $.RUN,
	  ';'
	),
	
	proc_step: $ => seq(
    $.PROC,
    field('name', $.proc_type),
    optional(repeat($.option)),
    ';',
    repeat($._statement),
    choice(
      seq($.RUN, ';'),
      seq($.QUIT, ';')
    )
  ),

  proc_type: $ => choice(
    'SORT',
    'PRINT',
    'MEANS',
    'FREQ',
    'SQL',
    'REPORT',
    'TABULATE',
    'UNIVARIATE',
    'GLM',
    'REG',
    'LOGISTIC',
    'MIXED',
    'TRANSPOSE',
    'APPEND',
    'COPY',
    'DATASETS',
    'FORMAT',
    'IMPORT',
    'EXPORT',
    'CONTENTS',
    'CORR',
    'FACTOR',
    'CLUSTER',
    'TEMPLATE',
    'SGPLOT',
    'SGPANEL',
    'SGSCATTER',
    $.identifier
  ),
  
  

    macro_definition: $ => seq(
      $.PERCENT_MACRO,
      $.identifier,
      optional(seq('(', optional($.macro_parameters), ')')),
      ';',
      repeat($._statement),
      $.PERCENT_MEND,
      optional($.identifier),
      ';'
    ),

    macro_call: $ => seq(
      '%',
      $.identifier,
      optional(seq('(', optional($.macro_arguments), ')')),
      ';'
    ),

    macro_parameters: $ => seq($.identifier, repeat(seq(',', $.identifier))),

    macro_arguments: $ => seq($.expression, repeat(seq(',', $.expression))),

    assignment_statement: $ => seq(
      $.identifier,
      '=',
      $.expression,
      ';'
    ),

	if_statement: $ => prec.right(seq(
	  $.IF,
	  $.expression,
	  $.THEN,
	  $._statement,
	  optional(seq($.ELSE, $._statement))
	)),

    do_loop: $ => seq(
      $.DO,
      optional(choice(
        seq($.identifier, '=', $.expression, $.TO, $.expression, optional(seq($.BY, $.expression))),
        $.WHILE_CONDITION,
        $.UNTIL_CONDITION
      )),
      ';',
      repeat($._statement),
      $.END,
      ';'
    ),

    array_statement: $ => seq(
      $.ARRAY,
      $.identifier,
      optional(seq('[' , $.number, ']')),
      optional($.array_elements),
      ';'
    ),

    input_statement: $ => seq(
      $.INPUT,
      repeat($.input_variable),
      ';'
    ),

    input_variable: $ => seq(
      $.identifier,
      optional(seq(':', $.informat_specification))
    ),

    informat_specification: $ => seq(
      $.format_name,
      '.',
      optional($.number),
      optional(seq('.', $.number))
    ),

	put_statement: $ => seq(
	  $.PUT,
	  repeat1(choice(
		prec(3, $.put_item),
		$.string,
		$.column_specification,
		$.line_control,
		$.format_specification
	  )),
	  ';'
	),

	put_item: $ => prec.left(3, choice(
	  $.expression,
	  $.identifier,
	  '_INFILE_',
	  '_ALL_',
	  '_ODS_'
	)),

	column_specification: $ => choice(
	  '@number',
	  '@@',
	  '+number'
	),

	line_control: $ => choice(
	  '/',
	  '_PAGE_'
	),

	expression: $ => prec.left(1, choice(
	  $.binary_expression,
	  $.function_call,
	  $.macro_variable,
	  $.number,
	  $.string,
	  $.identifier,
	  $.parenthetical_expression
	)),

	binary_expression: $ => prec.left(1, seq(
	  $.expression,
	  $.operator,
	  $.expression
	)),


	function_call: $ => prec.left(2, seq(
	  $.identifier,
	  '(',
	  optional($.arguments),
	  ')'
	)),


	parenthetical_expression: $ => prec.left(1, seq(
	  '(',
	  $.expression,
	  ')'
	)),
	
	
    operator: $ => choice(
      '+', '-', '*', '/', '**', '=', '>', '<', '>=', '<=', '<>', '^=', '~=', '¬=', 'AND', 'OR', 'NOT', 'IN'
    ),

    arguments: $ => seq($.expression, repeat(seq(',', $.expression))),

    set_statement: $ => seq(
      $.SET,
      repeat($.dataset_name),
      ';'
    ),

    merge_statement: $ => seq(
      $.MERGE,
      repeat($.dataset_name),
      ';'
    ),

    by_statement: $ => seq(
      $.BY,
      repeat($.identifier),
      ';'
    ),

    where_statement: $ => seq(
      $.WHERE,
      $.expression,
      ';'
    ),

    format_statement: $ => seq(
      $.FORMAT,
      repeat(seq($.identifier, $.format_specification)),
      ';'
    ),
	
	format_specification: $ => prec.left(1, seq(
	  $.format_name,
	  '.',
	  optional($.number),
	  optional(seq('.', $.number))
	)),
	
	format_name: $ => /[a-zA-Z_][a-zA-Z0-9_]*/,


    informat_statement: $ => seq(
      $.INFORMAT,
      repeat(seq($.identifier, $.informat_specification)),
      ';'
    ),

    length_statement: $ => seq(
      $.LENGTH,
      repeat(seq($.identifier, $.length_specification)),
      ';'
    ),

    length_specification: $ => choice(
      $.number,
      seq('$', $.number)
    ),

    label_statement: $ => seq(
      $.LABEL,
      repeat(seq($.identifier, '=', $.string)),
      ';'
    ),

    retain_statement: $ => seq(
      $.RETAIN,
      repeat($.identifier),
      ';'
    ),

    keep_statement: $ => seq(
      $.KEEP,
      repeat($.identifier),
      ';'
    ),

    drop_statement: $ => seq(
      $.DROP,
      repeat($.identifier),
      ';'
    ),

    options_statement: $ => seq(
      $.OPTIONS,
      repeat($.option),
      ';'
    ),

    option: $ => seq($.identifier, optional(seq('=', $.expression))),

    title_statement: $ => seq(
      $.TITLE,
      optional($.number),
      $.string,
      ';'
    ),

    footnote_statement: $ => seq(
      $.FOOTNOTE,
      optional($.number),
      $.string,
      ';'
    ),

    libname_statement: $ => seq(
      $.LIBNAME,
      $.identifier,
      $.path,
      optional(repeat($.libname_option)),
      ';'
    ),

    libname_option: $ => seq($.identifier, optional(seq('=', $.expression))),

    filename_statement: $ => seq(
      $.FILENAME,
      $.identifier,
      $.path,
      optional(repeat($.filename_option)),
      ';'
    ),

    filename_option: $ => seq($.identifier, optional(seq('=', $.expression))),

    ods_statement: $ => seq(
      $.ODS,
      $.identifier,
      repeat($.ods_option),
      ';'
    ),

    ods_option: $ => seq($.identifier, optional(seq('=', $.expression))),


    quit_statement: $ => seq(
      $.QUIT,
      ';'
    ),

    global_statement: $ => seq(
      $.GLOBAL,
      repeat($.identifier),
      ';'
    ),

    error_statement: $ => seq(
      $.ERROR,
      optional($.string),
      ';'
    ),

    abort_statement: $ => seq(
      $.ABORT,
      optional($.abort_options),
      ';'
    ),

    abort_options: $ => repeat1(choice($.identifier, $.string)),

    goto_statement: $ => seq(
      $.GOTO,
      $.identifier,
      ';'
    ),

    return_statement: $ => seq(
      $.RETURN,
      ';'
    ),

    stop_statement: $ => seq(
      $.STOP,
      ';'
    ),

    endsas_statement: $ => seq(
      $.ENDSAS,
      ';'
    ),

    call_statement: $ => seq(
      $.CALL,
      $.call_routine_name,
      optional(seq('(', optional($.arguments), ')')),
      ';'
    ),

    call_routine_name: $ => $.identifier,

    x_command: $ => seq(
      $.X,
      optional($.command),
      ';'
    ),

    command: $ => repeat1(choice(
      /[^;&]+/,
      $.macro_variable,
      '&'
    )),

    macro_variable: $ => seq(
      '&',
      $.identifier,
      optional('.')
    ),

    array_elements: $ => seq(
      '(',
      repeat1($.identifier),
      ')'
    ),

    dataset_name: $ => seq(
      optional(seq($.libref, '.')),
      $.identifier
    ),

    libref: $ => $.identifier,

    path: $ => $.string,

    WHILE_CONDITION: $ => seq($.WHILE, '(', $.expression, ')'),

    UNTIL_CONDITION: $ => seq($.UNTIL, '(', $.expression, ')'),

    function_name: $ => $.identifier,

    identifier: $ => /[a-zA-Z_][a-zA-Z0-9_]*/,

    number: $ => /\d+(\.\d+)?([eE][+-]?\d+)?/,

    string: $ => choice(
      seq(
        '"',
        repeat(choice(
          /[^"&]+/,
          $.macro_variable,
          '&'
        )),
        '"'
      ),
      seq(
        "'",
        repeat(choice(
          /[^'&]+/,
          $.macro_variable,
          '&'
        )),
        "'"
      )
    ),

    comment: $ => token(choice(
      seq('/*', /[^*]*\*+([^/*][^*]*\*+)*/, '/'),
      seq('*', /[^\n]*\n/)
    )),

    // Reserved Keywords
    DATA: $ => token(/DATA/i),
    PROC: $ => token(/PROC/i),
    RUN: $ => token(/RUN/i),
    QUIT: $ => token(/QUIT/i),
    PERCENT_LET: $ => token(/%LET/i),
    PERCENT_MACRO: $ => token(/%MACRO/i),
    PERCENT_MEND: $ => token(/%MEND/i),
    CALL: $ => token(/CALL/i),
    X: $ => token(/X/i),
    IF: $ => token(/IF/i),
    THEN: $ => token(/THEN/i),
    ELSE: $ => token(/ELSE/i),
    DO: $ => token(/DO/i),
    END: $ => token(/END/i),
    ARRAY: $ => token(/ARRAY/i),
    INPUT: $ => token(/INPUT/i),
    PUT: $ => token(/PUT/i),
    SET: $ => token(/SET/i),
    MERGE: $ => token(/MERGE/i),
    BY: $ => token(/BY/i),
    WHERE: $ => token(/WHERE/i),
    FORMAT: $ => token(/FORMAT/i),
    INFORMAT: $ => token(/INFORMAT/i),
    LENGTH: $ => token(/LENGTH/i),
    LABEL: $ => token(/LABEL/i),
    RETAIN: $ => token(/RETAIN/i),
    KEEP: $ => token(/KEEP/i),
    DROP: $ => token(/DROP/i),
    OPTIONS: $ => token(/OPTIONS/i),
    TITLE: $ => token(/TITLE\d*/i),
    FOOTNOTE: $ => token(/FOOTNOTE\d*/i),
    LIBNAME: $ => token(/LIBNAME/i),
    FILENAME: $ => token(/FILENAME/i),
    ODS: $ => token(/ODS/i),
    GLOBAL: $ => token(/GLOBAL/i),
    ERROR: $ => token(/ERROR/i),
    ABORT: $ => token(/ABORT/i),
    GOTO: $ => token(/GOTO/i),
    RETURN: $ => token(/RETURN/i),
    STOP: $ => token(/STOP/i),
    ENDSAS: $ => token(/ENDSAS/i),
    WHILE: $ => token(/WHILE/i),
    UNTIL: $ => token(/UNTIL/i),
    AND: $ => token(/AND/i),
    OR: $ => token(/OR/i),
    NOT: $ => token(/NOT/i),
    IN: $ => token(/IN/i),
    TO: $ => token(/TO/i),
    BY_KEYWORD: $ => token(/BY/i),
    SELECT: $ => token(/SELECT/i),
    WHEN: $ => token(/WHEN/i),
    OTHERWISE: $ => token(/OTHERWISE/i),
    OUTPUT: $ => token(/OUTPUT/i),
    DELETE: $ => token(/DELETE/i),
    UPDATE: $ => token(/UPDATE/i),
    MODIFY: $ => token(/MODIFY/i),
    SET: $ => token(/SET/i)
  }
});
