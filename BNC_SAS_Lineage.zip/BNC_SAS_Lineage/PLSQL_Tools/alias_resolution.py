import os
import sqlite3
import re
import time

# Get the parent directory of the Git repository
script_dir = os.path.dirname(os.path.abspath(__file__))
GIT_PARENT_PATH = os.path.dirname(os.path.dirname(script_dir))

# Path to the lineage database
DB_PATH = os.path.join(GIT_PARENT_PATH, "outputs", "plsql_lineage.db")

def resolve_aliases():
    """
    Resolves table aliases in the lineage database.
    For each row in sql_columns where table_name is 1-2 characters,
    it looks up the actual table name from the code_block and updates the database.
    """
    start_time = time.time()
    
    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Start a transaction
    conn.execute("BEGIN TRANSACTION")
    
    # Get all rows where table_name is 1 or 2 characters
    cursor.execute("""
        SELECT column_name, table_name, Source_Line, Source_File, code_block 
        FROM sql_columns 
        WHERE LENGTH(table_name) BETWEEN 1 AND 2
    """)
    
    rows = cursor.fetchall()
    print(f"Found {len(rows)} rows with potential aliases")
    
    # Prepare batch updates
    updates_count = 0
    
    # Compile regex patterns once (outside the loop)
    patterns = [
        # Standard SQL patterns
        re.compile(r'from\s+(\w+(?:\.\w+)?)\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'from\s+(\w+(?:\.\w+)?)\s+as\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'join\s+(\w+(?:\.\w+)?)\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'join\s+(\w+(?:\.\w+)?)\s+as\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'using\s+(\w+(?:\.\w+)?)\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'using\s+(\w+(?:\.\w+)?)\s+as\s+(\w{1,2})[\s,)]', re.IGNORECASE),
        re.compile(r'merge\s+into\s+\w+\s+\w+\s+using\s+(\w+(?:\.\w+)?)\s+(\w{1,2})', re.IGNORECASE),
        
        # Oracle-style comma-separated joins with schema
        re.compile(r'from\s+(?:.*?,\s*)?(\w+(?:\.\w+)?)\s+(\w{1,2})(?:\s*\(\+\))?[\s,)]', re.IGNORECASE),
        re.compile(r'from\s+(?:.*?,\s*)?schema\.(\w+)\s+(\w{1,2})(?:\s*\(\+\))?[\s,)]', re.IGNORECASE),
        re.compile(r'from\s+(?:.*?,\s*)?(\w+)\.(\w+)\s+(\w{1,2})(?:\s*\(\+\))?[\s,)]', re.IGNORECASE),
        
        # Specific pattern for comma-separated joins
        re.compile(r'from\s+.*?(\w+(?:\.\w+)?)\s+(\w{1,2})(?:\s*\(\+\))?[\s,)]', re.IGNORECASE),
    ]
    
    # Process in batches of 100
    batch_size = 100
    batch_updates = []
    
    for column_name, alias, source_line, source_file, code_block in rows:
        if not code_block:
            continue
            
        actual_table = None
        
        # Special handling for Oracle-style comma joins
        comma_join_pattern = re.compile(r'from\s+(.*?)\s+where', re.IGNORECASE | re.DOTALL)
        comma_join_match = comma_join_pattern.search(code_block)
        
        if comma_join_match:
            from_clause = comma_join_match.group(1)
            # Look for patterns like "schema.table a, schema.table b"
            table_aliases = re.findall(r'(\w+(?:\.\w+)?)\s+(\w{1,2})(?:\s*\(\+\))?', from_clause)
            
            for table, table_alias in table_aliases:
                if table_alias.lower() == alias.lower():
                    actual_table = table
                    break
        
        # If not found in comma join, try all other patterns
        if not actual_table:
            for pattern in patterns:
                for match in pattern.finditer(code_block):
                    # Check if the last group matches our alias
                    groups = match.groups()
                    if len(groups) >= 2 and groups[-1].lower() == alias.lower():
                        # If we have a schema.table pattern, use the table part
                        if len(groups) >= 3 and '.' not in groups[-2]:
                            actual_table = f"{groups[-3]}.{groups[-2]}"
                        else:
                            actual_table = groups[-2]
                        break
                if actual_table:
                    break
        
        # If still not found, try a more generic approach
        if not actual_table:
            # This pattern specifically looks for the alias we're trying to resolve
            specific_pattern = re.compile(rf'(\w+(?:\.\w+)?)\s+(?:as\s+)?{re.escape(alias)}[\s,)]', re.IGNORECASE)
            match = specific_pattern.search(code_block)
            if match:
                actual_table = match.group(1)
        
        if actual_table:
            # Only print every 10th update to reduce console output
            if updates_count % 10 == 0:
                print(f"Resolving alias '{alias}' to table '{actual_table}' for column '{column_name}'")
            
            # Add to batch updates
            batch_updates.append((actual_table, column_name, alias, source_line, source_file))
            updates_count += 1
            
            # Execute batch if we've reached batch size
            if len(batch_updates) >= batch_size:
                cursor.executemany("""
                    UPDATE sql_columns
                    SET table_name = ?
                    WHERE column_name = ? AND table_name = ? AND Source_Line = ? AND Source_File = ?
                """, batch_updates)
                batch_updates = []
    
    # Execute any remaining updates
    if batch_updates:
        cursor.executemany("""
            UPDATE sql_columns
            SET table_name = ?
            WHERE column_name = ? AND table_name = ? AND Source_Line = ? AND Source_File = ?
        """, batch_updates)
    
    # Commit changes and close connection
    conn.commit()
    end_time = time.time()
    print(f"Updated {updates_count} rows with resolved table names")
    print(f"Execution time: {end_time - start_time:.2f} seconds")
    conn.close()

if __name__ == "__main__":
    print("Starting alias resolution...")
    resolve_aliases()
    print("Alias resolution completed")
