import pandas as pd
import os
import glob

def combine_excel_files(directory_path, output_file):
    # Initialize empty DataFrames for each sheet
    combined_sheet1 = pd.DataFrame()
    combined_sheet3 = pd.DataFrame()
    
    # Get all Excel files in the directory
    excel_files = glob.glob(os.path.join(directory_path, '*part*.xlsx'))
    excel_files.sort()  # Sort to ensure consistent order
    
    print(f"Found {len(excel_files)} Excel files to combine")
    
    # Process each file
    for file in excel_files:
        print(f"Processing {file}")
        try:
            # Read sheet 1 and 3
            sheet1 = pd.read_excel(file, sheet_name=0)
            sheet3 = pd.read_excel(file, sheet_name=2)  # 0-based index, so 2 is the third sheet
            
            # Concatenate to combined DataFrames
            combined_sheet1 = pd.concat([combined_sheet1, sheet1], ignore_index=True)
            combined_sheet3 = pd.concat([combined_sheet3, sheet3], ignore_index=True)
            
        except Exception as e:
            print(f"Error processing {file}: {str(e)}")
    
    # Write combined data to new Excel file
    try:
        with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
            combined_sheet1.to_excel(writer, sheet_name='Table Lineage', index=False)
            combined_sheet3.to_excel(writer, sheet_name='Librefs', index=False)
        print(f"Successfully created combined file: {output_file}")
        
    except Exception as e:
        print(f"Error writing combined file: {str(e)}")

if __name__ == "__main__":
    # Example usage
    input_dir = ""
    output_file = ""
    combine_excel_files(input_dir, output_file)
