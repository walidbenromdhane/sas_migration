from tree_sitter import Language, Parser
import pandas as pd
import paths
import os
import re
import sqlite3

def normalize_table_name(table_ref):
    """Normalize table reference by extracting schema and table name"""
    if not isinstance(table_ref, str):
        return None, None
    
    parts = table_ref.strip('"').strip("'").split('.')
    if len(parts) > 1:
        return parts[-2], parts[-1]
    return None, parts[0]

def extract_table_info(node, file_path, code_lines):
    """Extract table information from a node"""
    tables = []
    
    # Get the entire procedure's code block if available
    procedure_node = node
    while procedure_node and procedure_node.type not in ['procedure_definition', 'source_file']:
        procedure_node = procedure_node.parent
    
    full_code_block = procedure_node.text.decode('utf-8') if procedure_node else node.text.decode('utf-8')
    
    # Handle CREATE TABLE statements
    if node.type == 'statement':
        has_create = False
        has_table = False
        for child in node.children:
            if child.type == 'kw_create':
                has_create = True
            elif child.type == 'kw_table':
                has_table = True
            elif has_create and has_table and child.type == 'ref_call':
                for subchild in child.children:
                    if subchild.type == 'referenced_element':
                        for ref_child in subchild.children:
                            if ref_child.type == 'identifier':
                                table_ref = ref_child.text.decode('utf-8')
                                schema, table = normalize_table_name(table_ref)
                                tables.append({
                                    'type': 'output',
                                    'operation': 'CREATE TABLE',
                                    'schema': schema,
                                    'table_name': table,
                                    'Source_Line': ref_child.start_point[0] + 1,
                                    'Source_File': file_path,
                                    'code_block': full_code_block
                                })
                                return tables  # Exit early once we find the table name
    
    # Handle SQL statements
    elif node.type == 'sql_statement_insert':
        for child in node.children:
            if child.type == 'single_table_insert':
                for subchild in child.children:
                    if subchild.type == 'referenced_element':
                        table_ref = subchild.text.decode('utf-8')
                        schema, table = normalize_table_name(table_ref)
                        tables.append({
                            'type': 'output',
                            'operation': 'INSERT',
                            'schema': schema,
                            'table_name': table,
                            'Source_Line': subchild.start_point[0] + 1,
                            'Source_File': file_path,
                            'code_block': full_code_block
                        })
    
    elif node.type == 'sql_statement_update':
        for child in node.children:
            if child.type == 'referenced_element':
                table_ref = child.text.decode('utf-8')
                schema, table = normalize_table_name(table_ref)
                tables.append({
                    'type': 'output',
                    'operation': 'UPDATE',
                    'schema': schema,
                    'table_name': table,
                    'Source_Line': child.start_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': full_code_block
                })
    
    elif node.type == 'sql_statement_delete':
        for child in node.children:
            if child.type == 'referenced_element':
                table_ref = child.text.decode('utf-8')
                schema, table = normalize_table_name(table_ref)
                tables.append({
                    'type': 'output',
                    'operation': 'DELETE',
                    'schema': schema,
                    'table_name': table,
                    'Source_Line': child.start_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': full_code_block
                })
    
    elif node.type == 'sql_statement_merge':
        for child in node.children:
            if child.type == 'referenced_element':
                table_ref = child.text.decode('utf-8')
                schema, table = normalize_table_name(table_ref)
                tables.append({
                    'type': 'output',
                    'operation': 'MERGE',
                    'schema': schema,
                    'table_name': table,
                    'Source_Line': child.start_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': full_code_block
                })
    
    elif node.type == 'table_list':
        for child in node.children:
            if child.type == 'table_list_element':
                for subchild in child.children:
                    if subchild.type == 'referenced_element':
                        table_ref = subchild.text.decode('utf-8')
                        schema, table = normalize_table_name(table_ref)
                        tables.append({
                            'type': 'input',
                            'operation': 'FROM',
                            'schema': schema,
                            'table_name': table,
                            'Source_Line': subchild.start_point[0] + 1,
                            'Source_File': file_path,
                            'code_block': full_code_block
                        })
    
    elif node.type == 'join_clause':
        for child in node.children:
            if child.type == 'referenced_element':
                table_ref = child.text.decode('utf-8')
                schema, table = normalize_table_name(table_ref)
                tables.append({
                    'type': 'input',
                    'operation': 'JOIN',
                    'schema': schema,
                    'table_name': table,
                    'Source_Line': child.start_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': full_code_block
                })
    
    # Recursively process child nodes
    for child in node.children:
        tables.extend(extract_table_info(child, file_path, code_lines))
    
    return tables

def extract_column_info(node, file_path, code_lines):
    """Extract column information from a node"""
    columns = []
    
    # Get the entire procedure's code block
    procedure_node = node
    while procedure_node and procedure_node.type not in ['procedure_definition', 'source_file']:
        procedure_node = procedure_node.parent
    
    full_code_block = procedure_node.text.decode('utf-8') if procedure_node else node.text.decode('utf-8')
    
    # Handle SELECT statements
    if node.type == 'sql_statement_select':
        for child in node.children:
            if child.type == 'select_list':
                for select_item in child.children:
                    if select_item.type == 'select_list_element':
                        for expr in select_item.children:
                            if expr.type == 'expression':
                                for ref in expr.children:
                                    if ref.type == 'referenced_element':
                                        # Handle column references (e.g., table.column)
                                        identifiers = [id.text.decode('utf-8') for id in ref.children if id.type == 'identifier']
                                        if len(identifiers) >= 2:  # table.column format
                                            table_name = identifiers[0]
                                            column_name = identifiers[-1]
                                        else:  # just column name
                                            table_name = None
                                            column_name = identifiers[0] if identifiers else None
                                            
                                        if column_name:
                                            columns.append({
                                                'operation': 'SELECT',
                                                'schema': None,
                                                'table_name': table_name,
                                                'column_name': column_name,
                                                'Source_Line': ref.start_point[0] + 1,
                                                'Source_File': file_path,
                                                'code_block': full_code_block
                                            })
    
    # Handle WHERE clauses
    elif node.type == 'where_clause':
        for child in node.children:
            if child.type == 'expression':
                for ref in child.children:
                    if ref.type == 'referenced_element':
                        identifiers = [id.text.decode('utf-8') for id in ref.children if id.type == 'identifier']
                        if len(identifiers) >= 2:
                            table_name = identifiers[0]
                            column_name = identifiers[-1]
                        else:
                            table_name = None
                            column_name = identifiers[0] if identifiers else None
                            
                        if column_name:
                            columns.append({
                                'operation': 'WHERE',
                                'schema': None,
                                'table_name': table_name,
                                'column_name': column_name,
                                'Source_Line': ref.start_point[0] + 1,
                                'Source_File': file_path,
                                'code_block': full_code_block
                            })
    
    # Handle ORDER BY clauses
    elif node.type == 'order_by_clause':
        for child in node.children:
            if child.type == 'order_by_element':
                for ref in child.children:
                    if ref.type == 'referenced_element':
                        identifiers = [id.text.decode('utf-8') for id in ref.children if id.type == 'identifier']
                        if len(identifiers) >= 2:
                            table_name = identifiers[0]
                            column_name = identifiers[-1]
                        else:
                            table_name = None
                            column_name = identifiers[0] if identifiers else None
                            
                        if column_name:
                            columns.append({
                                'operation': 'ORDER BY',
                                'schema': None,
                                'table_name': table_name,
                                'column_name': column_name,
                                'Source_Line': ref.start_point[0] + 1,
                                'Source_File': file_path,
                                'code_block': full_code_block
                            })
    
    # Handle CASE statements
    elif node.type == 'case_expression':
        for child in node.children:
            if child.type == 'referenced_element':
                identifiers = [id.text.decode('utf-8') for id in child.children if id.type == 'identifier']
                if len(identifiers) >= 2:
                    table_name = identifiers[0]
                    column_name = identifiers[-1]
                else:
                    table_name = None
                    column_name = identifiers[0] if identifiers else None
                    
                if column_name:
                    columns.append({
                        'operation': 'CASE',
                        'schema': None,
                        'table_name': table_name,
                        'column_name': column_name,
                        'Source_Line': child.start_point[0] + 1,
                        'Source_File': file_path,
                        'code_block': full_code_block
                    })
    
    # Recursively process child nodes
    for child in node.children:
        columns.extend(extract_column_info(child, file_path, code_lines))
    
    return columns

def extract_object_info(node, file_path, code_lines):
    """Extract object type information from a node"""
    objects = []
    
    # Add debug logging
    print(f"Processing node type: {node.type}")
    
    # Handle PACKAGE definitions
    if node.type == 'create_package':
        package_name = None
        for child in node.children:
            if child.type == 'identifier' and not package_name:
                package_name = child.text.decode('utf-8')
                objects.append({
                    'object_type': 'PACKAGE',
                    'object_name': package_name,
                    'start_line': node.start_point[0] + 1,
                    'end_line': node.end_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': node.text.decode('utf-8')
                })
                print(f"Found package: {package_name}")
                break
    
    # Handle VIEW definitions
    elif node.type == 'statement':
        has_create = False
        has_view = False
        view_name = None
        
        # First pass to find create and view keywords
        for child in node.children:
            if child.type == 'kw_create':
                has_create = True
            elif child.type == 'kw_view':
                has_view = True
            elif child.type == 'identifier' and has_view and not view_name:
                view_name = child.text.decode('utf-8')
                print(f"Found view name: {view_name}")
                break
        
        if has_create and has_view and view_name:
            objects.append({
                'object_type': 'VIEW',
                'object_name': view_name,
                'start_line': node.start_point[0] + 1,
                'end_line': node.end_point[0] + 1,
                'Source_File': file_path,
                'code_block': node.text.decode('utf-8')
            })
    
    # Handle PACKAGE BODY definitions
    elif node.type == 'create_package_body':
        package_name = None
        for child in node.children:
            if child.type == 'identifier' and not package_name:
                package_name = child.text.decode('utf-8')
                objects.append({
                    'object_type': 'PACKAGE BODY',
                    'object_name': package_name,
                    'start_line': node.start_point[0] + 1,
                    'end_line': node.end_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': node.text.decode('utf-8')
                })
                break
    
    # Handle PROCEDURE definitions
    elif node.type == 'procedure_definition':
        procedure_name = None
        for child in node.children:
            if child.type == 'identifier' and not procedure_name:
                procedure_name = child.text.decode('utf-8')
                objects.append({
                    'object_type': 'PROCEDURE',
                    'object_name': procedure_name,
                    'start_line': node.start_point[0] + 1,
                    'end_line': node.end_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': node.text.decode('utf-8')
                })
                break
    
    # Handle FUNCTION definitions
    elif node.type == 'function_definition' or (node.type == 'kw_function' and node.parent.type != 'function_definition'):
        function_name = None
        for child in node.children:
            if child.type == 'identifier' and not function_name:
                function_name = child.text.decode('utf-8')
                objects.append({
                    'object_type': 'FUNCTION',
                    'object_name': function_name,
                    'start_line': node.start_point[0] + 1,
                    'end_line': node.end_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': node.text.decode('utf-8')
                })
                break
        # If we didn't find the name in children, check if this is a kw_function node
        if not function_name and node.type == 'kw_function':
            next_node = node.next_sibling
            if next_node and next_node.type == 'identifier':
                function_name = next_node.text.decode('utf-8')
                objects.append({
                    'object_type': 'FUNCTION',
                    'object_name': function_name,
                    'start_line': node.start_point[0] + 1,
                    'end_line': node.end_point[0] + 1,
                    'Source_File': file_path,
                    'code_block': node.text.decode('utf-8')
                })
    
    # Handle CREATE statements (for tables and views)
    elif node.type == 'statement':
        has_create = False
        has_table = False
        has_view = False
        object_name = None
        
        for child in node.children:
            if child.type == 'create_obj':
                has_create = True
                for create_child in child.children:
                    if create_child.type == 'kw_create':
                        continue
                    elif create_child.type == 'kw_view':
                        has_view = True
                    elif create_child.type == 'kw_table':
                        has_table = True
            elif child.type == 'kw_view':
                has_view = True
            elif child.type == 'kw_table':
                has_table = True
            elif child.type == 'identifier':
                object_name = child.text.decode('utf-8')
            elif child.type == 'ref_call':
                for subchild in child.children:
                    if subchild.type == 'referenced_element':
                        for ref_child in subchild.children:
                            if ref_child.type == 'identifier':
                                object_name = ref_child.text.decode('utf-8')
        
        if has_create and has_view and object_name:
            objects.append({
                'object_type': 'VIEW',
                'object_name': object_name,
                'start_line': node.start_point[0] + 1,
                'end_line': node.end_point[0] + 1,
                'Source_File': file_path,
                'code_block': node.text.decode('utf-8')
            })
        elif has_create and has_table and object_name:
            objects.append({
                'object_type': 'TABLE',
                'object_name': object_name,
                'start_line': node.start_point[0] + 1,
                'end_line': node.end_point[0] + 1,
                'Source_File': file_path,
                'code_block': node.text.decode('utf-8')
            })
    
    # Recursively process child nodes
    for child in node.children:
        objects.extend(extract_object_info(child, file_path, code_lines))
    
    return objects

def analyze_plsql_file(file_path):
    """Analyze a PLSQL file and extract table and column information"""
    # List of encodings to try
    encodings = ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                code = f.read()
            break  # If successful, break the loop
        except UnicodeDecodeError:
            if encoding == encodings[-1]:  # If this was the last encoding to try
                print(f"Failed to decode {file_path} with any of the attempted encodings")
                return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
            continue
    
    try:
        # Parse the code using tree-sitter
        tree = parser.parse(bytes(code, 'utf8'))
        code_lines = code.splitlines()
        
        # Extract information
        tables = extract_table_info(tree.root_node, file_path, code_lines)
        columns = extract_column_info(tree.root_node, file_path, code_lines)
        objects = extract_object_info(tree.root_node, file_path, code_lines)
        
        if tables:
            print(f"Found {len(tables)} table references")
        if columns:
            print(f"Found {len(columns)} column references")
        if objects:
            print(f"Found {len(objects)} PL/SQL objects")
        
        # Convert to DataFrames
        df_tables = pd.DataFrame(tables)
        df_columns = pd.DataFrame(columns)
        df_objects = pd.DataFrame(objects)
        
        if not df_tables.empty:
            df_tables = df_tables.drop_duplicates(subset=['type', 'schema', 'table_name', 'Source_Line', 'Source_File'])
            df_tables = df_tables.sort_values(['Source_File', 'Source_Line', 'type', 'schema', 'table_name'])
            
        if not df_columns.empty:
            df_columns = df_columns.drop_duplicates(subset=['operation', 'schema', 'table_name', 'column_name', 'Source_Line', 'Source_File'])
            df_columns = df_columns.sort_values(['Source_File', 'Source_Line', 'operation', 'schema', 'table_name', 'column_name'])
        
        if not df_objects.empty:
            df_objects = df_objects.drop_duplicates(subset=['object_type', 'object_name', 'start_line', 'end_line', 'Source_File'])
            df_objects = df_objects.sort_values(['Source_File', 'start_line', 'object_type', 'object_name'])
        
        return df_tables, df_columns, df_objects
    
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

def analyze_plsql_files(directory_path):
    """Analyze multiple PLSQL files in a directory and its subdirectories"""
    # Initialize SQLite database
    db_path = os.path.join(paths.OUTPUT_PATH, "plsql_lineage.db")
    
    conn = sqlite3.connect(db_path)
    
    # Create tables
    create_tables_sql = '''
    CREATE TABLE IF NOT EXISTS table_lineage (
        type TEXT,
        operation TEXT,
        schema TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        code_block TEXT
    );
    
    CREATE TABLE IF NOT EXISTS column_lineage (
        operation TEXT,
        schema TEXT,
        table_name TEXT,
        column_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        code_block TEXT
    );
    
    CREATE TABLE IF NOT EXISTS object_info (
        object_type TEXT,
        object_name TEXT,
        start_line INTEGER,
        end_line INTEGER,
        Source_File TEXT,
        code_block TEXT
    );
    '''
    conn.executescript(create_tables_sql)
    
    try:
        file_count = 0
        total_files_processed = 0
        
        for root, _, files in os.walk(directory_path):
            sql_files = [f for f in files if f.lower().endswith(('.sql', '.pls', '.plsql'))]
            
            for sql_file in sql_files:
                file_path = os.path.join(root, sql_file)
                total_files_processed += 1
                print(f"\nProcessing file {total_files_processed}: {file_path}")
                
                df_tables, df_columns, df_objects = analyze_plsql_file(file_path)
                
                if not df_tables.empty:
                    df_tables.to_sql('table_lineage', conn, if_exists='append', index=False)
                    file_count += 1
                    print(f"Added {len(df_tables)} table records to database")
                
                if not df_columns.empty:
                    df_columns.to_sql('column_lineage', conn, if_exists='append', index=False)
                    print(f"Added {len(df_columns)} column records to database")
                
                if not df_objects.empty:
                    df_objects.to_sql('object_info', conn, if_exists='append', index=False)
                    print(f"Added {len(df_objects)} object records to database")
        
        # Create indices
        print("\nCreating indices...")
        conn.execute('CREATE INDEX IF NOT EXISTS idx_schema ON table_lineage(schema)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table ON table_lineage(table_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_type ON table_lineage(type)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_object_type ON object_info(object_type)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_object_name ON object_info(object_name)')
        
        # Remove duplicates
        print("Removing duplicates...")
        conn.execute('''
            DELETE FROM table_lineage 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM table_lineage 
                GROUP BY 
                    type,
                    operation,
                    schema,
                    table_name,
                    Source_Line,
                    Source_File
            )
        ''')
        
        conn.execute('''
            DELETE FROM object_info 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM object_info 
                GROUP BY 
                    object_type,
                    object_name,
                    start_line,
                    end_line,
                    Source_File
            )
        ''')
        
        conn.commit()
        print(f"\nProcessed {total_files_processed} total files")
        print(f"Found data in {file_count} files")
        print(f"Information saved to database: {db_path}")
    
    except Exception as e:
        print(f"Error during processing: {str(e)}")
    
    finally:
        conn.close()
    
    return pd.DataFrame()

if __name__ == "__main__":
    # Load the PLSQL grammar
    try:
        plsql_so = paths.PLSQL_GRAMMAR_FILE
        LANGUAGE = Language(plsql_so, 'plsql')
        parser = Parser()
        parser.set_language(LANGUAGE)
        print("Successfully loaded PLSQL grammar")
    except Exception as e:
        print(f"Error loading PLSQL grammar: {str(e)}")
        exit(1)

    # Process files
    input_directory = os.path.join(paths.INPUT_PATH, "plsql")
    analyze_plsql_files(input_directory)
