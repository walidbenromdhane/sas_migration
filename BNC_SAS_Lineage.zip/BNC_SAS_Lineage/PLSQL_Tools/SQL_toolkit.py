from tree_sitter import Language, Parser
import pandas as pd
import paths, os
import re

class Utils:
    @staticmethod
    def read_file(file_path):
        """
        Read the content of a file and return its content as a string.
        """
        with open(file_path, 'r') as file:
            return file.read()

    @staticmethod
    def process_files(file_or_directory_path, sql_language_path, sql_language_name, output_excel_path):
        """
        Process SQL files from a file or directory and save results to a single Excel file.
        """
        # Initialize an empty ASTProcessor to aggregate all results
        all_processor = ASTProcessor(sql_code="")

        if os.path.isfile(file_or_directory_path):  # Single file
            file_paths = [file_or_directory_path]
        elif os.path.isdir(file_or_directory_path):  # Directory
            file_paths = [os.path.join(file_or_directory_path, f) for f in os.listdir(file_or_directory_path) if f.endswith((".sql", ".txt"))]
        else:
            raise ValueError(f"The path '{file_or_directory_path}' is neither a file nor a directory.")

        for file_path in file_paths:
            file_name = os.path.basename(file_path)  # Get the file name
            sql_code = Utils.read_file(file_path)

            # Parse and process the SQL
            parser = SQLParser(sql_language_path, sql_language_name)
            tree = parser.parse(sql_code)
            processor = ASTProcessor(sql_code)
            processor.traverse_tree(tree.root_node)

            # Add the file name to all DataFrames
            processor.df["File"] = file_name  # Add file name to the main DataFrame
            processor.alias_df["File"] = file_name  # Add file name to alias DataFrame

            # Append the file name to business rules as well
            for rule in processor.business_rules:
                rule["File"] = file_name  # Add file name to each business rule

            # Append the current file's data to the aggregated processor
            all_processor.df = pd.concat([all_processor.df, processor.df], ignore_index=True)
            all_processor.alias_df = pd.concat([all_processor.alias_df, processor.alias_df], ignore_index=True)
            all_processor.business_rules.extend(processor.business_rules)

        # Save the aggregated data to Excel
        all_processor.save_to_excel(output_excel_path)


class SQLParser:
    def __init__(self, grammar_path, language_name):
        self.language = Language(grammar_path, language_name)
        self.parser = Parser()
        self.parser.set_language(self.language)

    def parse(self, sql_text):
        # Simple direct parsing, no preprocessing needed
        tree = self.parser.parse(bytes(sql_text, "utf8"))
        return tree

class ASTProcessor:
    def __init__(self, sql_text):
        self.sql_text = sql_text
        self.df = pd.DataFrame(columns=['Input/Output', 'Operation', 'Library', 'Table', 'Involved Tables', 'Condition', 'Connection'])
        self.alias_df = pd.DataFrame(columns=["Column", "Alias"])
        self.business_rules = []
        self.columns_df = pd.DataFrame(columns=["Library", "Table", "Column"])
        self.current_table = None
        self.current_connection = None
        self.current_operation = None
        self.current_library = None
        self.previous_tables = []
        
    def traverse_tree(self, node, current_table=None):
        """
        Modified traverse_tree to handle pass-through queries
        Removed previous_tables parameter since we're tracking it in the class
        """
        # Add these new conditions at the beginning of traverse_tree
        if node.type == "connect_to":
            self._handle_connect(node)
        elif node.type == "disconnect_from":
            self._handle_disconnect(node)
        elif node.type == "connection_to":
            self._handle_connection_to(node)
        elif node.type == "update_statement" or (node.type == "keyword" and self._extract_text(node).lower() == "update"):
            self._handle_update(node)
        elif node.type == "keyword_insert" or node.type == "keyword_into" or node.type.startswith("insert") or (node.type == "keyword" and self._extract_text(node).lower() in ["insert", "insert into"]):
            self._handle_insert(node)

        # Track the current table context
        if node.type == "object_reference":
            table_name = self._get_relation(node)
            if table_name:
                self.current_table = table_name
        
        # Handle FROM clause first to initialize the first table
        if node.type == 'from':
            self._handle_from(node)
        elif node.type == 'join':
            self._handle_join(node)
            
        # Extract columns from field nodes
        elif node.type == "field":
            self._extract_field_columns(node)
        
        # Extract columns from term nodes in select expressions
        elif node.type == "term":
            self._extract_term_columns(node)
        
        # Keep existing functionality
        if node.type == 'create_table':
            self._handle_create_table(node)
        elif node.type == 'drop_table':
            self._handle_drop_table(node)
        elif node.type == 'keyword_into':
            self._handle_into(node)
        elif node.type == 'case':
            self._handle_business_rule(node)

        # Recursively traverse children
        for child in node.children:
            self.traverse_tree(child, self.current_table)

    def _handle_create_table(self, node):
        """
        Handle create table nodes and extract relevant information.
        """
        table_name = None
        for child in node.children:
            if child.type == "object_reference":
                table_name = self._get_relation(child)
        if table_name:
            self._add_to_dataframe(table_name, "CREATE")

    def _handle_drop_table(self, node):
        """
        Handle drop table nodes and extract relevant information.
        """
        table_name = None
        for child in node.children:
            if child.type == "object_reference":
                table_name = self._get_relation(child)
        if table_name:
            self._add_to_dataframe(table_name, "DROP")

    def _handle_from(self, node):
        """Handle from nodes and extract table relations."""
        from_table = None
        for child in node.children:
            if child.type == "relation" or child.type == "field":
                table_ref = None
                alias = None
                
                for grandchild in child.children:
                    if grandchild.type == "object_reference":
                        table_ref = self._get_relation(grandchild)
                    elif grandchild.type == "identifier" and table_ref:
                        alias = self._extract_text(grandchild)
                    elif grandchild.type == "subquery":
                        table_ref = "subquery"
                        break
                
                if table_ref:
                    from_table = table_ref
                    self._add_to_dataframe(from_table, "FROM")
                    if alias:
                        self.alias_df = pd.concat(
                            [self.alias_df, pd.DataFrame([{"Column": from_table, "Alias": alias}])],
                            ignore_index=True
                        )
                    # Initialize previous_tables with the FROM table
                    self.previous_tables = [from_table]

    def _handle_join(self, node):
        """
        Handle join nodes and extract involved tables and conditions.
        Now uses class-level previous_tables tracking
        """
        involved_table = None
        join_condition = None
        alias = None
        
        for child in node.children:
            if child.type == "relation" or child.type == "field":
                table_text = self._extract_text(child)
                
                if '(' in table_text:
                    table_text = table_text.split('(')[0].strip()
                
                for grandchild in child.children:
                    if grandchild.type == "object_reference":
                        involved_table = self._get_relation(grandchild)
                    elif grandchild.type == "identifier" and involved_table:
                        alias = self._extract_text(grandchild)
                    elif grandchild.type == "subquery":
                        involved_table = "subquery"
            
            elif child.type == "binary_expression":
                join_condition = self._extract_text(child)
        
        if involved_table or table_text:
            final_table = involved_table or table_text
            if '.' in final_table:
                library, table = final_table.split('.')
            else:
                library, table = '', final_table
            
            # Create involved_tables string from previous tables in this PROC SQL
            involved_tables = None
            if self.previous_tables:
                involved_tables = ", ".join(self.previous_tables)
            
            if not self.df.empty:
                mask = (
                    (self.df['Input/Output'] == 'Input') &
                    (self.df['Operation'] == 'JOIN') &
                    (self.df['Library'].str.lower() == library.lower()) &
                    (self.df['Table'].str.lower() == table.lower())
                )
                duplicate_exists = mask.any()
            else:
                duplicate_exists = False
            
            if not duplicate_exists:
                self._add_to_df(
                    'Input',
                    'JOIN',
                    library,
                    table,
                    involved_tables,
                    join_condition
                )
                
                # Add the current table to previous_tables for the next join
                self.previous_tables.append(final_table)

    def _handle_into(self, node):
        """
        Handle INTO clauses to extract variable mappings.
        """
        identifiers = []
        parent = node.parent  # Locate the parent of the current node
        if parent:
            for sibling in parent.children:
                if sibling.type == "identifier_list":
                    # Traverse the identifier_list to get all identifiers
                    for grandchild in sibling.children:
                        if grandchild.type == "identifier":
                            identifiers.append(self._extract_text(grandchild))

        for identifier in identifiers:
            # Append to the main DataFrame
            self.df = pd.concat(
                [self.df, pd.DataFrame([{
                    "Table": identifier,
                    "Operation": "INTO",
                    "Involved Tables": None,
                    "Condition": None,
                    "Input/Output": "Output"
                }])],
                ignore_index=True
            )

    def _handle_business_rule(self, node):
        """
        Extract business rules from conditional nodes by capturing the parent `term` node.
        """
        # Start with the current node (case)
        current_node = node

        # Bubble up to find the parent `term` node
        while current_node and current_node.type != "term":
            if hasattr(current_node, "parent"):
                current_node = current_node.parent
            else:
                break  # Exit if there's no parent

        # If a `term` node is found, extract its text
        if current_node and current_node.type == "term":
            term_text = self._extract_text(current_node)
            self.business_rules.append({"Rule": term_text})

    def _extract_aliases(self, node):
        """
        Extract aliases for variables in SELECT fields.
        """
        column_name = None
        alias_name = None

        for child in node.children:
            if child.type == "identifier":  # Column name
                if self._extract_text(child) != "else":
                    column_name = self._extract_text(child)
            elif child.type == "object_reference":  # Alias name
                alias_name = self._extract_text(child)

        if column_name:  # Add to alias DataFrame if column_name exists
            self.alias_df = pd.concat(
                [self.alias_df, pd.DataFrame([{"Column": column_name, "Alias": alias_name}])],
                ignore_index=True
            )

    def _split_library_and_table(self, table_name):
        """
        Split the table name into library and table components.
        Handles both two-part (schema.table) and three-part (database.schema.table) names.
        For three-part names, database becomes the library and schema.table becomes the table.
        """
        if not table_name:
            return '', ''
            
        parts = table_name.split('.')
        if len(parts) == 3:
            # Three-part name: database.schema.table
            return parts[0], f"{parts[1]}.{parts[2]}"
        elif len(parts) == 2:
            # Two-part name: schema.table
            return parts[0], parts[1]
        else:
            # Single name: table
            return '', table_name

    def _extract_text(self, node):
        """
        Helper function to extract the text representation of a node.
        """
        return self.sql_text[node.start_byte:node.end_byte]

    def _get_relation(self, node):
        """
        Helper function to extract the full relation from an object_reference node.
        Returns the full table reference including schema/library if present.
        """
        parts = []
        for child in node.children:
            if child.type == "identifier":
                parts.append(self._extract_text(child))
        return ".".join(parts) if parts else None

    def _get_expression(self, node):
        """
        Helper function to extract the join condition from a binary_expression node.
        """
        return self.sql_text[node.start_byte:node.end_byte]
    
    def _add_to_dataframe(self, table, operation, involved_tables=None, condition=None):
        """
        Add extracted information to the main DataFrame
        """
        library, table_name = self._split_library_and_table(table)
        io_type = "Output" if operation in ["CREATE"] else "Input"
        self.df = pd.concat(
            [self.df, pd.DataFrame([{
                "Library": library,  # This will be empty string if no library
                "Table": table_name,
                "Operation": operation,
                "Involved Tables": involved_tables,
                "Condition": condition,
                "Input/Output": io_type
            }])],
            ignore_index=True
        )

    def _extract_create_columns(self, node):
        """Extract columns from CREATE TABLE statement"""
        print(f"Extracting columns from CREATE TABLE, node type: {node.type}")
        table_name = None
        for child in node.children:
            print(f"CREATE TABLE child type: {child.type}")
            if child.type == "table_reference":
                table_name = self._get_relation(child)
                print(f"Found table name: {table_name}")
            elif child.type == "column_definition":
                for subchild in child.children:
                    if subchild.type == "identifier":
                        column_name = self._extract_text(subchild)
                        print(f"Found column definition: {column_name}")
                        library, table = self._split_library_and_table(table_name or '')
                        self._add_to_columns_df(library, table, column_name)

    def _extract_select_columns(self, node):
        """Extract columns from SELECT statement"""
        print(f"Extracting columns from SELECT, node type: {node.type}")
        for child in node.children:
            print(f"SELECT child type: {child.type}")
            if child.type == "result_column" or child.type == "column_reference":
                column_name = None
                table_ref = None
                
                # Extract column name
                for subchild in child.children:
                    print(f"Column child type: {subchild.type}")
                    if subchild.type == "identifier":
                        column_name = self._extract_text(subchild)
                        print(f"Found column: {column_name}")
                    elif subchild.type == "table_reference":
                        table_ref = self._extract_text(subchild)
                        print(f"Found table reference: {table_ref}")
                
                if column_name and column_name != "*":
                    library, table = self._split_library_and_table(table_ref if table_ref else self.current_table or '')
                    self._add_to_columns_df(library, table, column_name)

    def _extract_insert_columns(self, node):
        """Extract columns from INSERT statement"""
        table_name = None
        for child in node.children:
            if child.type == "table_reference":
                table_name = self._get_relation(child)
            elif child.type == "column_list":
                for subchild in child.children:
                    if subchild.type == "column_name":
                        column_name = self._extract_text(subchild)
                        library, table = self._split_library_and_table(table_name or '')
                        self._add_to_columns_df(library, table, column_name)

    def _add_to_columns_df(self, library, table, column):
        """
        Add a column to the columns DataFrame with proper handling of empty libraries
        """
        # Ensure library is an empty string if None
        library = library or ''
        
        if column and table:  # Only add if we have both column and table
            self.columns_df = pd.concat([
                self.columns_df,
                pd.DataFrame([{
                    "Library": library,  # This will be empty string if no library
                    "Table": table,
                    "Column": column
                }])
            ], ignore_index=True)

    def _extract_field_columns(self, node):
        """Extract columns from field nodes"""
        column_name = None
        table_ref = None
        
        for child in node.children:
            if child.type == "identifier":
                column_name = self._extract_text(child)
            elif child.type == "object_reference":
                table_ref = self._get_relation(child)
        
        if column_name and column_name not in ["*", "."]:
            library, table = self._split_library_and_table(table_ref if table_ref else self.current_table or '')
            if table:  # Only add if we have a table reference
                self._add_to_columns_df(library, table, column_name)

    def _extract_term_columns(self, node):
        """Extract columns from term nodes"""
        for child in node.children:
            if child.type == "field":
                self._extract_field_columns(child)
            elif child.type == "identifier":
                column_name = self._extract_text(child)
                if column_name and column_name not in ["*", "."]:
                    library, table = self._split_library_and_table(self.current_table or '')
                    if table:  # Only add if we have a table reference
                        self._add_to_columns_df(library, table, column_name)

    def save_to_excel(self, filename):
        """
        Save all DataFrames to Excel file
        """
        with pd.ExcelWriter(filename, engine="openpyxl") as writer:
            self.alias_df = self.alias_df.drop_duplicates()
            self.columns_df = self.columns_df.drop_duplicates()

            # Save existing DataFrames
            self.df.to_excel(writer, index=False, sheet_name="Main")
            self.alias_df.to_excel(writer, index=False, sheet_name="Columns")
            if self.business_rules:
                rules_df = pd.DataFrame(self.business_rules)
                rules_df.to_excel(writer, index=False, sheet_name="Business Rules")
            
            # Save the new columns DataFrame
            self.columns_df.to_excel(writer, index=False, sheet_name="Table Columns")

    def _handle_connect(self, node):
        """
        Handle CONNECT TO statements
        """
        for child in node.children:
            if child.type == "identifier":
                self.current_connection = self._extract_text(child)
                # Add connection info to DataFrame
                self._add_to_dataframe(
                    f"{self.current_connection}_CONNECTION",
                    "CONNECT",
                    None,
                    "Database Connection"
                )

    def _handle_disconnect(self, node):
        """
        Handle DISCONNECT FROM statements
        """
        if self.current_connection:
            self._add_to_dataframe(
                f"{self.current_connection}_CONNECTION",
                "DISCONNECT",
                None,
                "Database Disconnection"
            )
            self.current_connection = None

    def _handle_connection_to(self, node):
        """
        Handle CONNECTION TO database queries
        """
        if self.current_connection:
            # Find the subquery within the CONNECTION TO clause
            for child in node.children:
                if child.type == "list":  # This matches the list node in your AST
                    self._process_passthrough_query(child)

    def _process_passthrough_query(self, node):
        """
        Process the contents of a pass-through query
        """
        tables_referenced = []
        columns_referenced = []

        def traverse_passthrough(node):
            if node.type == "object_reference" and node.parent.type != "connection_to":
                table_name = self._get_relation(node)
                if table_name:
                    tables_referenced.append(table_name)
            elif node.type == "column":
                for child in node.children:
                    if child.type == "identifier":
                        column_name = self._extract_text(child)
                        if column_name and column_name != "*":
                            columns_referenced.append(column_name)
            
            for child in node.children:
                traverse_passthrough(child)

        traverse_passthrough(node)

        # Add pass-through query information to DataFrame
        for table in tables_referenced:
            # For pass-through queries, set the library to the connection name
            _, table_name = self._split_library_and_table(table)
            self._add_to_dataframe(
                f"{self.current_connection}.{table_name}",  # Use connection as library
                "FROM",  # Keep the operation as FROM
                None,
                f"Pass-through query from {self.current_connection}"
            )

        # Add columns to columns_df
        for table in tables_referenced:
            _, table_name = self._split_library_and_table(table)
            for column in columns_referenced:
                self._add_to_columns_df(
                    self.current_connection,  # Use connection as library
                    table_name,
                    column
                )

    def _process_from_clause(self, node):
        table_ref = node.text.decode('utf-8')
        
        # Extract connection if present in comment
        connection = None
        connection_match = re.search(r'/\* CONNECTION:(\w+) \*/', self.sql_text)
        if connection_match:
            connection = connection_match.group(1)
        
        # Clean up table reference
        table_ref = re.sub(r'/\* CONNECTION:[^*]+\*/', '', table_ref).strip()
        
        if '.' in table_ref:
            library, table = table_ref.split('.')
            self._add_to_df('Input', 'FROM', library, table, connection=connection)
        else:
            self._add_to_df('Input', 'FROM', None, table_ref, connection=connection)

    def _add_to_df(self, io_type, operation, library, table, involved_tables=None, condition=None, connection=None):
        """
        Add a row to the DataFrame with proper handling of empty libraries
        """
        # Ensure library is an empty string if None
        library = library or ''
        
        new_row = {
            'Input/Output': io_type,
            'Operation': operation,
            'Library': library,  # This will be empty string if no library
            'Table': table,
            'Involved Tables': involved_tables,
            'Condition': condition,
            'Connection': connection
        }
        self.df = pd.concat([self.df, pd.DataFrame([new_row])], ignore_index=True)

    def _handle_update(self, node):
        """
        Handle UPDATE statements and extract table and condition information.
        """
        table_name = None
        condition = None
        
        # First, try to find the table directly after the UPDATE keyword
        for i, child in enumerate(node.children):
            if child.type == "keyword_update" and i + 1 < len(node.children):
                next_child = node.children[i + 1]
                if next_child.type == "object_reference":
                    table_name = self._extract_text(next_child)
                    break
        
        # If we didn't find the table that way, look for object_reference nodes
        if not table_name:
            for child in node.children:
                if child.type == "object_reference":
                    table_name = self._extract_text(child)
                    break
        
        # If still no table name, try to extract it from the SQL text
        if not table_name:
            sql_text = self._extract_text(node)
            match = re.search(r'update\s+([^\s]+)', sql_text, re.IGNORECASE)
            if match:
                table_name = match.group(1)
        
        # Look for WHERE clause
        for child in node.children:
            if child.type == "where":
                condition = self._extract_text(child)
                break
        
        # If we found a table name, add it to our dataframe
        if table_name:
            library, table = self._split_library_and_table(table_name)
            self._add_to_df(
                'Input/Output',  # UPDATE is both input and output
                'UPDATE',
                library,
                table,
                None,  # No involved tables for simple UPDATE
                condition
            )
            
            # Set as current table for column extraction
            self.current_table = table_name

    def _handle_insert(self, node):
        """
        Handle INSERT statements and extract table and column information.
        """
        table_name = None
        columns = []
        
        
        # Look for the table name in different ways based on the node structure
        if node.type == "keyword_insert" or node.type == "keyword_into":
            # Look for the next object_reference after keyword_into
            found_into = False
            for child in node.parent.children:
                if found_into and child.type == "object_reference":
                    table_name = self._extract_text(child)
                    break
                if child.type == "keyword_into":
                    found_into = True
        else:
            # Look for object_reference directly
            for child in node.children:
                if child.type == "object_reference":
                    table_name = self._extract_text(child)
                    break
                # Also check for keyword_into followed by object_reference
                if child.type == "keyword_into" and len(child.children) > 0:
                    for into_child in child.children:
                        if into_child.type == "object_reference":
                            table_name = self._extract_text(into_child)
                            break
        
        # If still no table name, try to extract it from the SQL text
        if not table_name:
            sql_text = self._extract_text(node)
            match = re.search(r'insert\s+(?:into\s+)?([^\s(]+)', sql_text, re.IGNORECASE)
            if match:
                table_name = match.group(1)
        
        # Extract columns if available - look for lists or column definitions
        for child in node.children:
            if child.type in ["list", "column_list", "_column_list", "paren_list"]:
                for col_child in child.children:
                    if col_child.type in ["column", "identifier"]:
                        columns.append(self._extract_text(col_child))
        
        # If we found a table name, add it to our dataframe
        if table_name:
            library, table = self._split_library_and_table(table_name)
            self._add_to_df(
                'Output',  # INSERT is output
                'INSERT',
                library,
                table,
                None,  # No involved tables for simple INSERT
                None   # No condition
            )
            
            # Set as current table for column extraction
            self.current_table = table_name
            
            # Add columns to columns_df if found
            for column in columns:
                self._add_to_columns_df(library, table, column)


# Main Program
if __name__ == "__main__":
    SQL_LANGUAGE_PATH = paths.SQL_GRAMMAR_FILE
    SQL_LANGUAGE_NAME = "sql"
    DIRECTORY_PATH = "smu"
    OUTPUT_EXCEL_PATH = os.paths.join(paths.OUTPUT_PATH,"output_sql.xlsx")
    
    # Process all files in the directory and save results
    Utils.process_files(DIRECTORY_PATH, SQL_LANGUAGE_PATH, SQL_LANGUAGE_NAME, OUTPUT_EXCEL_PATH)
