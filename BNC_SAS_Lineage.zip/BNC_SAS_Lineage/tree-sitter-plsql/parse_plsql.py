from tree_sitter import Language, Parser
import json
import os

def setup_parser():
    # Get the current directory (where the script is)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    

    
    # Load the PL/SQL language
    PLSQL_LANGUAGE = Language(os.path.join(current_dir, 'build/my-languages.so'), 'plsql')
    
    # Create and configure the parser
    parser = Parser()
    parser.set_language(PLSQL_LANGUAGE)
    
    return parser

def parse_file(parser, file_path):
    with open(file_path, 'r') as file:
        content = file.read()
    
    tree = parser.parse(bytes(content, 'utf8'))
    return tree

def node_to_dict(node):
    result = {
        'type': node.type,
        'start_point': node.start_point,
        'end_point': node.end_point,
    }
    
    if len(node.children) == 0:
        result['text'] = node.text.decode('utf8')
    else:
        result['children'] = [node_to_dict(child) for child in node.children]
    
    return result

def main():
    # Create build directory if it doesn't exist
    current_dir = os.path.dirname(os.path.abspath(__file__))
    build_dir = os.path.join(current_dir, 'build')
    if not os.path.exists(build_dir):
        os.makedirs(build_dir)

    parser = setup_parser()
    
    # Use an absolute path for the test file
    test_file = os.path.join(current_dir, 'test.sql')
    tree = parse_file(parser, test_file)
    
    # Convert the AST to a dictionary and print it as JSON
    ast_dict = node_to_dict(tree.root_node)
    print(json.dumps(ast_dict, indent=2))

if __name__ == '__main__':
    main()