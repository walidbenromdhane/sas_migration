import os, chardet, paths
import unicodedata
import re

"""
This code ensures that all the SAS codes are encoded correctly and removes comments. 
It needs to be executed with each new set of SAS code copied into the 'inputs' folder.
"""

def normalize_french_chars(text):
    """
    Replace French characters with their English counterparts.
    For example: é -> e, à -> a, ç -> c, etc.
    """
    # First, decompose the characters (separate base letter from accents)
    normalized = unicodedata.normalize('NFKD', text)
    # Then remove the accent marks, keeping only the base letters
    normalized = ''.join(c for c in normalized if not unicodedata.combining(c))
    return normalized


def fix_file_encoding(filepath):
    with open(filepath, 'rb') as f:
        data = f.readlines()

    # Decode and normalize all lines
    processed_lines = []
    for line in data:
        detection = chardet.detect(line)
        try:
            decoded_line = line.decode('utf8')
        except:
            try:
                decoded_line = line.decode('ISO-8859-1')
            except:
                decoded_line = line.decode(detection['encoding'])
        
        # Normalize French characters after decoding
        processed_lines.append(normalize_french_chars(decoded_line))

    
    # Remove any excessive blank lines created by comment removal
    cleaned_text = re.sub(r'\n\s*\n', '\n\n', cleaned_text)

    # Write the cleaned content back to file in UTF-8 encoding
    with open(filepath, mode='w', newline='', encoding='utf8') as f:
        f.write(cleaned_text)

##################
directory_name = "sas_code"
directory_path = os.path.join(paths.INPUT_PATH, directory_name)
for root, dirs, files in os.walk(directory_path):
    sas_files = [f for f in files if f.endswith('.sas')]
    for sas_file in sas_files:
        file_path = os.path.join(root, sas_file)
        print(file_path)
        fix_file_encoding(file_path)