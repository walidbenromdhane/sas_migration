import os
import re
import pandas as pd
import paths

def count_select_star(file_path):
    """Count occurrences of 'select *' and 'select * from connection' in a file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().lower()  # Convert to lowercase for case-insensitive matching
            
            # Count lines
            num_lines = len(content.splitlines())
            
            # Count 'select *' occurrences
            # This pattern matches 'select *' with optional whitespace and newlines
            pattern = r'select\s+\*'
            select_star_count = len(re.findall(pattern, content, re.IGNORECASE))
            
            # Count 'select * from connection' occurrences
            connection_pattern = r'select\s+\*\s+from\s+connection'
            connection_count = len(re.findall(connection_pattern, content, re.IGNORECASE))
            
            return num_lines, select_star_count, connection_count
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        return 0, 0, 0

def analyze_repository(directory_path):
    """Analyze all files in a repository for 'select *' usage"""
    results = []
    
    for root, _, files in os.walk(directory_path):
        for file in files:
            # Only process .sql, .sas, and .py files
            if file.endswith(('.sql', '.sas', '.py')):
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, directory_path)
                print(relative_path)  # Print progress
                
                num_lines, select_star_count, connection_count = count_select_star(file_path)
                
                if num_lines > 0:  # Only include files with content
                    results.append({
                        'Program Path': relative_path,
                        'Line Count': num_lines,
                        'Select * Count': select_star_count,
                        'Select * FROM CONNECTION Count': connection_count
                    })
    
    # Create DataFrame and sort by 'Select * Count' in descending order
    df = pd.DataFrame(results)
    df = df.sort_values('Select * Count', ascending=False)
    
    return df

if __name__ == "__main__":
    # Use the directory name from the example
    directory_name = "smu"
    input_directory = os.path.join(paths.INPUT_PATH, directory_name)
    
    # Analyze repository and create report
    results_df = analyze_repository(input_directory)
    
    # Save to Excel
    output_file = os.path.join(paths.OUTPUT_PATH, "select_star_analysis.xlsx")
    results_df.to_excel(output_file, index=False)
    
    print(f"\nAnalysis complete. Results saved to: {output_file}")
    print(f"\nFound {results_df['Select * Count'].sum()} total 'SELECT *' occurrences")
    print(f"Of which {results_df['Select * FROM CONNECTION Count'].sum()} are 'SELECT * FROM CONNECTION'")
    print(f"Analyzed {len(results_df)} files")
