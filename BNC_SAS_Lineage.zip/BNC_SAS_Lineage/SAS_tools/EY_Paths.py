SAS_GRAMMAR_FILE = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\tree-sitter-sas\build\sas.so"

SQL_GRAMMAR_FILE = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\sql\build\sql.so"

OUTPUT_PATH = r"C:\Users\ZH634TG\OneDrive - EY\Desktop\BNC_SAS_Lineage\output.xlsx"

DIRECTORY = r"C:\Users\ZH634TG\Downloads\files_sas"