#!/usr/bin/perl
use strict;
use warnings;

# A simple function that adds two numbers
sub add_numbers {
    my ($a, $b) = @_;
    return $a + $b;
}

# Main program
my $x = 10;
my $y = 20;
my $result = add_numbers($x, $y);
print "The sum of $x and $y is: $result\n";

# Test a simple loop
foreach my $i (1..5) {
    print "Count: $i\n";
}

# Test an if condition
if ($result > 25) {
    print "Result is greater than 25\n";
} else {
    print "Result is less than or equal to 25\n";
}