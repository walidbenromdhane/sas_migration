from tree_sitter import Language, Parser
import os
import pandas as pd
from pathlib import Path
import paths


def initialize_parser(plsql_language):
    parser = Parser()
    parser.set_language(plsql_language)
    return parser

def extract_table_info(node, source_bytes):
    """Recursively extract table operations from the AST"""
    table_operations = []
    
    # Helper function to get text from node
    def get_text(node):
        return source_bytes[node.start_byte:node.end_byte].decode('utf-8')

    # Helper function to get schema-qualified name
    def get_qualified_name(node):
        schema = node.child_by_field_name('schema')
        name = node.child_by_field_name('name')
        if schema:
            return f"{get_text(schema)}.{get_text(name)}"
        return get_text(name)

    if node.type == 'object_reference' and node.parent:
        parent_type = node.parent.type
        
        # Handle trigger definitions
        if parent_type == 'create_trigger':
            # Find the ON table reference
            table_node = None
            for child in node.parent.children:
                if child.type == 'keyword_on':
                    # The next node should be the table reference
                    next_idx = node.parent.children.index(child) + 1
                    if next_idx < len(node.parent.children):
                        table_node = node.parent.children[next_idx]
                        break
            
            if table_node:
                # Determine trigger timing and events
                timing = 'BEFORE'  # default
                events = []
                for child in node.parent.children:
                    if child.type == 'keyword_after':
                        timing = 'AFTER'
                    elif child.type in ['keyword_insert', 'keyword_update', 'keyword_delete']:
                        events.append(get_text(child).upper())

                table_operations.append({
                    'operation': f'CREATE TRIGGER ({timing} {" OR ".join(events)})',
                    'table_name': get_text(table_node),
                    'trigger_name': get_text(node)
                })

        # Handle FROM clause tables and subqueries
        elif parent_type == 'relation' and node.parent.parent and node.parent.parent.type == 'from':
            alias_node = node.parent.child_by_field_name('_alias')
            table_operations.append({
                'operation': 'FROM',
                'table_name': get_qualified_name(node),
                'alias': get_text(alias_node) if alias_node else None
            })

        # Handle INSERT operations
        elif parent_type == 'insert':
            column_list = node.parent.child_by_field_name('columns')
            table_operations.append({
                'operation': 'INSERT INTO',
                'table_name': get_qualified_name(node),
                'columns': get_text(column_list) if column_list else None
            })

        # Handle SELECT INTO operations
        elif parent_type == 'select' and any(child.type == 'keyword_into' for child in node.parent.children):
            table_operations.append({
                'operation': 'SELECT INTO',
                'table_name': get_qualified_name(node)
            })

        # Handle UPDATE operations
        elif parent_type == 'update':
            table_operations.append({
                'operation': 'UPDATE',
                'table_name': get_qualified_name(node)
            })

        # Handle DELETE operations
        elif parent_type == 'delete':
            table_operations.append({
                'operation': 'DELETE FROM',
                'table_name': get_qualified_name(node)
            })

        # Handle type references (%TYPE, %ROWTYPE)
        elif parent_type == 'type_reference':
            table_operations.append({
                'operation': 'TYPE REFERENCE',
                'table_name': get_qualified_name(node),
                'reference_type': '%ROWTYPE' if node.parent.children[-1].type == '%ROWTYPE' else '%TYPE'
            })

    # Recursively process all children
    for child in node.children:
        table_operations.extend(extract_table_info(child, source_bytes))

    return table_operations

def process_file(file_path, parser):
    """Process a single PLSQL file and extract table operations"""
    with open(file_path, 'rb') as file:
        source_bytes = file.read()
        
    tree = parser.parse(source_bytes)
    table_ops = extract_table_info(tree.root_node, source_bytes)
    
    # Add file information to each operation
    for op in table_ops:
        op['file'] = str(file_path)
    
    return table_ops

def main(directory_path):
    # Initialize tree-sitter
    plsql_so = paths.PLSQL_GRAMMAR_FILE
    
    plsql_language = Language(plsql_so, 'plsql')
    parser = initialize_parser(plsql_language)
    
    # Process all files
    all_table_operations = []
    
    for root, _, files in os.walk(directory_path):
        for file in files:
            if file.endswith(('.sql', '.pls', '.plsql')):
                file_path = Path(root) / file
                try:
                    table_ops = process_file(file_path, parser)
                    all_table_operations.extend(table_ops)
                except Exception as e:
                    print(f"Error processing {file_path}: {e}")

    # Create DataFrame and save to Excel
    if all_table_operations:
        df = pd.DataFrame(all_table_operations)
        output_file = 'table_operations.xlsx'
        df.to_excel(output_file, index=False)
        print(f"Results saved to {output_file}")
    else:
        print("No table operations found")

if __name__ == "__main__":
    directory_path = os.path.join(paths.INPUT_PATH, "plsql")
    main(directory_path)
