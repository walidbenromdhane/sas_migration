import os
import pandas as pd

root_folder = os.path.dirname(os.getcwd())
input_folder = os.path.join(root_folder,"Rtl_01_Credit_cards") 
output_folder = os.path.join(root_folder,"outputs") 
output_path  = os.path.join(output_folder,"files_filtered_by_keywords.csv") 

def search_files_for_keywords(folder_path, key_words):
    data = []
    
    # Walk through the folder recursively
    for root, _, files in os.walk(folder_path):
        for file_name in files:
            file_path = os.path.join(root, file_name)
            
            # Check if any keyword is in the file name
            for keyword in key_words:
                if keyword.lower() in file_name.lower():
                    data.append({
                        "file_name": file_name,
                        "file_path": file_path,
                        "keyword": keyword,
                        "keyword_location": "file name"
                    })
            
            # Check file content for keywords
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    for line_number, line in enumerate(file, start=1):
                        for keyword in key_words:
                            if keyword.lower() in line.lower():
                                data.append({
                                    "file_name": file_name,
                                    "file_path": file_path,
                                    "keyword": keyword,
                                    "keyword_location": f"line {line_number}"
                                })
            except (UnicodeDecodeError, IOError):
                # Skip files that can't be read
                pass
    
    # Convert data to a DataFrame
    df = pd.DataFrame(data, columns=["file_name", "file_path", "keyword", "keyword_location"])
    return df

# Example usage
key_words = ["credit", "carte"]
result_df = search_files_for_keywords(input_folder, key_words)
result_df.to_csv(output_path, index=False)
