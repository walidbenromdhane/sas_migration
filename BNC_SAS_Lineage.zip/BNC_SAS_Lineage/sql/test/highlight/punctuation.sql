SELECT foo.bar;
--        ^ punctuation.delimiter
--            ^ punctuation.delimiter
