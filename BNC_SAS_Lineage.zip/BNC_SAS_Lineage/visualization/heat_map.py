import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import os

output_folder = os.path.join(os.path.dirname(os.path.dirname(os.getcwd())),"outputs")  

file_path = os.path.join(output_folder,'lineage.csv')
lineage_data = pd.read_csv(file_path)
# Prepare data for the heatmap
lineage_data = lineage_data[~lineage_data.library.isna()]
lineage_data['len'] = lineage_data.apply(lambda x: len(x['library']),axis=1)
lineage_data['library'] = lineage_data.apply(lambda x: x['library'].lower(),axis=1)
lineage_data = lineage_data[ lineage_data.len < 15]
heatmap_data = lineage_data.groupby(['library', 'step_type']).size().unstack(fill_value=0)
# Create the heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(heatmap_data, annot=True, fmt="d", cmap="coolwarm", cbar=True)

# Add labels and title
plt.title("Frequency of Dataset Usage by Library and Step Type", fontsize=14)
plt.xlabel("Step Type", fontsize=12)
plt.ylabel("Library", fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()

# Show the heatmap
plt.show()
