import os
import tempfile
from fix_files_encoding import detect_sas_comments

def test_comment_removal():
    # Test SAS code with various comment styles
    test_sas_code = '''
************************************************************************************************************************;
* Author: ABC                                                                                                                                                                                                                                                                                                                                                                      ;
* Purpose: XYZ                                                                                                                                                                                                                                                                                ;
* Version: 1                                                                                                                                                                                                                                                                                                                                                   ;
*******************************************************************************************************************************************;
*Program Start;

/* This is a block comment */
proc sql;
    /* Another block comment */
    select * from table1;  /* Inline comment */
    * Single line comment;
    select a,
           b,
           sum(c) as total
    from table2;
quit;

data test;
    set mydata;
    /* Multi-line
       block comment */
    if a > 0 then do;
        output;
    end;
run;'''

    # Get the before state
    before_lines = test_sas_code.splitlines()
    print("\nBEFORE:")
    print("-" * 80)
    print(test_sas_code)
    print(f"Number of lines before: {len(before_lines)}")

    # Apply the comment detection directly
    comments, after_content = detect_sas_comments(test_sas_code)

    # Get the after state
    after_lines = after_content.splitlines()
    print("\nAFTER:")
    print("-" * 80)
    print(after_content)
    print(f"Number of lines after: {len(after_lines)}")

    # Print comments found
    print("\nComments found:")
    print("-" * 80)
    for comment in comments:
        print(f"- {comment}")

    # Additional assertions
    assert len(before_lines) == len(after_lines), f"Line count mismatch: before={len(before_lines)}, after={len(after_lines)}"

if __name__ == "__main__":
    print("Testing comment removal...")
    test_comment_removal()
