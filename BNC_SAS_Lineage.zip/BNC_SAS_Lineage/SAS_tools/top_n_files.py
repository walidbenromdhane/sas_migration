import os
import heapq

def find_largest_sas_files(directory, top_n=10):
    largest_files = []
    sas_extensions = {".sas", ".sas7bdat"}

    for root, _, files in os.walk(directory):
        for file in files:
            try:
                if os.path.splitext(file)[1].lower() in sas_extensions:
                    filepath = os.path.join(root, file)
                    filesize = os.path.getsize(filepath)
                    if len(largest_files) < top_n:
                        heapq.heappush(largest_files, (filesize, filepath))
                    else:
                        heapq.heappushpop(largest_files, (filesize, filepath))
            except (OSError, PermissionError):
                pass

    # Sort the results in descending order by size
    largest_files.sort(reverse=True, key=lambda x: x[0])
    return largest_files

# Usage example
if __name__ == "__main__":
    directory_to_search = "directory"
    top_n_files = 10
    largest_files = find_largest_sas_files(directory_to_search, top_n_files)

    print(f"The {top_n_files} largest SAS files are:")
    for size, path in largest_files:
        print(f"{size} bytes - {path}")
