import sqlite3
import pandas as pd
import os
import paths

def merge_columns_into_output():
    output_db = sqlite3.connect(os.path.join(paths.OUTPUT_PATH, "output.db"))
    columns_db = sqlite3.connect(os.path.join(paths.OUTPUT_PATH, "columns.db"))
    
    try:
        columns_df = pd.read_sql_query("""
            SELECT * FROM sas_columns
        """, columns_db)
        
        columns_df.to_sql('columns', output_db, if_exists='replace', index=False)
        
        output_db.execute('CREATE INDEX IF NOT EXISTS idx_col_library ON columns(library)')
        output_db.execute('CREATE INDEX IF NOT EXISTS idx_col_table ON columns(table_name)')
        output_db.execute('CREATE INDEX IF NOT EXISTS idx_col_name ON columns(column_name)')
        
        output_db.commit()
        print("Successfully added columns table to output database!")
        
        cursor = output_db.cursor()
        cursor.execute("SELECT COUNT(*) FROM columns")
        columns_count = cursor.fetchone()[0]
        print(f"\nTotal columns: {columns_count}")
        
    finally:
        output_db.close()
        columns_db.close()

if __name__ == "__main__":
    merge_columns_into_output()