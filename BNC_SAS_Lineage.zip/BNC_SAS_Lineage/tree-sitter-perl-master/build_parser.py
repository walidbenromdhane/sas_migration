from tree_sitter import Language

# Build the language library
Language.build_library(
    'build/my-languages.so',
    [
        '.'  # Since you're already in the tree-sitter-perl directory, use '.'
    ]
)