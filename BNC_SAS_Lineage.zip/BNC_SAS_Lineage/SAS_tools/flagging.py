import pandas as pd

def find_missing_libraries(input_excel, output_excel):

    table_lineage = pd.read_excel(input_excel, sheet_name='Table Lineage')
    librefs = pd.read_excel(input_excel, sheet_name='Librefs')
    
    defined_libraries = librefs['libref'].str.strip("'").unique()
    
    missing_libs = table_lineage[~table_lineage['library'].str.strip("'").isin(defined_libraries)]
    
    try:
        with pd.ExcelWriter(output_excel, engine='openpyxl') as writer:
            missing_libs.to_excel(writer, sheet_name='Missing Libraries', index=False)
            
            # Add a summary sheet
            summary = pd.DataFrame({
                'Metric': ['Total Tables', 'Tables with Undefined Libraries', 'Percentage'],
                'Value': [
                    len(table_lineage),
                    len(missing_libs),
                    f"{(len(missing_libs) / len(table_lineage) * 100):.2f}%"
                ]
            })
            summary.to_excel(writer, sheet_name='Summary', index=False)
            
        print(f"\nResults written to: {output_excel}")
        
    except Exception as e:
        print(f"Error writing Excel file: {str(e)}")

if __name__ == "__main__":
    input_file = ""
    output_file = ""
    find_missing_libraries(input_file, output_file)
