#!/usr/bin/env python3
from tree_sitter import Language, Parser
import json

def get_ast(perl_code):
    # Load the tree-sitter-perl language
    PERL_LANGUAGE = Language('build/my-languages.so', 'perl')
    
    # Create a parser
    parser = Parser()
    parser.set_language(PERL_LANGUAGE)

    # Parse the code
    tree = parser.parse(bytes(perl_code, "utf8"))
    
    # Convert the AST to a dictionary format
    def convert_tree_to_dict(node):
        result = {
            "type": node.type,
            "start_point": node.start_point,
            "end_point": node.end_point,
            "start_byte": node.start_byte,
            "end_byte": node.end_byte,
        }
        
        if len(node.children) == 0:
            result["text"] = perl_code[node.start_byte:node.end_byte]
        else:
            result["children"] = [convert_tree_to_dict(child) for child in node.children]
            
        return result

    return convert_tree_to_dict(tree.root_node)

def main():
    # Read the Perl file
    try:
        with open('test.pl', 'r') as file:
            perl_code = file.read()
    except FileNotFoundError:
        print("Error: test.pl not found")
        return

    # Get the AST
    ast = get_ast(perl_code)
    
    # Write the AST to a file
    try:
        with open('ast_output.txt', 'w') as outfile:
            json.dump(ast, outfile, indent=2)
        print("AST has been written to ast_output.txt")
    except IOError:
        print("Error: Could not write to ast_output.txt")

if __name__ == "__main__":
    main()