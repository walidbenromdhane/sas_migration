import re
import os
import sqlite3
import pandas as pd
from tree_sitter import Language, Parser
from SQL_toolkit import SQLParser, ASTProcessor
import traceback

def extract_sql(plsql_script: str) -> list:
    """
    Extract pure SQL components from a PL/SQL script using regex.
    Captures complete SQL statements that start with SQL keywords and end with semicolon.
    
    Args:
        plsql_script (str): The input PL/SQL script
        
    Returns:
        list: List of tuples containing (sql_statement, line_number)
    """
    # Create a copy of the script for line number tracking
    line_tracking_script = plsql_script
    
    # Replace single-line comments with empty lines to preserve line numbers
    line_tracking_script = re.sub(r'--.*$', '\n', line_tracking_script, flags=re.MULTILINE)
    line_tracking_script = re.sub(r'#.*$', '\n', line_tracking_script, flags=re.MULTILINE)
    
    # Replace multi-line comments with equivalent number of newlines to preserve line numbers
    def replace_with_newlines(match):
        return '\n' * match.group(0).count('\n')
    
    line_tracking_script = re.sub(r'/\*.*?\*/', replace_with_newlines, line_tracking_script, flags=re.DOTALL)
    
    # SQL keywords that typically start a SQL statement
    # Ensure UPDATE and DELETE are properly captured
    sql_keywords = r'select|insert\s+into|insert|update|delete\s+from|delete|merge|create|alter|drop|truncate|grant|revoke'
    
    # Pattern: SQL keyword followed by any characters (non-greedy) until semicolon
    # Modified to better handle multi-line statements
    pattern = fr'(?s)\b({sql_keywords})\b.*?;'
    
    # Find all matches and their line numbers
    statements = []
    for match in re.finditer(pattern, line_tracking_script, re.IGNORECASE):
        # Get the original case version of the statement from the original script
        original_statement = plsql_script[match.start():match.end()].strip()
        line_num = line_tracking_script[:match.start()].count('\n') + 1
        statements.append((original_statement, line_num))
    
    return statements

def normalize_sql(sql):
    """Normalize SQL string by cleaning up whitespace and formatting"""
    # Replace multiple whitespace with single space
    sql = re.sub(r'\s+', ' ', sql)
    sql = re.sub(r',\s*', ', ', sql)
    sql = re.sub(r'\s*(=|\+|-|\*|/|\(|\))\s*', r' \1 ', sql)
    sql = re.sub(r'\s+JOIN\s+', ' JOIN ', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+ON\s+', ' ON ', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+FROM\s+', ' FROM ', sql, flags=re.IGNORECASE)
    return sql.strip()

def extract_objects(plsql_script: str) -> list:
    """
    Extract SQL objects (packages, views, triggers, etc.) from a PL/SQL script using regex.
    
    Args:
        plsql_script (str): The input PL/SQL script
        
    Returns:
        list: List of tuples containing (object_type, object_name, definition, line_number)
    """
    # Create a copy for line number tracking
    line_tracking_script = plsql_script
    
    # Remove comments but preserve line numbers
    line_tracking_script = re.sub(r'--.*$', '', line_tracking_script, flags=re.MULTILINE)
    
    # Replace multi-line comments with equivalent number of newlines
    def replace_with_newlines(match):
        return '\n' * match.group(0).count('\n')
    
    line_tracking_script = re.sub(r'/\*.*?\*/', replace_with_newlines, line_tracking_script, flags=re.DOTALL)
    
    # Define regex patterns for different object types
    object_patterns = {
        'PACKAGE': r'CREATE\s+(?:OR\s+REPLACE\s+)?PACKAGE\s+(?:BODY\s+)?([^\s]+)(?:\s+AS|\s+IS)?([^;]+?)\s*(?:END[^;]*?;|;)',
        'VIEW': r'(?i)CREATE\s+(?:OR\s+REPLACE\s+)?(?:FORCE\s+)?VIEW\s+([^\s]+)\s+AS\s+([^;]+);',
        'TRIGGER': r'CREATE\s+(?:OR\s+REPLACE\s+)?TRIGGER\s+([^\s]+)([^;]+);',
        'PROCEDURE': r'(?:CREATE\s+(?:OR\s+REPLACE\s+)?)?PROCEDURE\s+([^\s(]+)[^;]+?(?:AS|IS)([^;]+?)\s*(?:END[^;]*?;|;)',
        'MATERIALIZED_VIEW': r'CREATE\s+MATERIALIZED\s+VIEW\s+([^\s]+)([^;]+);',
        'TEMPORARY_TABLE': r'CREATE\s+(?:GLOBAL\s+)?TEMPORARY\s+TABLE\s+([^\s]+)([^;]+);',
        'FUNCTION': r'(?:CREATE\s+(?:OR\s+REPLACE\s+)?)?FUNCTION\s+([^\s(]+)[^;]+?(?:AS|IS)([^;]+?)\s*(?:END[^;]*?;|;)'
    }
    
    objects = []
    modified_script = line_tracking_script
    
    # Process each pattern
    for obj_type, pattern in object_patterns.items():
        matches = re.finditer(pattern, line_tracking_script, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        
        for match in matches:
            obj_name = match.group(1)
            # Remove double quotation marks from object name
            obj_name = obj_name.replace('"', '')
            # Get the original definition from the original script
            definition = plsql_script[match.start():match.end()].strip()
            line_num = line_tracking_script[:match.start()].count('\n') + 1
            
            objects.append((obj_type, obj_name.strip(), definition.strip(), line_num))
            # Remove the matched object from script to prevent duplicate processing
            # Replace with newlines to preserve line numbers
            match_text = line_tracking_script[match.start():match.end()]
            newline_replacement = '\n' * match_text.count('\n')
            modified_script = modified_script.replace(match_text, newline_replacement)
    
    return objects, modified_script

def extract_columns(sql: str, sql_parser: SQLParser) -> list:
    """
    Extract column information from SQL statements.
    
    Args:
        sql (str): The SQL statement
        sql_parser (SQLParser): The SQL parser instance
        
    Returns:
        list: List of dictionaries containing column information
    """
    # First normalize the SQL
    normalized_sql = normalize_sql(sql)
    
    # Skip index-related operations
    if re.search(r'\b(alter|create)\s+index\b', normalized_sql, re.IGNORECASE):
        return []
    
    # Skip GRANT statements
    if re.search(r'\bgrant\s+(select|insert|update|delete|all)', normalized_sql, re.IGNORECASE):
        return []
    
    # Skip REVOKE statements
    if re.search(r'\brevoke\s+(select|insert|update|delete|all)', normalized_sql, re.IGNORECASE):
        return []
    
    # Skip CREATE VIEW statements
    if re.search(r'\bcreate\s+(?:or\s+replace\s+)?(?:force\s+)?view\b', normalized_sql, re.IGNORECASE):
        return []
    
    # Parse the SQL
    sql_tree = sql_parser.parse(normalized_sql)
    
    # Create an ASTProcessor to handle the SQL parsing
    sql_processor = ASTProcessor(normalized_sql)
    sql_processor.traverse_tree(sql_tree.root_node)
    
    # Get the columns from the processor
    columns_df = sql_processor.columns_df
    
    # If we have columns from the processor, use them
    if not columns_df.empty:
        result = []
        for _, row in columns_df.iterrows():
            # Skip empty or invalid columns
            if not row['Column'] or not is_valid_column_name(row['Column']):
                continue
                
            # Create a column entry
            column_entry = {
                'column_name': row['Column'],
                'table_name': row['Table'] if row['Table'] and row['Table'].lower() not in SQL_KEYWORDS else ''
            }
            
            # Add library/schema if available
            if row['Library'] and row['Library'] != 'WORK':
                column_entry['schema'] = row['Library']
                
            result.append(column_entry)
        return result
    
    # If the processor didn't find columns, fall back to our manual extraction
    columns = []
    tables = set()  # Track tables to avoid misidentifying them as columns
    table_aliases = {}  # Track table aliases as a mapping from alias to actual table name
    default_tables = []  # Track tables in FROM clause for unqualified columns
    
    # First pass: identify tables and their aliases
    def identify_tables(node):
        # Handle table references
        if node.type == 'relation' or node.type == 'object_reference':
            if node.parent and node.parent.type in ['from', 'join', 'update_statement', 'insert_statement', 'merge_statement', '_merge_statement']:
                table_text = normalized_sql[node.start_byte:node.end_byte].strip()
                if table_text:  # Check if not empty
                    tables.add(table_text.lower())
                    # Also add the last part of qualified names (schema.table)
                    if '.' in table_text:
                        tables.add(table_text.split('.')[-1].lower())
                    
                    # Add to default tables list if this is in a FROM clause
                    if node.parent.type == 'from':
                        default_tables.append(table_text)
                        
                    # Check for alias after this table
                    next_sibling = node.next_sibling
                    if next_sibling:
                        if next_sibling.type == 'identifier':
                            alias_text = normalized_sql[next_sibling.start_byte:next_sibling.end_byte].strip()
                            if alias_text:
                                table_aliases[alias_text.lower()] = table_text
                        elif next_sibling.type == '_alias':
                            alias_text = normalized_sql[next_sibling.start_byte:next_sibling.end_byte].strip()
                            # Remove 'AS' if present
                            alias_text = re.sub(r'^AS\s+', '', alias_text, flags=re.IGNORECASE).strip()
                            if alias_text:
                                table_aliases[alias_text.lower()] = table_text
        
        # Handle table aliases
        if node.type == '_alias' and node.parent and node.parent.type in ['relation', 'object_reference']:
            alias_text = normalized_sql[node.start_byte:node.end_byte].strip()
            if alias_text:
                # Remove 'AS' if present
                alias_text = re.sub(r'^AS\s+', '', alias_text, flags=re.IGNORECASE).strip()
                # Get the table name from the parent node
                if node.parent:
                    table_text = normalized_sql[node.parent.start_byte:node.parent.end_byte].strip()
                    # Remove the alias part from the table text
                    table_text = table_text.replace(normalized_sql[node.start_byte:node.end_byte], '').strip()
                    if table_text:
                        table_aliases[alias_text.lower()] = table_text
        
        # Handle explicit aliases in FROM clauses
        if node.type == 'from' or node.type == 'join':
            for child in node.children:
                if child.type == 'relation' or child.type == 'object_reference':
                    table_text = normalized_sql[child.start_byte:child.end_byte].strip()
                    # Add to default tables list if this is in a FROM clause
                    if node.type == 'from':
                        default_tables.append(table_text)
                    # Look for siblings that might be aliases
                    next_sibling = child.next_sibling
                    if next_sibling and next_sibling.type == 'identifier':
                        alias_text = normalized_sql[next_sibling.start_byte:next_sibling.end_byte].strip()
                        if alias_text:
                            table_aliases[alias_text.lower()] = table_text
        
        # Handle MERGE statement aliases - special handling for MERGE INTO table alias
        if node.type == 'merge_statement' or node.type == '_merge_statement':
            # Look for the target table and its alias
            for i, child in enumerate(node.children):
                if child.type == 'object_reference' and i < len(node.children) - 1:
                    table_text = normalized_sql[child.start_byte:child.end_byte].strip()
                    next_child = node.children[i + 1]
                    if next_child.type == 'identifier':
                        alias_text = normalized_sql[next_child.start_byte:next_child.end_byte].strip()
                        if alias_text:
                            table_aliases[alias_text.lower()] = table_text
                
                # Handle USING clause aliases
                if child.type == 'using':
                    for subchild in child.children:
                        if subchild.type == 'subquery':
                            # For subqueries, we can't easily determine the "real" table name
                            # So we'll use the alias with a special marker
                            next_sibling = subchild.next_sibling
                            if next_sibling and next_sibling.type == 'identifier':
                                alias_text = normalized_sql[next_sibling.start_byte:next_sibling.end_byte].strip()
                                if alias_text:
                                    table_aliases[alias_text.lower()] = f"SUBQUERY_{alias_text}"
        
        # Recursively process children
        for child in node.children:
            identify_tables(child)
    
    # Second pass: extract columns
    def extract_column_info(node):
        # Handle INSERT statements with column lists
        if node.type == '_insert_statement' or node.type == 'insert_statement':
            target_table = None
            column_list_node = None
            
            # Find the table name and column list
            for child in node.children:
                if child.type == 'object_reference' or child.type == 'relation':
                    target_table = normalized_sql[child.start_byte:child.end_byte].strip()
                elif child.type == 'list' and child.start_byte > 0 and normalized_sql[child.start_byte-1:child.start_byte] == '(':
                    column_list_node = child
            
            # Extract columns from the column list
            if column_list_node:
                for child in column_list_node.children:
                    if child.type == 'identifier':
                        column_name = normalized_sql[child.start_byte:child.end_byte].strip()
                        if column_name and is_valid_column_name(column_name):  # Check if valid
                            columns.append({
                                'column_name': column_name,
                                'table_name': target_table or ''
                            })
        
        # Handle field references in WHERE, SELECT, etc.
        elif node.type == 'field' or (node.type == 'identifier' and node.parent and node.parent.type != 'relation'):
            column_text = normalized_sql[node.start_byte:node.end_byte].strip()
            if not column_text or not is_valid_column_name(column_text):  # Skip if empty or invalid
                return
                
            # Skip if this is a table name or a PL/SQL variable
            if (column_text.lower() in tables or 
                column_text.lower() in table_aliases or
                column_text.lower().startswith('v_') or
                column_text.lower().startswith('p_')):
                return
                
            # Skip common SQL functions and keywords
            if column_text.lower() in SQL_KEYWORDS:
                return
                
            # Skip PL/SQL variables and parameters
            if column_text.startswith(':') or column_text.startswith('&'):
                return
            
            # Handle qualified column names (table.column)
            table_name = ''
            if '.' in column_text:
                parts = column_text.split('.')
                if len(parts) == 2:
                    potential_alias = parts[0].lower()
                    # Check if this is an alias and resolve it to the actual table name
                    if potential_alias in table_aliases:
                        table_name = table_aliases[potential_alias]
                    else:
                        # If not a known alias, use as is (might be a schema.table reference)
                        table_name = parts[0]
                    column_text = parts[1]  # Use only the column part
                    
                    # Skip if the column part is not a valid name
                    if not is_valid_column_name(column_text):
                        return
            
            # Try to determine the associated table from context
            if not table_name and node.parent and node.parent.type == '_qualified_field':
                for sibling in node.parent.children:
                    if sibling.type == 'object_reference':
                        potential_alias = normalized_sql[sibling.start_byte:sibling.end_byte].strip().lower()
                        # Check if this is an alias and resolve it
                        if potential_alias in table_aliases:
                            table_name = table_aliases[potential_alias]
                        else:
                            table_name = normalized_sql[sibling.start_byte:sibling.end_byte].strip()
            
            # If still no table name and we have a default table, use it
            if not table_name and default_tables:
                # Use the first table in the FROM clause for unqualified columns
                table_name = default_tables[0]
            
            columns.append({
                'column_name': column_text,
                'table_name': table_name or ''
            })
        
        # Recursively process children
        for child in node.children:
            extract_column_info(child)
    
    # Run the two passes
    identify_tables(sql_tree.root_node)
    extract_column_info(sql_tree.root_node)
    
    # Filter out duplicates and PL/SQL variables
    unique_columns = []
    seen = set()
    
    for col in columns:
        column_name = col['column_name']
        table_name = col.get('table_name', '')
        
        if not column_name:  # Skip if column name is empty
            continue
            
        # Skip PL/SQL variables and parameters
        if (column_name.lower().startswith('v_') or 
            column_name.lower().startswith('p_') or
            column_name.lower().startswith('l_') or
            column_name.lower().startswith('g_')):
            continue
            
        # Skip if it's a table name or alias
        if column_name.lower() in tables or column_name.lower() in table_aliases:
            continue
            
        # Skip if it contains a dot (qualified name that wasn't properly parsed)
        if '.' in column_name:
            continue
            
        # Fix truncated table names (like "tst_mploys" instead of "test_employees")
        if table_name.lower() in table_aliases:
            table_name = table_aliases[table_name.lower()]
            
        # Check if table_name is actually a SQL function
        if table_name.lower() in SQL_KEYWORDS:
            table_name = ''
            
        # Create a unique key for this column
        key = (column_name.lower(), table_name.lower() if table_name else '')
        
        # Skip if we've seen this column before
        if key in seen:
            continue
            
        seen.add(key)
        unique_columns.append({
            'column_name': column_name,
            'table_name': table_name
        })
    
    return unique_columns

def is_valid_column_name(name):
    """
    Validate if a name follows SQL naming conventions:
    - First character must be a letter (A-Z, a-z) or underscore
    - Subsequent characters can be letters, numbers, or underscore
    - No special characters except underscore
    - No blanks
    - Not a SQL keyword or index-related term
    - Not a PL/SQL variable (v_, p_, l_, g_ prefixes)
    - Not a single character
    - Not a date format pattern
    - Not a generic term like 'column' or 'quantile'
    """
    if not name:
        return False
    
    # Remove quotes if they exist
    name = name.strip('"\'`[]')
    
    # Check if the name contains invalid special characters
    if '=' in name or '/' in name or ' ' in name:
        return False
    
    # Skip SQL keywords
    if name.lower() in SQL_KEYWORDS:
        return False
    
    # Skip index-related terms
    if name.lower() in ['index', 'unique', 'bitmap', 'function-based', 'reverse']:
        return False
    
    # Skip PL/SQL variables
    if (name.lower().startswith('v_') or 
        name.lower().startswith('p_') or 
        name.lower().startswith('l_') or 
        name.lower().startswith('g_')):
        return False
    
    # Skip all single character names
    if len(name) == 1:
        return False
    
    # Skip date format patterns
    date_patterns = [
        'dd', 'mm', 'yy', 'yyyy', 'hh', 'mi', 'ss', 
        'ddmmyy', 'ddmmyyyy', 'mmddyy', 'mmddyyyy', 'yyyymmdd', 'yymmdd',
        'ddmonyy', 'ddmonyyyy', 'monddyy', 'monddyyyy'
    ]
    if name.lower() in date_patterns:
        return False
    
    # Skip generic terms
    generic_terms = [
        'column', 'columns', 'col', 'cols', 
        'quantile', 'quantiles', 
        'field', 'fields', 
        'value', 'values', 
        'variable', 'variables', 
        'parameter', 'parameters',
        'temp', 'temporary', 'tmp', "par", "mis", "transfo"
    ]
    if name.lower() in generic_terms:
        return False
    
    # Regular expression for SQL naming convention
    sql_name_pattern = r'^[a-zA-Z_][a-zA-Z0-9_]*$'
    return bool(re.match(sql_name_pattern, name))

# Add SQL keywords set (expanded from SAS_KEYWORDS in columns.py)
SQL_KEYWORDS = {
    'and', 'as', 'by', 'delete', 'drop', 'else', 'end', 'from', 'group', 'having',
    'if', 'in', 'into', 'join', 'left', 'like', 'not', 'null', 'on', 'or', 'order',
    'outer', 'right', 'set', 'then', 'union', 'update', 'where', 'while',
    'select', 'insert', 'create', 'alter', 'drop', 'truncate', 'grant', 'revoke',
    'commit', 'rollback', 'savepoint', 'with', 'case', 'when', 'exists', 'between',
    'distinct', 'all', 'any', 'some', 'check', 'constraint', 'foreign', 'primary',
    'references', 'unique', 'default', 'index', 'table', 'view', 'procedure', 'function',
    'trigger', 'package', 'begin', 'exception', 'declare', 'cursor', 'for', 'loop',
    'exit', 'continue', 'return', 'sysdate', 'current_date', 'current_timestamp',
    'count', 'sum', 'avg', 'min', 'max', 'nvl', 'decode', 'rownum', 'rowid',
    'merge', 'using', 'matched', 'values', 'sequence', 'synonym', 'type', 'numer', 'varchar2', 'pragma',
    # Add more SQL functions
    'substr', 'substring', 'to_char', 'to_date', 'to_number', 'to_timestamp',
    'length', 'instr', 'replace', 'trim', 'ltrim', 'rtrim', 'upper', 'lower', 'initcap',
    'round', 'trunc', 'floor', 'ceil', 'mod', 'abs', 'sign', 'power', 'sqrt',
    'extract', 'months_between', 'add_months', 'last_day', 'next_day',
    'greatest', 'least', 'coalesce', 'nullif', 'lag', 'lead', 'first_value', 'last_value',
    'rank', 'dense_rank', 'row_number', 'ntile', 'listagg', 'regexp_like', 'regexp_replace',
    'regexp_substr', 'regexp_instr', 'regexp_count', 'cast', 'convert', 'sys_context',
    'subquery', 'xmlagg', 'xmlelement', 'xmlforest', 'json_object', 'json_array', "(", "_"
}

def extract_plsql_from_shl(script):
        matches = re.findall(r'sqlplus\s+/nolog\s*<ENDSQL.*?\n(.*?)(?=\nENDSQL\b)', script, flags=re.DOTALL)
        return '\n'.join(matches)

def analyze_plsql_file(file_path: str, sql_parser: SQLParser):
    """Analyze a single PL/SQL file and extract SQL information, objects, and columns"""
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    # Helper function to validate table names
    def is_valid_table_name(name):
        if not name:
            return False
        # Check for invalid characters
        invalid_chars = ['(', ')', ':', '/', ',', ';', '=', '+', '-', '*', '&', '%', '$', '#', '@', '!', '?', '<', '>', '{', '}', '[', ']']
        for char in invalid_chars:
            if char in name:
                return False
        # Check if it's just a single special character
        if len(name) == 1 and not name.isalnum() and name != '_':
            return False
        # Check if it's a SQL keyword
        if name.lower() in SQL_KEYWORDS:
            return False
        return True
    
    for encoding in encodings:
        try:
            if not file_path.endswith('.shl'):
                with open(file_path, 'r', encoding='utf8') as f:
                    plsql_script = f.read()
            else:
                with open(file_path, 'r', encoding='utf8') as f:
                    shl_script = f.read()
                plsql_script = extract_plsql_from_shl(shl_script)
                
            # Normalize the case of the entire script to lowercase
            # This ensures consistent processing of keywords like UPDATE, DELETE, etc.
            normalized_script = plsql_script.lower()
                
            # Extract objects first
            objects, modified_script = extract_objects(normalized_script)
            objects_df = pd.DataFrame(
                [(obj_type, obj_name, definition, line_num, os.path.relpath(file_path)) 
                 for obj_type, obj_name, definition, line_num in objects],
                columns=['Object_Type', 'Object_Name', 'Definition', 'Source_Line', 'Source_File']
            )
            
            # Process remaining SQL statements
            sql_statements = extract_sql(modified_script)
            tables = []
            columns_data = []
            
            for sql, line_num in sql_statements:
                # Skip empty SQL statements
                if not sql.strip():
                    continue
                
                # Process the SQL statement
                try:
                    normalized_sql = normalize_sql(sql)
                    
                    # Special handling for UPDATE statements
                    update_match = re.search(r'\bupdate\s+([^\s;]+)', normalized_sql, re.IGNORECASE)
                    if update_match:
                        table_ref = update_match.group(1)
                        
                        # Extract schema and table
                        if '.' in table_ref:
                            schema, table = table_ref.split('.', 1)
                        else:
                            schema, table = '', table_ref
                        
                        # Remove quotation marks from table name
                        table = str(table).replace('"', '') if table else ''
                        schema = str(schema).replace('"', '') if schema else ''
                        
                        # Validate table name before adding
                        if is_valid_table_name(table):
                            # Make sure this entry is added to the tables list
                            tables.append({
                                'type': 'output',  # UPDATE modifies data
                                'step_type': 'update',  # Lowercase for consistency
                                'schema': schema.lower(),
                                'table': table.lower(),
                                'Source_Line': line_num,
                                'join_condition': None,
                                'involved_tables': None,
                                'code_block': sql,
                                'Source_File': os.path.relpath(file_path)
                            })
                    
                    # Special handling for DELETE statements
                    delete_match = re.search(r'\bdelete\s+(?:from\s+)?([^\s;]+)', normalized_sql, re.IGNORECASE)
                    if delete_match:
                        table_ref = delete_match.group(1)
                        
                        # Extract schema and table
                        if '.' in table_ref:
                            schema, table = table_ref.split('.', 1)
                        else:
                            schema, table = '', table_ref
                        
                        # Remove quotation marks from table name
                        table = str(table).replace('"', '') if table else ''
                        schema = str(schema).replace('"', '') if schema else ''
                        
                        # Validate table name before adding
                        if is_valid_table_name(table):
                            # Make sure this entry is added to the tables list
                            tables.append({
                                'type': 'output',  # DELETE modifies data
                                'step_type': 'delete',  # Lowercase for consistency
                                'schema': schema.lower(),
                                'table': table.lower(),
                                'Source_Line': line_num,
                                'join_condition': None,
                                'involved_tables': None,
                                'code_block': sql,
                                'Source_File': os.path.relpath(file_path)
                            })
                    
                    # Special handling for GRANT/REVOKE statements
                    grant_match = re.search(r'\b(grant|revoke)\s+(select|insert|update|delete|all).*?\bon\b\s+([^\s;]+)', 
                                           normalized_sql, re.IGNORECASE)
                    if grant_match:
                        privilege_type = grant_match.group(1).lower()  # Lowercase for consistency
                        table_ref = grant_match.group(3)
                        
                        # Extract schema and table
                        if '.' in table_ref:
                            schema, table = table_ref.split('.', 1)
                        else:
                            schema, table = '', table_ref
                        
                        # Remove quotation marks from table name
                        table = str(table).replace('"', '') if table else ''
                        schema = str(schema).replace('"', '') if schema else ''
                        
                        # Validate table name before adding
                        if is_valid_table_name(table):
                            tables.append({
                                'type': 'input',
                                'step_type': privilege_type,
                                'schema': schema.lower(),
                                'table': table.lower(),
                                'Source_Line': line_num,
                                'join_condition': None,
                                'involved_tables': None,
                                'code_block': sql,
                                'Source_File': os.path.relpath(file_path)
                            })
                    
                    # Try to use the SQL parser for regular processing
                    try:
                        sql_tree = sql_parser.parse(normalized_sql)
                        sql_processor = ASTProcessor(normalized_sql)
                        sql_processor.previous_tables = []
                        sql_processor.traverse_tree(sql_tree.root_node)
                        
                        # Only add processor results if we got some tables
                        if not sql_processor.df.empty:
                            for _, row in sql_processor.df.iterrows():
                                # Remove quotation marks from table and schema names
                                table_name = row.get('Table', '')
                                schema_name = row.get('Library', '')
                                
                                # Convert to string before using replace
                                if table_name is not None:
                                    table_name = str(table_name).replace('"', '') if isinstance(table_name, (str, float, int)) else ''
                                else:
                                    table_name = ''
                                    
                                if schema_name is not None:
                                    schema_name = str(schema_name).replace('"', '') if isinstance(schema_name, (str, float, int)) else ''
                                else:
                                    schema_name = ''
                                
                                # Validate table name before adding
                                if is_valid_table_name(table_name):
                                    tables.append({
                                        'type': 'input' if row.get('Input/Output') == 'Input' else 'output',
                                        'step_type': row.get('Operation', 'unknown').lower(),  # Lowercase for consistency
                                        'schema': schema_name.lower(),
                                        'table': table_name.lower(),
                                        'Source_Line': line_num,
                                        'join_condition': row.get('Condition'),
                                        'involved_tables': row.get('Involved Tables'),
                                        'code_block': sql,
                                        'Source_File': os.path.relpath(file_path)
                                    })
                    except Exception as parser_error:
                        # If parser fails, log the error but continue with our regex-based extraction
                        print(f"SQL parser error for statement at line {line_num}: {str(parser_error)}")
                        # We already added UPDATE/DELETE/GRANT statements above, so no need to do anything here
                    
                    # Extract columns from the SQL statement
                    columns = extract_columns(sql, sql_parser)
                    for column in columns:
                        # Remove quotation marks from table names in columns
                        table_name = column.get('table_name', '')
                        column_name = column.get('column_name', '')
                        
                        # Convert to string before using replace
                        if table_name is not None:
                            table_name = str(table_name).replace('"', '') if isinstance(table_name, (str, float, int)) else ''
                        else:
                            table_name = ''
                            
                        if column_name is not None:
                            column_name = str(column_name).replace('"', '') if isinstance(column_name, (str, float, int)) else ''
                        else:
                            column_name = ''
                        
                        # Validate table name before adding
                        if is_valid_table_name(table_name) or not table_name:  # Allow empty table names for columns
                            column_data = {
                                'column_name': column_name.lower(),  # Lowercase for consistency
                                'table_name': table_name.lower(),    # Lowercase for consistency
                                'Source_Line': line_num,
                                'Source_File': os.path.relpath(file_path),
                                'code_block': sql
                            }
                            columns_data.append(column_data)
                except Exception as e:
                    print(f"Error processing SQL statement at line {line_num} in {file_path}: {str(e)}")
                    continue
            
            # Create DataFrames
            tables_df = pd.DataFrame(tables) if tables else pd.DataFrame()
            columns_df = pd.DataFrame(columns_data) if columns_data else pd.DataFrame()
            
            # Post-processing: Replace NaN values and "nan" strings with empty strings
            if not tables_df.empty:
                # Replace actual NaN values
                tables_df['schema'] = tables_df['schema'].fillna('')
                # Replace "nan" strings
                tables_df['schema'] = tables_df['schema'].apply(lambda x: '' if str(x).lower() == 'nan' else x)

            if not columns_df.empty:
                # Replace actual NaN values
                columns_df['table_name'] = columns_df['table_name'].fillna('')
                # Replace "nan" strings
                columns_df['table_name'] = columns_df['table_name'].apply(lambda x: '' if str(x).lower() == 'nan' else x)
            
            # New feature: Associate columns with the only table in a code block
            if not columns_df.empty and not tables_df.empty:
                # Group columns by code_block
                for code_block, group in columns_df.groupby('code_block'):
                    # Find columns with empty table_name in this code block
                    empty_table_mask = (group['table_name'] == '')
                    if empty_table_mask.any():
                        # Find tables referenced in this code block
                        tables_in_block = tables_df[tables_df['code_block'] == code_block]['table'].unique()
                        # If there's exactly one table, associate all columns with it
                        if len(tables_in_block) == 1:
                            table_name = tables_in_block[0]
                            # Update the table_name for columns with empty table_name
                            columns_df.loc[
                                (columns_df['code_block'] == code_block) & 
                                (columns_df['table_name'] == ''), 
                                'table_name'
                            ] = table_name
            
            return tables_df, objects_df, columns_df
        
        except UnicodeDecodeError:
            if encoding == encodings[-1]:
                print(f"Failed to decode {file_path} with any of the attempted encodings")
                return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
            continue
        except Exception as e:
            print(f"Error processing {file_path}: {str(e)}")
            return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
    
    return pd.DataFrame(), pd.DataFrame(), pd.DataFrame()

def analyze_plsql_directory(directory_path: str, sql_grammar_path: str, output_db_path: str):
    """Analyze all PL/SQL files in a directory and save results to SQLite database"""
    # Initialize SQL parser
    sql_parser = SQLParser(sql_grammar_path, 'sql')
    
    # Initialize SQLite database
    conn = sqlite3.connect(output_db_path)
    
    # Drop existing tables if they exist to ensure correct schema
    conn.execute('DROP TABLE IF EXISTS sql_columns')
    
    # Create tables
    create_lineage_table = '''
    CREATE TABLE IF NOT EXISTS sql_lineage (
        type TEXT,
        step_type TEXT,
        schema TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        join_condition TEXT,
        involved_tables TEXT,
        code_block TEXT
    )
    '''
    
    create_objects_table = '''
    CREATE TABLE IF NOT EXISTS sql_objects (
        Object_Type TEXT,
        Object_Name TEXT,
        Definition TEXT,
        Source_Line INTEGER,
        Source_File TEXT
    )
    '''
    
    create_columns_table = '''
    CREATE TABLE IF NOT EXISTS sql_columns (
        column_name TEXT,
        table_name TEXT,
        Source_Line INTEGER,
        Source_File TEXT,
        code_block TEXT
    )
    '''
    
    conn.execute(create_lineage_table)
    conn.execute(create_objects_table)
    conn.execute(create_columns_table)
    
    try:
        file_count = 0
        all_tables = pd.DataFrame()
        all_objects = pd.DataFrame()
        all_columns = pd.DataFrame()
        
        for root, _, files in os.walk(directory_path):
            plsql_files = [f for f in files if f.endswith(('.sql', '.plsql', '.shl'))]            
            for plsql_file in plsql_files:
                file_path = os.path.join(root, plsql_file)
                print(f"Processing file: {file_path}")
                
                df_tables, df_objects, df_columns = analyze_plsql_file(file_path, sql_parser)
                
                if not df_tables.empty:
                    all_tables = pd.concat([all_tables, df_tables], ignore_index=True)
                if not df_objects.empty:
                    all_objects = pd.concat([all_objects, df_objects], ignore_index=True)
                if not df_columns.empty:
                    all_columns = pd.concat([all_columns, df_columns], ignore_index=True)
                file_count += 1
                
                # Write to database every 100 files
                if file_count % 100 == 0:
                    if not all_tables.empty:
                        all_tables.rename(columns={'table': 'table_name'}).to_sql(
                            'sql_lineage', conn, if_exists='append', index=False
                        )
                        all_tables = pd.DataFrame()
                    if not all_objects.empty:
                        all_objects.to_sql('sql_objects', conn, if_exists='append', index=False)
                        all_objects = pd.DataFrame()
                    if not all_columns.empty:
                        all_columns.to_sql('sql_columns', conn, if_exists='append', index=False)
                        all_columns = pd.DataFrame()
                    conn.commit()
        
        # Write remaining data
        if not all_tables.empty:
            all_tables.rename(columns={'table': 'table_name'}).to_sql(
                'sql_lineage', conn, if_exists='append', index=False
            )
        if not all_objects.empty:
            all_objects.to_sql('sql_objects', conn, if_exists='append', index=False)
        if not all_columns.empty:
            all_columns.to_sql('sql_columns', conn, if_exists='append', index=False)
        
        # Create indices
        print("Creating indices...")
        # Existing indices
        conn.execute('CREATE INDEX IF NOT EXISTS idx_schema ON sql_lineage(schema)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table ON sql_lineage(table_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_type ON sql_lineage(type)')
        
        # New indices for objects table
        conn.execute('CREATE INDEX IF NOT EXISTS idx_obj_type ON sql_objects(Object_Type)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_obj_name ON sql_objects(Object_Name)')
        
        # New indices for columns table
        conn.execute('CREATE INDEX IF NOT EXISTS idx_column_name ON sql_columns(column_name)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_table_name ON sql_columns(table_name)')
        
        # Remove duplicates from all tables
        print("Removing duplicates...")
        conn.execute('''
            DELETE FROM sql_lineage 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sql_lineage 
                GROUP BY 
                    LOWER(type),
                    LOWER(step_type),
                    LOWER(schema),
                    LOWER(table_name),
                    Source_Line,
                    Source_File
            )
        ''')
        
        conn.execute('''
            DELETE FROM sql_objects 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sql_objects 
                GROUP BY 
                    LOWER(Object_Type),
                    LOWER(Object_Name),
                    Source_Line,
                    Source_File
            )
        ''')
        
        conn.execute('''
            DELETE FROM sql_columns 
            WHERE rowid NOT IN (
                SELECT MIN(rowid) 
                FROM sql_columns 
                GROUP BY 
                    LOWER(column_name),
                    LOWER(table_name),
                    Source_Line,
                    Source_File
            )
        ''')
        
        # Additional post-processing: Associate columns with single tables in code blocks
        print("Associating orphaned columns with tables...")
        conn.execute('''
            UPDATE sql_columns
            SET table_name = (
                SELECT table_name FROM (
                    SELECT DISTINCT code_block, table_name
                    FROM sql_lineage
                    WHERE step_type != 'into'  -- Ignore 'into' tables
                    GROUP BY code_block
                    HAVING COUNT(DISTINCT table_name) = 1
                ) single_table
                WHERE single_table.code_block = sql_columns.code_block
            )
            WHERE table_name = ''
            AND code_block IN (
                SELECT code_block
                FROM sql_lineage
                WHERE step_type != 'into'  -- Ignore 'into' tables
                GROUP BY code_block
                HAVING COUNT(DISTINCT table_name) = 1
            )
        ''')
        
        # Additional post-processing: Handle PL/SQL INTO statements
        # Modified to specifically target FROM tables
        print("Handling PL/SQL INTO statements...")
        conn.execute('''
            UPDATE sql_columns
            SET table_name = (
                SELECT table_name FROM sql_lineage
                WHERE sql_lineage.code_block = sql_columns.code_block
                AND sql_lineage.code_block LIKE '%INTO%'
                AND sql_lineage.code_block LIKE '%FROM%'
                AND step_type != 'into'  -- Ignore 'into' tables
                LIMIT 1
            )
            WHERE table_name = ''
            AND code_block LIKE '%INTO%'
            AND code_block LIKE '%FROM%'
        ''')
        
        conn.commit()
        print(f"\nProcessed {file_count} files")
        print(f"Information saved to {output_db_path}")
    
    except Exception as e:
        print(f"Error during processing: {str(e)}")
        traceback.print_exc()  # Print the full traceback for better debugging
    
    finally:
        conn.close()

if __name__ == "__main__":
    import paths
    
    input_directory = os.path.join(paths.INPUT_PATH, "plsql")
    sql_grammar_path = paths.SQL_GRAMMAR_FILE
    output_db = os.path.join(paths.OUTPUT_PATH, "plsql_lineage.db")
    
    analyze_plsql_directory(input_directory, sql_grammar_path, output_db)
