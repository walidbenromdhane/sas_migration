// Remarks and known issues:  
// (1) %sysfunc is not detected within an %if statement in a macro 
//  %if %sysfunc(fileexist("&path_mft./RA_Prets.csv")). The % might need to be removed for the parser to work correctly.
// (2) Comments cause a lot of issues, especially when they are placed inside the statements
// (3) PROC SQL statements are deteceted separately
// (4) If a statement that contains a ';' is nested in another statement that ends with ';', the second ';' is not be parsed correctly.

module.exports = grammar({
    name: 'sas',
  
    conflicts: $ => [[$.put_variable_list, $._expression]],
    
    rules: {
      // Starting rule for parsing SAS files
      source_file: $ => repeat($._statement),
  
      // Main statement rule with prioritized order
      _statement: $ => choice(
        $.assignment_statement,
        $.array_statement,
        $.comment,
        $.call_symput_statement,
        //$.call_statement,
        $.do_block,
        $.data_step,
        $.drop_statement,
        $.sysfunc,
        $.format_statement,
        $.function_call,
        $.file_statement,
        $.filename_statement,
        $.global_statement,
        $.input_statement,
        $.infile_statement,
        $.informat_statement,
        $.if_statement,
        $.keep_statement,
        $.keyword,
        $.let_statement,
        $.length_statement,
        $.libname_statement,
        $.macro_call,
        $.macro_definition,
        $.ods_statement,
        $.outfile_statement,
        $.output_statement,
        $.pipe_statement,
        $.put_statement,
        $.proc_import,
        $.proc_export,
        $.proc_print,
        $.proc_sort_statement,
        $.set_statement
      ),
      
      keyword: $ => choice(
          'eof',
          'delete'),
  
      // Reserved keywords as tokens
      AND: $ => /[aA][nN][dD]/,
      ARRAY: $ => /[aA][rR][rR][aA][yY]/,
      BY: $ => /[bB][yY]/,
      CALL: $ => /[cC][aA][lL][lL]/,
      CALL_SYMPUT: $ => /[cC][aA][lL][lL] [sS][yY][mM][pP][uU][tT]/,
      CLOSE: $ => /[cC][lL][oO][sS][eE]/,
      DATA: $ => /[dD][aA][tT][aA]/,
      DEVICE: $ => /[dD][eE][vV][iI][cC][eE]/,
      DESCENDING: $ => /[dD][eE][sS][cC][eE][nN][dD][iI][nN][gG]/,
      DOLLAR: $ => /\$/,
      DO: $ => /%?[dD][oO]/,
      DROP: $ => /[dD][rR][oO][pP]/,
      DSD: $ => /[dD][sS][dD]/,
      END: $ => /%?[eE][nN][dD]/,
      ELSE: $ => /%?[eE][lL][sS][eE]/,
      EQ: $ => /%?[eE][qQ]/,
      EXCEL: $ => /[eE][xX][cC][eE][lL]/,
      FILE: $ => /[fF][iI][lL][eE]/,
      FILENAME: $ => /[fF][iI][lL][eE][nN][aA][mM][eE]/,
      FORMAT: $ => /[fF][oO][rR][mM][aA][tT]/,
      GLOBAL: $ => /%[gG][lL][oO][bB][aA][lL]/,
      GE: $ => /%[gG][eE]/,
      GT: $ => /%[gG][tT]/,
      HTML: $ => /[hH][tT][mM][lL]/,
      IF: $ => /%?[iI][fF]/,
      IN: $ => /[iI][nN]/,
      INFILE: $ => /[iI][nN][fF][iI][lL][eE]/,
      INFORMAT: $ => /[iI][nN][fF][oO][rR][mM][aA][tT]/,
      INPUT: $ => /[iI][nN][pP][uU][tT]/,
      KEEP: $ => /[kK][eE][eE][pP]/,
      LABEL: $ => /[lL][aA][bB][eE][lL]/,
      LET: $ => /%[lL][eE][tT]/,
      LENGTH: $ => /[lL][eE][nN][gG][tT][hH]/,
      LIBNAME: $ => /[lL][iI][bB][nN][aA][mM][eE]/,
      LRECL: $ => /[lL][rR][eE][cC][lL]/,
      LE: $ => /[lL][eE]/,
      LT: $ => /[lL][tT]/,
      MACRO: $ => /%[mM][aA][cC][rR][oO]/,
      MEND: $ => /%[mM][eE][nN][dD]/,
      NE: $ => /[nN][eE]/,
      NOOBS: $ => /[nN][oO][oO][bB][sS]/,
      NOT: $ => /[nN][oO][tT]/,
      NOT_IN: $ => /[nN][oO][tT] [iI][nN]/,
      ODS: $ => /[oO][dD][sS]/,
      OF: $ => /[oO][fF]/,
      OR: $ => /[oO][rR]/,
      OUTFILE: $ => /[oO][uU][tT][fF][iI][lL][eE]/,
      OUTPUT: $ => /[oO][uU][tT][pP][uU][tT]/,
      PDF: $ => /[pP][dD][fF]/,
      PIPE: $ => /[pP][iI][pP][eE]/,
      PROC_SORT: $ => /[pP][rR][oO][cC] [sS][oO][rR][tT]/,
      PROC_EXPORT: $ => /[pP][rR][oO][cC] [eE][xX][pP][oO][rR][tT]/,
      PROC_IMPORT: $ => /[pP][rR][oO][cC] [iI][mM][pP][oO][rR][tT]/,
      PROC_PRINT: $ => /[pP][rR][oO][cC] [pP][rR][iI][nN][tT]/,
      PROC_SQL: $ => /[pP][rR][oO][cC] [sS][qQ][lL]/,
      PUT: $ => /%?[pP][uU][tT]/,
      QUIT: $ => /[qQ][uU][iI][tT]/,
      RECFM: $ => /[rR][eE][cC][fF][mM]/,
      RUN: $ => /[rR][uU][nN]/,
      SET: $ => /[sS][eE][tT]/,
      SYSFUNC: $ => /%?[sS][yY][sS][fF][uU][nN][cC]/,
      THEN: $ => /%?[tT][hH][eE][nN]/,
      TO: $ => /%?[tT][oO]/,
  
  
      // LIBNAME statement
      libname_statement: $ => seq(
        field('keyword', alias($.LIBNAME, 'libname_keyword')),
        field('libref', $.identifier),
        optional(field('engine', $.identifier)),
        optional(field('path', choice($.string, $.macro_variable))),
        optional(field('options', $.libname_options)),
        ';'
      ),
  
      // DATA step structure
      data_step: $ => seq(
        $.DATA,                              // "DATA" keyword
        repeat1(                             // Allows multiple datasets
          seq(
            choice(
              $.identifier,                  // Simple dataset name
              seq($.identifier, '.', $.identifier), // Library.dataset format
              seq($.identifier, '.', $.identifier, $.macro_variable) // Library.dataset format
            ),
            optional($.dataset_options)      // Optional dataset options like (drop=...)
          )
        ),
        ';',                                 // Statement terminator
        repeat($._statement),                // Body of the DATA step
        $.RUN,                               // "RUN" keyword
        ';'                                  // End of DATA step
      ),
  
      dataset_options: $ => seq(
        '(',                              		// Open parenthesis
        repeat1(seq(
          field('option_name', $.identifier), 	// Option name (e.g., "drop")
          '=',                              		// Equal sign
          field('option_value', choice(
            $.identifier,                  		// Variable name
            $.string,                      		// String value
            $._expression,
            $.macro_variable               		// Macro variable (e.g., `&var`)
          )),
          optional(',')                    		// Optional comma for multiple options
        )),
        ')'                               		// Close parenthesis
      ),
  
      length_statement: $ => seq(
        $.LENGTH,                           		// "LENGTH" keyword
        repeat1(seq(
          field('variable', $.identifier), 		// Variable name
          optional(field('type', '$')),    	    // Optional type indicator (e.g., `$` for character)
          optional(field('length', $.number))     // Length of the variable (e.g., `13`)
          )),
        ';'
      ),
  
      format_statement: $ => seq(
        $.FORMAT,                           		// "FORMAT" keyword
        repeat1(seq(
          field('variable', $.identifier), 		// Variable name
          field('format', $.format_identifier)    // Format name (e.g., `$CHAR13.`)
        )),
        ';'
      ),
  
      informat_statement: $ => seq(
        $.INFORMAT,                           	// "INFORMAT" keyword
        repeat1(seq(
          field('variable', $.identifier), 		// Variable name
          field('format', $.format_identifier)    // Format name (e.g., `$CHAR13.`)
        )),
        ';'
      ),	
  
      format_identifier: $ => seq(
        optional('$'),               // Optional "$" for character formats
        optional(/[a-zA-Z_][a-zA-Z0-9_]*/),    // Base format name
        optional(/[0-9]+/),          // Optional numeric length
        '.'                          // Required dot at the end
      ),
  
          // DATA step structure
      proc_sql: $ => seq(
          $.PROC_SQL, 
          $.identifier,
          ';',                                  
          repeat($._statement),                
          $.QUIT,                               
          ';'                                  
      ),
      proc_import: $ => seq(
        $.PROC_IMPORT,
        repeat($.proc_option),
        ';',
        $.RUN,
        ';'
      ),
  
      proc_export: $ => seq(
        $.PROC_EXPORT,
        repeat($.proc_option),
        ';',
        $.RUN,
        ';'
      ),
      
      proc_print: $ => seq(
        $.PROC_PRINT,         // "PROC PRINT" keyword (case-insensitive)
        optional(seq(
          field('data_option', $.DATA),  // "DATA=" option
          '=', 
          field('dataset', $.identifier) // Dataset to print
        )),
        repeat($.print_option),          // Additional options (e.g., NOOBS, LABEL)
        ';',                             // Terminator for PROC PRINT
        seq($.RUN,';')       			   // Optional RUN statement
      ),
      
      print_option: $ => choice(
        $.NOOBS,          // Suppress observation numbers
        $.LABEL           // Use labels for variables
      ),
  
  
      // Output statement
      output_statement: $ => seq($.OUTPUT, ';'),
  
      // PUT statement
      put_statement: $ => seq(
          $.PUT,
          field('display_content', repeat(choice(
              /[a-zA-Z0-9_:]+/, // Matches words, colons, underscores, and numbers.
              /\s+/,            // Matches spaces or whitespace.
              /["'][^"']*["']/, // Matches quoted strings (single or double quotes).
              /[^;\s]+/         // Matches any other characters except semicolon or spaces.
          ))),
          ';'
      ),
      put_variable_list: $ => repeat1(
        seq($.identifier, optional($.format_specifier)) // Variable + optional format
      ),
      
      // Format specifier for PUT statement
      format_specifier: $ => seq(
        '.',                      // Indicates the start of a format
        choice(
          $.identifier,           // Format name (e.g., `dollar`)
          $.number                // Format width (e.g., `8.2`)
        )
      ),
  
      // Assignment statement
      assignment_statement: $ => prec.right(seq(
        $.identifier,
        '=',
        $._expression,
        optional(';')
      )),
  
  
      call_symput_statement: $ => prec.left(4,seq(
        $.CALL_SYMPUT,
        '(',
        field('variable_name', $.string),
        ',',
        field('variable_value', $._expression),
        ')',
        optional(';')
      )),
  
      
      // General CALL statement to support various routines
  //	call_statement: $ => choice(
  //	  prec(2, $.call_symput_statement),  // Higher precedence for `CALL SYMPUT`
  //	  seq(
  //		$.CALL,
  //		field('routine_name', $.identifier),  // General rule for other CALL routines
  //		'(',
  //		optional($.argument_list),
  //		')',
  //		';'
  //	  )
  //	),
  
      function_call: $ => seq(
        field('function_name', $.identifier), // Function name
        '(',                                  // Opening parenthesis
        optional($.argument_list),            // Optional argument list
        ')'
      ),
  
      sysfunc: $ => seq(
          $.SYSFUNC,
          '(',
          $.function_call,
          ')'
      ),
  
  
      // Argument list for CALL routines
      argument_list: $ => seq(
        optional($.OF),
        $._expression,
        optional(repeat(seq(',', $._expression)))
      ),
  
      // Tuple
      tuple: $ => seq(
          '(',
          $.atom,
          optional(repeat(seq(',', $.atom))),
          ')'
      ),
      
  
      // Expressions, including concatenation and macro variables
      _expression: $ => prec.left(5,choice(
        '.',
        $.atom,
        prec(5, $.macro_call),           // Macro calls (higher precedence)
        $.function_call,
        prec.left(5, seq(                // Relational operators
          $._expression,
          choice('=', '<', '>', '<=', '>=', '<>'),
          $._expression
        )),
        prec.left(5, seq(                // Logical operators
          $._expression,
          choice($.AND, $.OR, $.TO, $.IN, $.NOT_IN, $.NE, $.EQ, $.LT, $.GT, $.LE, $.GE, '/','+', '-', '*'),
          $._expression
        )),
        prec(5, seq($.NOT, $._expression)), // NOT operator
        prec(5, seq($._expression, $.IN, $.tuple)), 
        prec(5, seq($._expression, $.NOT_IN, $.tuple)), 
        prec.left(seq(                   // Concatenation (||)
          $._expression,
          '||',
          $._expression
        )),
        seq('(', $._expression, ')')     // Nested expressions
      )),
  
   
       // IF-THEN-ELSE statement
      if_statement: $ => prec.right(3, seq(
        $.IF,
        $._expression,                   
        $.THEN,
        $._statement,                    
        optional(seq($.ELSE, $._statement)), 
        optional($.END),                
        ';'                   
      )),
  
      // DO-END block for loops or grouping
      do_block: $ => seq(
        $.DO,
        optional($._expression),
        ';',
        repeat($._statement),
        $.END,
        ';'
      ),
  
      // ARRAY statement
      array_statement: $ => seq(
        $.ARRAY,                                // ARRAY keyword
        $.identifier,                           // Array name
        optional(choice(                        // Optional dimensions in parentheses or curly braces
          seq('(', choice($.number,'*'), ')'),              // Parentheses for dimensions
          seq('{', choice($.number,'*'), '}')               // Curly braces for dimensions
        )),
        optional(field('variables', choice(     // Variables defined in the array
          seq($.identifier, '-', $.identifier), // Variable range (e.g., var1-var3)
          repeat1($.identifier)                 // List of variables
        ))),
        ';'                                     // Statement terminator
      ),
  
      // KEEP statement
      keep_statement: $ => seq(
        $.KEEP,
        repeat1($.identifier),
        ';'
      ),
  
      // DROP statement
      drop_statement: $ => seq(
        $.DROP,
        repeat1($.identifier),
        ';'
      ),
  
      // SET statement
      set_statement: $ => seq(
        $.SET,
        repeat1(choice($.identifier,
               seq($.identifier,'.',$.identifier),
               seq($.identifier,'.',$.identifier,$.macro_variable))),
        ';'
      ),
  
      // LET statement for macros
      let_statement: $ => seq(
        $.LET,                                        // "%LET" keyword
        field('variable_name', $.identifier),         // Variable name
        '=',                                          // Equal sign
        optional(field('variable_value', $.let_value)), // Handle complex value
        ';'                                          // Terminator
      ),
      
      
      let_value: $ => choice(
        $.string,                  // Quoted strings (e.g., "value")
        $.parenthesized_expression, // Parenthesized structures (e.g., `(dsn=... authdomain=...)`)
        $.identifier,              // Simple identifiers
        repeat1($.any_character)   // Catch-all for unstructured content
      ),
  
      parenthesized_expression: $ => seq(
        '(',
        repeat(choice($.identifier, '=', $.string, $.number, $.whitespace)),
        ')'
      ),
      
      whitespace: $ => /[ \t\r\n]+/,
      any_character: $ => /[^;]+/, // Matches any characters up to the semicolon
          
      
  
      // INFILE statement
      infile_statement: $ => seq(
        $.INFILE,
        choice($.string,$.identifier),
        optional(repeat($.file_option)),
        ';'
      ),
  
      // OUTFILE statement
      outfile_statement: $ => seq(
        $.OUTFILE,
        $.string,
        optional(repeat($.file_option)),
        ';'
      ),
  
      // Rule for FILE statement
      file_statement: $ => seq(
        $.FILE,                 // "FILE" keyword (case-insensitive)
        $.string,               // File path or external file
        optional(repeat($.file_option)),
        ';'                     // Statement terminator
      ),
      
      
      macro_definition: $ => seq(
        $.MACRO,                           // `%MACRO` keyword
        field('macro_name', $.identifier), // Macro name
        optional($.macro_parameters),  // Optional macro parameter list
        ';',
        repeat($._statement),   			// Macro body can include macro-specific and regular SAS statements
        $.MEND,                       	// `%MEND` keyword
        optional(field('macro_name', $.identifier)), // Optional repetition of macro name after `%MEND`
        ';'
      ),
  
  
      macro_parameters: $ => seq(
        '(',
        optional(seq(
          field('parameter', $.identifier),
          optional(seq('=', field('default_value', $._expression))), // Default parameter values
          repeat(seq(',', field('parameter', $.identifier),
                      optional(seq('=', field('default_value', $._expression)))))
        )),
        ')'
      ),
      
      macro_call: $ => seq(
        '%',                              // Percent sign for macro invocation
        field('macro_name', $.identifier), // Macro name
        optional(seq('(',$.argument_list,')')),  // Optional argument list
        ';'                               // End of macro invocation
      ),	
  
      global_statement: $ => seq(
        $.GLOBAL,                        // `%global` keyword
        repeat1($.identifier),            // One or more global variables
        ';'
      ),
      
      
      // Comments in SAS
      comment: $ => token(choice(
        seq('/*', /[^*]*\*+([^/*][^*]*\*+)*/, '/'),
        seq('*', /[^;]*;/)
      )),
  
      // Expression components
  //    _expression: $ => choice(
  //      $.number,
  //      $.identifier,
  //      seq('(', $._expression, ')'),
  //      prec.left(2, seq($._expression, choice('=', '<', '>', '<=', '>=', '<>'), $._expression)),
  //      prec.left(1, seq($._expression, choice('AND', 'OR'), $._expression)),
  //      prec(3, seq('NOT', $._expression))
  //    ),
  
      // Options for PROC and LIBNAME statements
      proc_option: $ => seq(
        field('option_name', $.identifier),
        optional(seq(
          '=',
          field('option_value', choice($.atom,
                                       seq($.identifier,'.',$.identifier),
                                       ))
        ))
      ),
  
      input_statement: $ => seq(
        $.INPUT,              // "input" keyword (case-insensitive)
        repeat1(seq(
          $.identifier,       // Variable name (e.g., var1, var2, etc.)
          optional($.DOLLAR) // Optional '$' for character variables
        )),
        ';'                   // Statement terminator
      ),
  
      libname_options: $ => repeat1(
        seq(
          field('option_name', $.identifier),
          '=',
          field('option_value', choice($.atom,
                                       seq($.identifier,'.',$.identifier)
                                       ))
        )
      ),
  
      file_option: $ => seq(
        field('option_name', $.identifier),        // Option name (e.g., "DSD", "LRECL", etc.)
        optional(seq(
          '=',                                     // Optional "=" sign
          field('option_value', choice(
            $.atom,
            $.keyword_option,                       // Keyword options like DEVICE, LRECL
            seq($.identifier, '.', $.identifier, optional($.macro_variable)), // Dot notation (e.g., dataset.variable)
          ))
        ))
      ),
  
      
      filename_statement: $ => seq(
        $.FILENAME,            // "FILENAME" keyword (case-insensitive)
        $.identifier,          // Fileref (name of the file reference)
        choice($.string,$.pipe_statement),              // File path or external file
        optional(repeat($.file_option)), // Optional filename options
        ';'                    // Statement terminator
      ),
      
      pipe_statement: $ => seq(
        $.PIPE,          						  // "PIPE" keyword
        field('command', $.string),             // OS command
      ),
      
      ods_statement: $ => seq(
        $.ODS,
        choice($.EXCEL, $.HTML, $.PDF),
        $.FILE, '=', $.string,
        optional(repeat1($.identifier)), // Ensures ods_option requires at least one identifier if present
        ';',
        optional(repeat1($._statement)), // Ensures ods_option requires at least one identifier if present
        $.ODS, choice($.EXCEL, $.HTML, $.PDF), $.CLOSE, ';'
      ),
  
      ods_option: $ => repeat($.identifier),
  
      proc_sort_statement: $ => seq(
        $.PROC_SORT,                					// "PROC_SORT" keyword
        optional($.proc_sort_options),                // Optional PROC SORT options
        ';',
        optional($.by_statement),                     // Optional BY statement for sorting
        optional($.RUN),
        ';',                    // Optional RUN statement to terminate
      ),	
  
      proc_sort_options: $ => repeat1(
        seq(
          field('option_name', choice($.identifier, $.SORT_OPTION)), // Option keyword
          optional(seq('=', field('option_value', choice($.identifier, $.string)))) // Optional value
        )
      ),
  
      SORT_OPTION: $ => choice(
        /[dD][aA][tT][aA]/,  // DATA=
        /[oO][uU][tT]/       // OUT=
      ),
      
      by_statement: $ => seq(
        $.BY,          				// "BY" keyword
        repeat1(choice(
          seq(alias($.DESCENDING, 'descending_keyword'), $.identifier), // DESCENDING variable
          $.identifier                                                  // Variable name
        )),
        ';'
      ),
      
  
      
      keyword_option: $ => choice(
        $.DEVICE,   // 
        $.LRECL 
      ),	
      
      // Basic components
      identifier: $ => /[a-zA-Z_][a-zA-Z0-9_]*/,
  
      
      macro_variable: $ => /&[a-zA-Z_][a-zA-Z0-9_]*\.?/,
      
      string: $ => choice(
        seq("'", /[^']*/, "'"),
        seq('"', /[^"]*/, '"'),
      ),
      
      number: $ => /-?\d+(\.\d*)?/,
      value: $ => /[a-zA-Z0-9]+/, 
      
      informat_identifier: $ => seq(
        choice(
          seq(
            /[a-zA-Z]+/, // Base informat name (e.g., 'yymmn')
            /\d+/,       // Width specification (e.g., '6')
            '.'          // Mandatory dot
          )
        )
      ),
      
      atom: $ => prec.left(6, choice(
          $.informat_identifier,
          $.number,
          $.value,
          $.identifier,
          $.string,
          $.macro_variable,
          '.'
      )),
  
    }
  });