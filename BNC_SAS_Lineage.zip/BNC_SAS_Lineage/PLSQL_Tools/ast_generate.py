from tree_sitter import Language, Parser
import pandas as pd
import paths, os

def generate_ast(file_path):
    """Generate and return AST for a SAS file"""
    # Load the SAS grammar
    LANGUAGE = Language(paths.PLSQL_GRAMMAR_FILE, 'plsql')
    parser = Parser()
    parser.set_language(LANGUAGE)
    
    # Read the file
    with open(file_path, 'r', encoding='utf-8') as f:
        code = f.read()
    
    # Parse the code
    tree = parser.parse(bytes(code, 'utf8'))
    
    return tree

def write_tree(node, output_file, level=0, code_lines=None):
    """Write the AST to a file in a readable format"""
    # Format the current node
    indent = "  " * level
    node_text = ""
    
    if code_lines and hasattr(node, 'start_point'):
        line_num = node.start_point[0]
        if line_num < len(code_lines):
            node_text = code_lines[line_num].strip()
    
    output_file.write(f"{indent}{node.type}: {node_text}\n")
    
    # Recursively write children
    for child in node.children:
        write_tree(child, output_file, level + 1, code_lines)

def main():
    # Get input directory
    directory_name = "PLSQL"  # Name of the directory under the "inputs" folder
    input_directory = os.path.join(paths.INPUT_PATH, directory_name)
    
    # Create output directory if it doesn't exist
    output_directory = os.path.join(paths.OUTPUT_PATH, "ast_output")
    os.makedirs(output_directory, exist_ok=True)
    
    # Process each SAS file in the directory
    for root, dirs, files in os.walk(input_directory):
        for file in files:
            if file.endswith('.sql'):
                file_path = os.path.join(root, file)
                print(f"Processing: {file_path}")
                
                try:
                    # Generate AST
                    tree = generate_ast(file_path)
                    
                    # Read code lines for reference
                    with open(file_path, 'r', encoding='utf-8') as f:
                        code_lines = f.readlines()
                    
                    # Create output file path
                    relative_path = os.path.relpath(root, input_directory)
                    output_subdir = os.path.join(output_directory, relative_path)
                    os.makedirs(output_subdir, exist_ok=True)
                    
                    output_file_path = os.path.join(
                        output_subdir, 
                        f"{os.path.splitext(file)[0]}_ast.txt"
                    )
                    
                    # Write the AST to file
                    with open(output_file_path, 'w', encoding='utf-8') as f:
                        f.write(f"Abstract Syntax Tree for: {file_path}\n")
                        f.write("=" * 80 + "\n\n")
                        write_tree(tree.root_node, f, code_lines=code_lines)
                    
                    print(f"AST written to: {output_file_path}")
                    
                except Exception as e:
                    print(f"Error processing {file_path}: {str(e)}")

if __name__ == "__main__":
    main()