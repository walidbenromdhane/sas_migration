from tree_sitter import Language, Parser
import pandas as pd
import paths

# Load the SAS grammar (you need to provide the compiled grammar path)
sas_so = paths.SAS_GRAMMAR_FILE

LANGUAGE = Language(sas_so, 'sas')  # Replace 'my-languages.so' with your compiled grammar
parser = Parser()
parser.set_language(LANGUAGE)

# Sample SAS tree-sitter input (replace this with the full AST input)
file = r""

# Parse the SAS file content
with open(file, 'r', encoding="utf-8") as f:
    code = f.read()

# sas_code = """
# PROC COPY IN=sasdat.dataset1 OUT=refwrr.dataset2 MTYPE=(DATA);
# PROC MEANS DATA=wrk.donnees_ajout OUTPUT=out_means;
# PROC SQL; CREATE TABLE work.result AS SELECT * FROM input_table; QUIT;
# """

# Parse the SAS code
tree = parser.parse(bytes(code, "utf8"))
root_node = tree.root_node

def extract_tables_from_proc(node):
    tables = []
    if node.type == "proc_statement":
        # Extract text and search for table references
        text = node.text.decode('utf-8')
        print(f"Processing proc_statement:\n{text}\n")

        # Basic heuristic to capture tables: Look for "DATA=", "OUT=", "IN=", "FROM", etc.
        for keyword in ["DATA=", "OUT=", "IN=", "FROM", "TABLE"]:
            parts = text.split(keyword)
            if len(parts) > 1:
                table_ref = parts[1].split()[0].strip(';').strip(',')
                tables.append(table_ref)
    # Recursively check children
    for child in node.children:
        tables.extend(extract_tables_from_proc(child))
    return tables

# Function to traverse the AST and find proc_statement nodes
def find_proc_statements_and_tables(node):
    tables = []
    if node.type == "proc_statement":
        tables.extend(extract_tables_from_proc(node))
    # Recursively traverse child nodes
    for child in node.children:
        tables.extend(find_proc_statements_and_tables(child))
    return tables

# Extract tables from all proc_statement nodes
print("Extracting tables from proc_statement nodes...\n")
tables = find_proc_statements_and_tables(root_node)

# Convert the list of tables to a DataFrame
df = pd.DataFrame({"Table References": tables})

# Save to Excel
output_file = "proc_statement_tables.xlsx"
df.to_excel(output_file, index=False)
print(f"Excel file saved as {output_file}")