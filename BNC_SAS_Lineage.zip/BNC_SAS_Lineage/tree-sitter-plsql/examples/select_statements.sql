SELECT abcd,
       cdejfsdf,
       sdfkjslkdfj,
       sysdate as abcd,
       sysdate(a,b) -- Test
INTO   asffs,
       sdfsdf
FROM   dsv_abcd,
       dsv_xyz a
WHERE  abcd_id = 15
-- Test commen
group by safdjljlk, asfdskfs, sysds;



SELECT abcd,
       cdejfsdf,
       sdfkjslkdfj,
       sysdate as abcd,
       sysdate(a,b)
INTO   asffs,
       sdfsdf
FROM   dsv_abcd left outer join dsv_xyz on abcd = xyu
WHERE  abcd_id IN ('A','B')
AND    x = Y
AND    fd = fdl -- Test Comment
group by safdjljlk, asfdskfs, sysds;



