from tree_sitter import Language, Parser
from SQL_toolkit import SQLParser, ASTProcessor
import pandas as pd
import paths, os
import re

sas_so = paths.SAS_GRAMMAR_FILE
sql_so = paths.SQL_GRAMMAR_FILE
output_file_location = os.path.join(paths.OUTPUT_PATH,"output.xlsx")
directory_name = "smu" # Name of the directory under the "inputs" folder

# Load the SAS grammar
LANGUAGE = Language(sas_so, 'sas')
parser = Parser()
parser.set_language(LANGUAGE)
sql_parser = SQLParser(sql_so, 'sql')

# Add these regex patterns after the imports
PROC_SQL_REGEX = re.compile(r"(?i)PROC\s+SQL\s*;(.*?)(?=\s*QUIT\s*;)", re.DOTALL)
PROC_DATA_REGEX = re.compile(r'(?i)data\s*=\s*(\w+\.?\w*)')
PROC_OUT_REGEX = re.compile(r'(?i)out\s*=\s*(\w+\.?\w*)')
CONNECTION_SQL_REGEX = re.compile(r'CREATE\s+TABLE\s+(\w+\.?\w*)\s+AS\s*(?:\s*SELECT\s+.*?FROM\s+CONNECTION\s+TO\s+(\w+)\s*\((.*?)\))', re.IGNORECASE | re.DOTALL)
SIMPLE_CONNECTION_SQL_REGEX = re.compile(r'CONNECTION\s+TO\s+(\w+)\s*\((.*?)\)', re.IGNORECASE | re.DOTALL)
CONNECT_TO_REGEX = re.compile(r'(?i)CONNECT\s+TO\s+.*?;', re.DOTALL)
DISCONNECT_REGEX = re.compile(r'(?i)DISCONNECT\s+FROM\s+\w+\s*;')
SELECT_FROM_CONNECTION_REGEX = re.compile(r'(?i)SELECT\s+.*?FROM\s+CONNECTION\s+TO\s+\w+\s*\(', re.DOTALL)
MACRO_PERIOD_REGEX = re.compile(r'&[^.\s]+\.')

def normalize_table_name(table_name):
    """Normalize table name by removing the first period after each & symbol"""
    if not isinstance(table_name, str):
        return table_name
    
    # Split the string into segments at & symbols
    parts = table_name.split('&')
    result = parts[0]  # Keep the first part as is
    
    # Process each part that started with &
    for part in parts[1:]:
        if part:  # Only process non-empty parts
            # Find the first period in this part
            period_idx = part.find('.')
            if period_idx != -1:
                # Keep everything before the first period and after it
                result += '&' + part[:period_idx] + part[period_idx + 1:]
            else:
                result += '&' + part
    
    return result.strip()

def normalize_sql(sql):
    """Normalize SQL string by cleaning up whitespace and formatting"""
    # First, handle the trailing period after table names in CREATE TABLE and FROM statements
    sql = re.sub(r'(?i)(CREATE\s+TABLE\s+\w+)\.(\s+AS)', r'\1\2', sql)
    sql = re.sub(r'(?i)(FROM\s+[\w.]+)\.(\s+)', r'\1\2', sql)  # Handle FROM statements
    sql = re.sub(r'(?i)(JOIN\s+[\w.]+)\.(\s+)', r'\1\2', sql)  # Handle JOIN statements
    
    
    # First, preserve important line breaks around parentheses and WHERE clauses
    sql = re.sub(r'\)\s*\n*\s*where', ')\nwhere', sql, flags=re.IGNORECASE)
    
    # Replace multiple whitespace with single space
    sql = re.sub(r'\s+', ' ', sql)
    
    # Ensure single space after commas
    sql = re.sub(r',\s*', ', ', sql)
    
    # Ensure single space around operators, but don't add spaces inside parentheses
    sql = re.sub(r'\s*(=|\+|-|\*|/)\s*', r' \1 ', sql)
    sql = re.sub(r'\s*\(\s*', ' (', sql)  # Space before (, no space after
    sql = re.sub(r'\s*\)\s*', ') ', sql)  # No space before ), space after
    
    # Clean up JOIN syntax
    sql = re.sub(r'\s+JOIN\s+', ' JOIN ', sql, flags=re.IGNORECASE)
    sql = re.sub(r'\s+ON\s+', ' ON ', sql, flags=re.IGNORECASE)
    
    # Clean up FROM syntax
    sql = re.sub(r'\s+FROM\s+', ' FROM ', sql, flags=re.IGNORECASE)
    
    # Restore line breaks for WHERE clauses after parentheses
    sql = re.sub(r'\)\s*where', ')\nwhere', sql, flags=re.IGNORECASE)
    
    # Remove any trailing/leading whitespace
    sql = sql.strip()
    
    return sql

def extract_proc_info(node, code_lines):
    """Extract information from PROC statements"""
    tables = []
    
    if node.type == 'proc_statement':
        # Get the line number and full statement text
        line_num = node.start_point[0] + 1
        proc_text = node.text.decode('utf-8')
        
        # Add the full code block
        full_block = proc_text
        
        # Get PROC type (first word after PROC)
        proc_match = re.search(r'(?i)PROC\s+(\w+)', proc_text)
        if proc_match:
            proc_type = proc_match.group(1).upper()
            
            # Find input (DATA=) and output (OUT=) datasets
            data_matches = PROC_DATA_REGEX.finditer(proc_text)
            out_matches = PROC_OUT_REGEX.finditer(proc_text)
            
            # Process input datasets
            for match in data_matches:
                dataset = normalize_table_name(match.group(1))
                lib, table = ('WORK', dataset) if '.' not in dataset else dataset.split('.')
                tables.append({
                    'type': 'input',
                    'step_type': f'PROC {proc_type}',
                    'library': lib,
                    'table': table,
                    'Source_Line': line_num,
                    'code_block': full_block
                })
            
            # Process output datasets
            for match in out_matches:
                dataset = match.group(1)
                lib, table = ('WORK', dataset) if '.' not in dataset else dataset.split('.')
                tables.append({
                    'type': 'output',
                    'step_type': f'PROC {proc_type}',
                    'library': lib,
                    'table': table,
                    'Source_Line': line_num,
                    'code_block': full_block
                })
    
    # Recursively process child nodes
    for child in node.children:
        tables.extend(extract_proc_info(child, code_lines))
    
    return tables

def extract_dataset_info(node, code_lines):
    """Extract dataset information from a node"""
    tables = []
    data_found = False
    
    # Get the line number for this node (1-based indexing)
    node_line_num = node.start_point[0] + 1
    
    if node.type == 'data_step':
        current_lib = 'WORK'
        # Capture the full DATA step code block
        full_block = node.text.decode('utf-8')
        
        for child in node.children:
            child_line_num = child.start_point[0] + 1
            
            if child.type == 'DATA':
                data_found = True
                continue
            elif data_found and child.type == 'identifier':
                next_sibling = child.next_sibling
                if next_sibling and next_sibling.type == '.':
                    current_lib = normalize_table_name(child.text.decode('utf-8'))
                else:
                    table = normalize_table_name(child.text.decode('utf-8'))
                    if table != '_null_':
                        tables.append({
                            'type': 'output',
                            'step_type': 'DATA',
                            'library': current_lib,
                            'table': table,
                            'Source_Line': child_line_num,
                            'code_block': full_block
                        })
                    data_found = False
            
            elif child.type == 'set_statement':
                current_lib = 'WORK'
                for set_child in child.children:
                    set_line_num = set_child.start_point[0] + 1
                    
                    if set_child.type == 'identifier':
                        next_sibling = set_child.next_sibling
                        if next_sibling and next_sibling.type == '.':
                            current_lib = normalize_table_name(set_child.text.decode('utf-8'))
                        else:
                            table = normalize_table_name(set_child.text.decode('utf-8'))
                            tables.append({
                                'type': 'input',
                                'step_type': 'SET',
                                'library': current_lib,
                                'table': table,
                                'Source_Line': set_line_num,
                                'code_block': full_block
                            })
                            current_lib = 'WORK'
            
            elif child.type == 'infile_statement':
                infile_text = child.text.decode('utf-8').strip()
                tables.append({
                    'type': 'input',
                    'step_type': 'INFILE',
                    'library': 'EXTERNAL',
                    'table': infile_text,
                    'Source_Line': child_line_num,
                    'involved_tables': None,
                    'join_condition': None,
                    'code_block': full_block
                })
    
    elif node.type == 'filename_statement':
        filename_text = node.text.decode('utf-8').strip()
        tables.append({
            'type': 'input',
            'step_type': 'FILENAME',
            'library': 'EXTERNAL',
            'table': filename_text,
            'Source_Line': node_line_num,
            'involved_tables': None,
            'join_condition': None,
            'code_block': filename_text
        })
    
    elif node.type == 'include_statement':
        include_text = node.text.decode('utf-8').strip()
        # Extract the file path
        file_path = None
        for child in node.children:
            if child.type == 'string':
                file_path = child.text.decode('utf-8').strip('"\'')
                break
            elif child.type == 'identifier':
                # Handle library.member format
                next_sibling = child.next_sibling
                if next_sibling and next_sibling.type == '.':
                    lib = child.text.decode('utf-8')
                    member = next_sibling.next_sibling.text.decode('utf-8') if next_sibling.next_sibling else None
                    if member:
                        file_path = f"{lib}.{member}"
        
        if file_path:
            tables.append({
                'type': 'input',
                'step_type': 'INCLUDE',
                'library': 'EXTERNAL',
                'table': include_text,
                'Source_Line': node_line_num,
                'involved_tables': None,
                'join_condition': None,
                'code_block': include_text
            })
    
    for child in node.children:
        tables.extend(extract_dataset_info(child, code_lines))
    
    tables.extend(extract_proc_info(node, code_lines))
    
    return tables

def extract_libref_info(node, code_lines):
    """Extract libref information from a node"""
    librefs = []
    
    if node.type == 'libname_statement':
        libref_name = None
        engine = None
        path = None
        line_num = node.start_point[0] + 1
        # Get the full statement
        full_statement = node.text.decode('utf-8')
        
        for child in node.children:
            if child.type == 'identifier' and not libref_name:
                libref_name = child.text.decode('utf-8')
            elif child.type == 'string':
                path = child.text.decode('utf-8').strip('"')
            elif child.type == 'identifier' and libref_name:
                engine = child.text.decode('utf-8')
        
        if libref_name:
            librefs.append({
                'libref': libref_name,
                'engine': engine,
                'path': path,
                'Source_Line': line_num,
                'full_statement': full_statement  # New column
            })
    
    for child in node.children:
        librefs.extend(extract_libref_info(child, code_lines))
    
    return librefs

def convert_df_to_lowercase(df):
    """Convert all string values in DataFrame to lowercase"""
    for column in df.columns:
        if df[column].dtype == 'object':  # Only convert string/object columns
            df[column] = df[column].apply(lambda x: x.lower() if isinstance(x, str) else x)
    return df

def preserve_lines_replace(pattern, repl, text):
    """Replace pattern with empty lines while preserving line count"""
    def replacement(match):
        # Count newlines in the matched text
        newline_count = match.group(0).count('\n')
        # If there are newlines, return that many empty lines
        if newline_count:
            return '\n' * newline_count
        # If no newlines, return a single space to preserve the line
        return ' '
    
    return re.sub(pattern, replacement, text)

def remove_comments(sql):
    """Remove SQL comments while preserving line numbers"""
    # Remove inline comments /*...*/
    sql = re.sub(r'/\*.*?\*/', '', sql)
    # Remove single-line comments --...
    sql = re.sub(r'--.*$', '', sql, flags=re.MULTILINE)
    return sql

def analyze_sas_file(file_path):
    """Analyze a SAS file and extract table and libref information"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            code = f.read()
        
        # First normalize the table names to handle periods after & symbols
        code = normalize_table_name(code)
        
        # Then handle macro variables
        code = code.replace('&', 'MACROREPLACE')
        
        sql_blocks = PROC_SQL_REGEX.finditer(code)
        sql_tables = []
        
        for match in sql_blocks:
            sql_content = match.group(1)
            line_num = code[:match.start()].count('\n') + 1
            original_block = f"PROC SQL;\n{sql_content}\nQUIT;"  # Capture original block
            
            # Remove comments first
            sql_content = remove_comments(sql_content)
            
            print("\n=== Original SQL ===")
            print(sql_content)
            
            # Clean up in specific order:
            cleaned_sql = sql_content
            
            # 1. Remove CONNECT TO statements
            cleaned_sql = preserve_lines_replace(CONNECT_TO_REGEX, '', cleaned_sql)
            
            # 2. Remove SELECT ... FROM CONNECTION TO ... (
            cleaned_sql = preserve_lines_replace(SELECT_FROM_CONNECTION_REGEX, '', cleaned_sql)
            
            
            # Continue with rest of the processing...
            
            print("\n=== Cleaned SQL ===")
            print(cleaned_sql)
            
            # Split the SQL content into individual statements
            statements = []
            current_statement = []
            paren_count = 0
            quote_char = None
            
            for char in cleaned_sql:
                if char in ["'", '"'] and (not quote_char or char == quote_char):
                    quote_char = None if quote_char else char
                
                if not quote_char:
                    if char == '(':
                        paren_count += 1
                    elif char == ')':
                        paren_count -= 1
                
                if char == ';' and paren_count == 0 and not quote_char:
                    current_statement = ''.join(current_statement).strip()
                    if current_statement:
                        statements.append(current_statement)
                    current_statement = []
                    continue
                
                current_statement.append(char)
            
            current_statement = ''.join(current_statement).strip()
            if current_statement:
                statements.append(current_statement)
            
            for statement in statements:
                normalized_sql = normalize_sql(statement)
                sql_tree = sql_parser.parse(normalized_sql)
                sql_processor = ASTProcessor(normalized_sql)
                sql_processor.traverse_tree(sql_tree.root_node)
                
                for _, row in sql_processor.df.iterrows():
                    # Add defensive checks for required fields
                    library = row.get('Library', 'WORK')  # Default to WORK if Library is missing
                    table = row.get('Table')
                    if table:  # Only add if we have a table name
                        sql_tables.append({
                            'type': 'input' if row.get('Input/Output') == 'Input' else 'output',
                            'step_type': f"PROC SQL {row.get('Operation', 'UNKNOWN')}".upper(),
                            'library': library,
                            'table': table,
                            'Source_Line': line_num,
                            'join_condition': row.get('Condition'),
                            'code_block': original_block
                        })
        
        # Now parse the SAS code normally
        code_lines = code.splitlines()
        tree = parser.parse(bytes(code, 'utf8'))
        
        del code
        
        tables = extract_dataset_info(tree.root_node, code_lines)
        librefs = extract_libref_info(tree.root_node, code_lines)
        
        tables.extend(sql_tables)
        
        # Create DataFrames with explicit columns including the new code_block column
        df_tables = pd.DataFrame(tables, columns=[
            'type', 'step_type', 'library', 'table', 'Source_Line', 
            'join_condition', 'code_block'
        ]).drop_duplicates()
        
        df_librefs = pd.DataFrame(librefs, columns=[
            'libref', 'engine', 'path', 'Source_Line', 'full_statement'
        ])
        
        # Filter and convert to lowercase
        if not df_tables.empty:
            df_tables = df_tables[df_tables['library'].str.lower() != 'connection']
            df_tables = df_tables.dropna(subset=['table'])
            df_tables = df_tables[df_tables['table'].str.strip() != "'"]
            df_tables = df_tables.sort_values(['type', 'library', 'table'])
        
        # Convert to lowercase and add quotes
        df_tables = convert_df_to_lowercase(df_tables)
        df_librefs = convert_df_to_lowercase(df_librefs)
        
        # Replace MACROREPLACE with & before adding quotes
        for df in [df_tables, df_librefs]:
            for column in df.columns:
                df[column] = df[column].apply(
                    lambda x: x.replace('macroreplace', '&') if isinstance(x, str) else x
                )
        
        # Add quotes after replacing MACROREPLACE
        for df in [df_tables, df_librefs]:
            for column in df.columns:
                df[column] = df[column].apply(
                    lambda x: f"'{str(x)}" if pd.notnull(x) else x
                )
        
        return df_tables, df_librefs
        
    except Exception as e:
        print(f"Error processing {file_path}: {str(e)}")
        print(f"Error details: {type(e).__name__}")
        return pd.DataFrame(), pd.DataFrame()

def analyze_sas_files(directory_path):
    """Analyze multiple SAS files in a directory and its subdirectories, and combine results."""
    all_tables = pd.DataFrame(columns=[
        'type', 'step_type', 'library', 'table', 'Source_Line', 
        'Source_File', 'join_condition'
    ])
    all_librefs = pd.DataFrame()
    
    stop_path = os.path.join(directory_path, 'a20')
    
    for root, dirs, files in os.walk(directory_path):
        # Check if we've reached or passed the a20 directory
        if root.startswith(stop_path):
            print(f"Stopping at directory: {stop_path}")
            break
            
        sas_files = [f for f in files if f.endswith('.sas')]
        
        for sas_file in sas_files:
            file_path = os.path.join(root, sas_file)
            print(file_path)
            try:
                df_tables, df_librefs = analyze_sas_file(file_path)
                
                if not df_tables.empty:
                    relative_path = os.path.relpath(file_path, start=directory_path)
                    df_tables['Source_File'] = relative_path
                    all_tables = pd.concat([all_tables, df_tables], ignore_index=True)
                
                if not df_librefs.empty:
                    relative_path = os.path.relpath(file_path, start=directory_path)
                    df_librefs['Source_File'] = relative_path
                    all_librefs = pd.concat([all_librefs, df_librefs], ignore_index=True)
            
            except Exception as e:
                print(f"Error processing {file_path}: {str(e)}")
    
    if not all_tables.empty or not all_librefs.empty:
        output_path = output_file_location
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            if not all_tables.empty:
                all_tables.to_excel(writer, sheet_name='Table Lineage', index=False)
            
            if not all_librefs.empty:
                all_librefs.to_excel(writer, sheet_name='Librefs', index=False)
            
            for sheet_name in writer.sheets:
                worksheet = writer.sheets[sheet_name]
                for column in worksheet.columns:
                    max_length = 0
                    column = [cell for cell in column]
                    for cell in column:
                        try:
                            if len(str(cell.value)) > max_length:
                                max_length = len(str(cell.value))
                        except:
                            pass
                    adjusted_width = (max_length + 2)
                    worksheet.column_dimensions[column[0].column_letter].width = adjusted_width
    
    return all_tables, all_librefs


# Modify the test code at the bottom
if __name__ == "__main__":
    input_directory = os.path.join(paths.INPUT_PATH,directory_name)
    
    result = analyze_sas_files(input_directory)
    print("\nExtracted Table Information:")
    # print(result)
    # print("Results have been exported.")